#!/usr/bin/env node
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { spawnSync } from "node:child_process";

const target = process.argv[2];

if (!target) {
  console.error("Usage: npm run open:output -- <path-to-docx-or-pdf>");
  console.error("Tip: DOCX/PDF can be finalized with WPS or LibreOffice when Microsoft Word is unavailable.");
  process.exit(1);
}

const filePath = resolve(target);
if (!existsSync(filePath)) {
  console.error(`Output file not found: ${filePath}`);
  process.exit(1);
}

function run(command, args) {
  const result = spawnSync(command, args, { stdio: "inherit", shell: process.platform === "win32" });
  return result.status === 0;
}

let ok = false;
if (process.platform === "darwin") {
  ok = run("open", [filePath]);
} else if (process.platform === "win32") {
  ok = run("powershell.exe", ["-NoProfile", "-Command", `Start-Process -LiteralPath ${JSON.stringify(filePath)}`]);
} else if (process.platform === "linux") {
  ok = run("xdg-open", [filePath]);
} else {
  ok = run("xdg-open", [filePath]);
}

if (!ok) {
  console.error("Could not open the file automatically.");
  console.error("Open it manually with WPS, LibreOffice, Microsoft Word, or your PDF viewer.");
  process.exit(1);
}

console.log(JSON.stringify({
  ok: true,
  file: filePath,
  platform: process.platform,
  recommended_apps: ["WPS", "LibreOffice", "Microsoft Word"],
}, null, 2));
