#!/usr/bin/env node
import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const platform = process.platform;
const isWindows = platform === "win32";
const isMac = platform === "darwin";
const isLinux = platform === "linux";
const includeLegacyDesktop = process.argv.includes("--include-legacy-desktop")
  || process.env.SCHOLAR_ASSIST_INCLUDE_LEGACY_DESKTOP === "1";
const checks = [];

function run(command, args = []) {
  const result = spawnSync(command, args, { cwd: root, encoding: "utf8", shell: false });
  return {
    ok: result.status === 0,
    stdout: (result.stdout || "").trim(),
    stderr: (result.stderr || "").trim(),
    status: result.status,
  };
}

function commandExists(binary) {
  if (isWindows) {
    return run("where.exe", [binary]);
  }
  return run("sh", ["-lc", `command -v ${binary}`]);
}

function add(name, ok, status, detail, kind = "local", nextStep = "") {
  checks.push({
    name,
    ok,
    status,
    detail,
    kind,
    next_step: nextStep || (ok ? "无需处理" : detail),
  });
}

function addCommandCheck(binary, label = binary, nextStep = "") {
  const resolved = commandExists(binary);
  add(label, resolved.ok, resolved.ok ? "ready" : "missing", resolved.stdout || resolved.stderr || `${label} 未安装或不在 PATH`, "local", nextStep);
}

function addOptionalCommandCheck(binary, label = binary, nextStep = "") {
  const resolved = commandExists(binary);
  add(
    label,
    resolved.ok,
    resolved.ok ? "ready" : "optional",
    resolved.stdout || resolved.stderr || `${label} 未安装或不在 PATH；这是标准导出增强项，不阻断 Web-first 写作和部署`,
    "local",
    resolved.ok ? "无需处理" : nextStep,
  );
}

function pythonCandidates() {
  const configuredPythonRoot = process.env.pythonLocation || process.env.Python_ROOT_DIR || "";
  const configuredPython = configuredPythonRoot
    ? [{ label: "setup-python", command: join(configuredPythonRoot, isWindows ? "python.exe" : "bin/python"), args: [] }]
    : [];
  const defaults = isWindows
    ? [
        { label: "python", command: "python", args: [] },
        { label: "py -3", command: "py", args: ["-3"] },
        { label: "python3", command: "python3", args: [] },
      ]
    : [
        { label: "python3", command: "python3", args: [] },
        { label: "python", command: "python", args: [] },
      ];
  return [...configuredPython, ...defaults];
}

function resolvePython() {
  let blockedCandidate = null;
  for (const candidate of pythonCandidates()) {
    const result = run(candidate.command, [...candidate.args, "--version"]);
    if (result.ok) return { ...candidate, version: result.stdout || result.stderr };
    const detail = result.stderr || result.stdout;
    if (/Xcode license|xcodebuild -license|Apple SDKs license/i.test(detail)) {
      blockedCandidate = { ...candidate, version: detail, external_blocked: true };
    }
  }
  if (blockedCandidate) return blockedCandidate;
  return null;
}

function checkPythonModule(moduleName, importStatement, nextStep) {
  const python = resolvePython();
  if (!python) {
    add(moduleName, false, "missing", "未检测到 Python；Windows 推荐安装 Python 后确认 py -3 可用", "local", "安装 Python 3.11+，然后运行 pip install -r backend/requirements.txt。");
    return;
  }
  if (python.external_blocked) {
    add(
      moduleName,
      false,
      "external-blocked",
      python.version,
      "external",
      "在 macOS 终端运行 sudo xcodebuild -license 并同意 Xcode 许可后再跑浏览器辅助 smoke。",
    );
    return;
  }
  const result = run(python.command, [...python.args, "-c", importStatement]);
  const detail = result.stderr || result.stdout || `${moduleName} checked by ${python.label}`;
  const externalBlock = /Xcode license|xcodebuild -license|Apple SDKs license/i.test(detail);
  add(
    moduleName,
    result.ok,
    result.ok ? "ready" : externalBlock ? "external-blocked" : "optional",
    detail,
    externalBlock ? "external" : "local",
    result.ok
      ? `使用 ${python.label}：${python.version}`
      : externalBlock
        ? "在 macOS 终端运行 sudo xcodebuild -license 并同意 Xcode 许可后再跑浏览器辅助 smoke。"
        : `${nextStep} 这是浏览器辅助增强项，不阻断 Web-first 启动、阅读和基础写作。`,
  );
}

function addWebDistributionCheck() {
  const webDistributionFiles = ["Dockerfile", "docker-compose.yml", "docs/WEB_DEPLOYMENT.md", "scripts/package-web-release.mjs", "scripts/start-web.mjs"];
  const missingWebFiles = webDistributionFiles.filter(file => !existsSync(join(root, file)));
  add(
    "Web-first distribution",
    missingWebFiles.length === 0,
    missingWebFiles.length === 0 ? "ready" : "missing",
    missingWebFiles.length === 0
      ? "已具备 Docker、Web 部署文档、跨平台启动脚本和免 Apple 签名 Web 发布包脚本"
      : `缺少 Web 分发文件：${missingWebFiles.join(", ")}`,
    "local",
    missingWebFiles.length === 0
      ? "运行 npm run web:start 本地启动，或 npm run web:package 生成 release/web/latest-web.json 和网页发布包。"
      : "补齐 Web-first 分发文件后再打包。",
  );
}

function addMacChecks() {
  if (!includeLegacyDesktop) {
    const wpsCandidates = [
      "/Applications/wpsoffice.app",
      "/Applications/WPS Office.app",
      "/Applications/WPS Office for Mac.app",
    ];
    const wpsAppPath = wpsCandidates.find(path => existsSync(path));
    add(
      "WPS Office.app",
      Boolean(wpsAppPath),
      wpsAppPath ? "ready" : "optional",
      wpsAppPath || "未检测到 WPS Office；可选用 WPS 或 LibreOffice 打开导出的 DOCX/PDF",
      "local",
      wpsAppPath ? "可用于定稿和校对。" : "这是可选阅读/定稿软件，不阻断 Web 写作。",
    );
    return;
  }
  const wordAppPath = "/Applications/Microsoft Word.app";
  const wpsCandidates = [
    "/Applications/wpsoffice.app",
    "/Applications/WPS Office.app",
    "/Applications/WPS Office for Mac.app",
  ];
  const wpsAppPath = wpsCandidates.find(path => existsSync(path));

  add(
    "Microsoft Word.app",
    existsSync(wordAppPath),
    existsSync(wordAppPath) ? "ready" : "external-blocked",
    existsSync(wordAppPath)
      ? "已检测到 Word，可按 word-addin/README.md sideload"
      : "未检测到 Microsoft Word.app，真实 sideload 需要本机安装 Word；WPS/DOCX 路线不受影响",
    "external",
    existsSync(wordAppPath)
      ? "运行 node word-addin/dev-server.mjs，然后在 Word 中上传 word-addin/manifest.xml。"
      : "不影响 Scholar Assist 独立写作和导出；没有 Word 时优先导出 DOCX/PDF 并用 WPS 打开校对。",
  );

  add(
    "WPS Office.app",
    Boolean(wpsAppPath),
    wpsAppPath ? "ready" : "optional",
    wpsAppPath
      ? `已检测到 ${wpsAppPath}，可作为无 Word 用户的 DOCX 定稿和校对软件`
      : "未检测到 WPS Office；这是无 Word 用户的可选定稿软件，不影响内置导出",
    "local",
    wpsAppPath
      ? "在 Scholar Assist 导出 DOCX/PDF 后，用 WPS 打开做导师批注、最终校对和学校模板微调。"
      : "没有 Microsoft Word 时可安装 WPS 或 LibreOffice；也可以先使用内置 PDF/HTML/Markdown 导出。",
  );

  const identities = run("security", ["find-identity", "-v", "-p", "codesigning"]);
  const hasDeveloperId = /Developer ID Application/.test(identities.stdout);
  add(
    "Developer ID Application",
    hasDeveloperId,
    hasDeveloperId ? "ready" : "external-blocked",
    hasDeveloperId ? "已检测到 Developer ID Application 证书" : "未检测到 Developer ID Application 证书；签名/公证需要 Apple Developer Program",
    "external",
    hasDeveloperId
      ? "配置 Tauri signingIdentity 后执行签名构建和 notarytool 公证。"
      : "没有 Developer ID 仍可开发和网页分发；面向外部 macOS 用户时需加入 Apple Developer Program 并安装证书。",
  );

  const notarytool = run("xcrun", ["notarytool", "--help"]);
  add(
    "notarytool",
    notarytool.ok,
    notarytool.ok ? "ready" : "external-blocked",
    notarytool.ok ? "xcrun notarytool 可用" : "notarytool 不可用；公证需要 Xcode 工具链和 Apple 账号",
    "external",
    notarytool.ok
      ? "使用 xcrun notarytool submit 上传已签名 DMG/App，并在通过后 staple。"
      : "安装 Xcode Command Line Tools 并配置 Apple 账号后再做公证；网页版本不需要此步骤。",
  );

  const xattr = run("xattr", ["-h"]);
  add(
    "xattr",
    xattr.ok,
    xattr.ok ? "ready" : "missing",
    "用于诊断 macOS quarantine 导致的“已损坏，无法打开”",
    "local",
    xattr.ok ? "手动测试包被 Gatekeeper 拦截时，可执行 xattr -dr com.apple.quarantine '/Applications/Scholar Assist.app'。" : "安装 macOS xattr 工具后再排查 quarantine。",
  );
}

function addWindowsChecks() {
  addCommandCheck("node", "Windows Node.js", "安装 Node.js LTS 后重新打开 PowerShell。");
  addCommandCheck("npm", "Windows npm", "安装 Node.js LTS 后重新打开 PowerShell。");
  addOptionalCommandCheck("docker", "Windows Docker", "可选：安装 Docker Desktop 后用 docker compose up --build 一条命令运行。");

  const chromeCandidates = [
    join(process.env.ProgramFiles || "C:\\Program Files", "Google", "Chrome", "Application", "chrome.exe"),
    join(process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)", "Google", "Chrome", "Application", "chrome.exe"),
    join(process.env.LOCALAPPDATA || "", "Google", "Chrome", "Application", "chrome.exe"),
  ];
  const chromePath = chromeCandidates.find(path => path && existsSync(path));
  const chromeWhere = commandExists("chrome");
  add(
    "Google Chrome",
    Boolean(chromePath) || chromeWhere.ok,
    Boolean(chromePath) || chromeWhere.ok ? "ready" : "optional",
    chromePath || chromeWhere.stdout || "未检测到 Google Chrome；浏览器辅助可使用 Playwright Chromium 或安装 Chrome",
    "local",
    chromePath || chromeWhere.ok ? "可用于人工验证后的浏览器辅助搜索。" : "安装 Chrome 或运行 python -m playwright install chromium。",
  );

  const wpsBase = process.env.ProgramFiles || "C:\\Program Files";
  const wpsCandidates = [
    join(wpsBase, "Kingsoft", "WPS Office"),
    join(process.env.LOCALAPPDATA || "", "Kingsoft", "WPS Office"),
  ];
  const wpsPath = wpsCandidates.find(path => path && existsSync(path));
  add(
    "Windows WPS Office",
    Boolean(wpsPath),
    wpsPath ? "ready" : "optional",
    wpsPath || "未检测到 WPS Office；可安装 WPS 或 LibreOffice 打开导出的 DOCX/PDF",
    "local",
    wpsPath ? "导出 DOCX/PDF 后可用 WPS 定稿和校对。" : "没有 Word 时建议安装 WPS 或 LibreOffice。",
  );
}

function addLinuxChecks() {
  addCommandCheck("node", "Linux Node.js", "安装 Node.js LTS。");
  addCommandCheck("npm", "Linux npm", "安装 Node.js LTS。");
  addOptionalCommandCheck("docker", "Linux Docker", "可选：安装 Docker Engine 和 Compose。");
  addOptionalCommandCheck("xdg-open", "xdg-open", "可选：安装 xdg-utils 后可从脚本打开导出文件。");
}

for (const binary of ["pandoc", "quarto", "pandoc-crossref"]) {
  addOptionalCommandCheck(binary, binary, `可选安装 ${binary} 以增强 DOCX/PDF/交叉引用导出；不影响 Web-first 启动、阅读和基础写作。`);
}

checkPythonModule(
  "python playwright",
  "from playwright.sync_api import sync_playwright; print('playwright ok')",
  "安装 Python 依赖后再运行 UI smoke：python -m pip install -r backend/requirements.txt && python -m playwright install chromium。",
);

if (includeLegacyDesktop) {
  add(
    "word-addin/manifest.xml",
    existsSync(join(root, "word-addin/manifest.xml")),
    existsSync(join(root, "word-addin/manifest.xml")) ? "ready" : "missing",
    "已冻结的 Word 插件 manifest 文件",
  );
}

addWebDistributionCheck();

if (includeLegacyDesktop) {
  const tauri = run(isWindows ? "npx.cmd" : "npx", ["tauri", "--version"]);
  add(
    "tauri cli",
    tauri.ok,
    tauri.ok ? "ready" : "optional",
    tauri.stdout || tauri.stderr || "Tauri CLI 未检测到；桌面路线已冻结，不阻断 Web 交付",
    "local",
    tauri.ok ? "无需处理" : "只在恢复桌面开发时安装 Tauri CLI。",
  );
}

if (isMac) addMacChecks();
if (isWindows) addWindowsChecks();
if (isLinux) addLinuxChecks();

if (includeLegacyDesktop && !isWindows) {
  const tauriDriverPath = commandExists("tauri-driver");
  const tauriDriverUsable = tauriDriverPath.ok ? run("sh", ["-lc", "tauri-driver --help >/tmp/scholar-assist-tauri-driver-help.txt 2>&1"]) : { ok: false, stdout: "", stderr: "" };
  let tauriDriverDetail = tauriDriverPath.stdout || "未检测到 tauri-driver；Tauri 真桌面 UI smoke 需要先安装 WebDriver：cargo install tauri-driver";
  if (tauriDriverPath.ok && !tauriDriverUsable.ok) {
    const help = run("sh", ["-lc", "cat /tmp/scholar-assist-tauri-driver-help.txt 2>/dev/null || true"]);
    tauriDriverDetail = help.stdout || help.stderr || "tauri-driver 已安装，但当前平台不可运行";
  }
  add(
    "tauri-driver",
    tauriDriverPath.ok && tauriDriverUsable.ok,
    tauriDriverPath.ok && tauriDriverUsable.ok ? "ready" : "external-blocked",
    tauriDriverDetail,
    "external",
    tauriDriverPath.ok && tauriDriverUsable.ok
      ? "可接入 Tauri 真桌面 smoke test。"
      : "如需真实桌面 UI 自动化验收，安装并确认 tauri-driver 在当前平台可运行。",
  );
}

const artifact = {
  generated_at: new Date().toISOString(),
  platform,
  profile: includeLegacyDesktop ? "web-plus-legacy-desktop" : "web",
  platform_label: isWindows ? "Windows" : isMac ? "macOS" : isLinux ? "Linux" : platform,
  summary: {
    ready: checks.filter(check => check.ok).length,
    missing: checks.filter(check => !check.ok && check.status === "missing").length,
    external_blocked: checks.filter(check => check.status === "external-blocked").length,
    optional: checks.filter(check => check.status === "optional").length,
  },
  checks,
};

mkdirSync(join(root, "tmp"), { recursive: true });
writeFileSync(join(root, "tmp", "delivery-doctor.json"), JSON.stringify(artifact, null, 2), "utf8");
console.log(JSON.stringify(artifact, null, 2));

const hardFailures = checks.filter(check => !check.ok && check.kind !== "external" && check.status !== "optional");
process.exit(hardFailures.length ? 1 : 0);
