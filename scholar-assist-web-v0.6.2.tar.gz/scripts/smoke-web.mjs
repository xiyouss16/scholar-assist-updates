#!/usr/bin/env node
const args = new Map();
for (let i = 2; i < process.argv.length; i += 1) {
  const key = process.argv[i];
  if (!key.startsWith("--")) continue;
  const next = process.argv[i + 1];
  if (!next || next.startsWith("--")) {
    args.set(key, "true");
  } else {
    args.set(key, next);
    i += 1;
  }
}

const baseUrl = (args.get("--base-url") || process.env.SCHOLAR_ASSIST_WEB_URL || "http://127.0.0.1:8765").replace(/\/+$/, "");
const retries = Number(args.get("--retries") || 30);
const delayMs = Number(args.get("--delay-ms") || 1000);

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function fetchWithRetry(path, checker) {
  const url = `${baseUrl}${path}`;
  let lastError = null;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const response = await fetch(url);
      const text = await response.text();
      if (response.ok && checker(response, text)) return { response, text };
      lastError = new Error(`Unexpected response from ${url}: ${response.status} ${text.slice(0, 120)}`);
    } catch (error) {
      lastError = error;
    }
    await sleep(delayMs);
  }
  throw lastError || new Error(`Smoke failed for ${url}`);
}

try {
  const platformLabel = process.platform === "win32" ? "Windows" : process.platform;
  await fetchWithRetry("/api/health", (_response, text) => text.includes("Scholar Assist Backend"));
  await fetchWithRetry("/", (_response, text) => text.includes("Scholar Assist") || text.includes("<div id=\"root\""));
  console.log(JSON.stringify({ ok: true, baseUrl, platform: platformLabel }, null, 2));
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
}
