"""
Feature 6: PDF 导入解析
使用 PyMuPDF 提取全文文本和元数据
"""
from __future__ import annotations

import base64
import re
import os
import hashlib
import json
from pathlib import Path
from typing import Optional

try:
    import fitz  # PyMuPDF
    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

# ═══════════════════════════════════════════
# PDF 文本和元数据提取
# ═══════════════════════════════════════════

def _positive_env_int(name: str, default: int) -> int:
    try:
        return max(1, int(os.getenv(name, str(default))))
    except ValueError:
        return default


def pdf_extraction_limits() -> dict[str, int]:
    """Return explicit safety limits that still accommodate long theses."""
    return {
        "max_pages": _positive_env_int("SCHOLAR_ASSIST_MAX_PDF_PAGES", 500),
        "max_full_text_chars": _positive_env_int("SCHOLAR_ASSIST_MAX_PDF_TEXT_CHARS", 2_000_000),
        "max_page_text_chars": _positive_env_int("SCHOLAR_ASSIST_MAX_PDF_PAGE_TEXT_CHARS", 20_000),
        "preview_pages": _positive_env_int("SCHOLAR_ASSIST_MAX_PDF_PREVIEW_PAGES", 20),
    }


def _annotation_root() -> Path:
    root = Path(os.getenv("SCHOLAR_ASSIST_PDF_ANNOTATION_DIR", Path.home() / ".scholar-assist" / "pdf-annotations")).expanduser()
    root.mkdir(parents=True, exist_ok=True)
    return root


def _safe_pdf_id(paper_id: str) -> str:
    clean = re.sub(r"[^a-zA-Z0-9_\-]+", "-", paper_id or "unknown-pdf").strip("-")
    return clean or "unknown-pdf"


def _annotation_path(paper_id: str) -> Path:
    return _annotation_root() / f"{_safe_pdf_id(paper_id)}.json"


def list_pdf_annotations(paper_id: str) -> list[dict]:
    path = _annotation_path(paper_id)
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        return payload.get("annotations", [])
    except Exception:
        return []


def save_pdf_annotation(paper_id: str, annotation: dict) -> dict:
    annotations = [item for item in list_pdf_annotations(paper_id) if item.get("id") != annotation.get("id")]
    item = {
        "id": annotation.get("id") or hashlib.sha1(json.dumps(annotation, sort_keys=True).encode("utf-8")).hexdigest()[:12],
        "page": int(annotation.get("page") or 1),
        "text": annotation.get("text") or "",
        "note": annotation.get("note") or "",
        "tags": annotation.get("tags") or [],
        "rect": annotation.get("rect"),
        "createdAt": annotation.get("createdAt") or annotation.get("created_at") or "",
    }
    annotations.insert(0, item)
    path = _annotation_path(paper_id)
    path.write_text(json.dumps({"paper_id": paper_id, "annotations": annotations}, ensure_ascii=False, indent=2), encoding="utf-8")
    return item


def delete_pdf_annotation(paper_id: str, annotation_id: str) -> None:
    annotations = [item for item in list_pdf_annotations(paper_id) if item.get("id") != annotation_id]
    _annotation_path(paper_id).write_text(json.dumps({"paper_id": paper_id, "annotations": annotations}, ensure_ascii=False, indent=2), encoding="utf-8")

def _normalize_rect(bbox: list | tuple | None) -> dict | None:
    if not bbox or len(bbox) < 4:
        return None
    x0, y0, x1, y1 = [round(float(value), 2) for value in bbox[:4]]
    return {
        "x": x0,
        "y": y0,
        "width": max(0, round(x1 - x0, 2)),
        "height": max(0, round(y1 - y0, 2)),
    }


def build_page_layouts(raw_pages: list[dict], max_blocks: int = 80) -> list[dict]:
    """Normalize PDF page previews and text block rectangles for source backlinks."""
    layouts = []
    for item in raw_pages:
        text_blocks = []
        for block in item.get("blocks", [])[:max_blocks]:
            text = " ".join((block.get("text") or "").split())
            rect = _normalize_rect(block.get("bbox") or block.get("rect"))
            if not text or not rect:
                continue
            text_blocks.append({
                "text": text[:1000],
                "rect": rect,
            })
        layouts.append({
            "page": item.get("page", 0),
            "width": round(float(item.get("width") or 595), 2),
            "height": round(float(item.get("height") or 842), 2),
            "preview_url": item.get("preview_url", ""),
            "text_blocks": text_blocks,
        })
    return layouts


def build_page_segments(page_texts: list[dict], max_chars: int = 1800, page_layouts: list[dict] | None = None) -> list[dict]:
    """Build page-aware snippets for deep reading and AI context."""
    layout_lookup = {layout.get("page"): layout for layout in page_layouts or []}
    segments = []
    for item in page_texts:
        text = " ".join((item.get("text") or "").split())
        if not text:
            continue
        first_block = (layout_lookup.get(item.get("page", 0), {}).get("text_blocks") or [{}])[0]
        segments.append({
            "page": item.get("page", 0),
            "text": text[:max_chars],
            "char_count": len(item.get("text") or ""),
            "rect": first_block.get("rect"),
        })
    return segments


def find_relevant_pages(page_texts: list[dict], query: str, limit: int = 3) -> list[dict]:
    """Return pages with the most simple term overlaps for a user question."""
    terms = [t.lower() for t in re.findall(r"[\w\u4e00-\u9fff]+", query) if len(t) > 1]
    matches = []
    for item in page_texts:
        text = item.get("text") or ""
        lowered = text.lower()
        score = sum(1 for term in terms if term in lowered)
        if score > 0:
            matches.append({
                "page": item.get("page", 0),
                "score": score,
                "text": " ".join(text.split())[:1200],
            })
    matches.sort(key=lambda x: x["score"], reverse=True)
    return matches[:limit]


def build_pdf_reading_map(page_texts: list[dict], query: str = "", limit: int = 8) -> dict:
    """Build a Zotero-like reading spine with page evidence cards."""
    segments = build_page_segments(page_texts)
    relevant = find_relevant_pages(page_texts, query, limit=limit) if query else []
    relevant_pages = {item["page"]: item for item in relevant}
    evidence_cards = []
    for segment in segments[: max(limit, len(relevant_pages))]:
        page = segment["page"]
        evidence_cards.append({
            "id": f"P{page}",
            "page": page,
            "score": relevant_pages.get(page, {}).get("score", 0),
            "text": relevant_pages.get(page, {}).get("text") or segment["text"][:1200],
            "jump_label": f"跳到第 {page} 页",
        })
    evidence_cards.sort(key=lambda item: (item["score"], -item["page"]), reverse=True)
    return {
        "total_pages": len(page_texts),
        "reading_spine": [{"page": item.get("page", 0), "char_count": len(item.get("text") or "")} for item in page_texts],
        "evidence_cards": evidence_cards[:limit],
    }

async def extract_pdf_text(file_path: str) -> dict:
    """从 PDF 文件中提取全文和元数据"""
    if not HAS_PYMUPDF:
        return {"error": "PyMuPDF 未安装，请运行 pip install pymupdf"}

    if not os.path.exists(file_path):
        return {"error": f"文件不存在: {file_path}"}

    try:
        doc = fitz.open(file_path)
        metadata = doc.metadata
        total_pages = len(doc)
        limits = pdf_extraction_limits()
        processed_pages = min(total_pages, limits["max_pages"])

        # 提取全文
        full_text = ""
        page_texts = []
        raw_page_layouts = []
        page_text_truncated = False
        for page_num in range(processed_pages):
            page = doc[page_num]
            text = page.get_text()
            if len(text) > limits["max_page_text_chars"]:
                page_text_truncated = True
            page_texts.append({"page": page_num + 1, "text": text[:limits["max_page_text_chars"]]})
            if len(full_text) < limits["max_full_text_chars"]:
                remaining = limits["max_full_text_chars"] - len(full_text)
                full_text += text[:remaining]
            blocks = []
            text_dict = page.get_text("dict")
            for block in text_dict.get("blocks", []):
                if block.get("type") != 0:
                    continue
                lines = []
                for line in block.get("lines", []):
                    spans = [span.get("text", "") for span in line.get("spans", [])]
                    if spans:
                        lines.append("".join(spans))
                block_text = " ".join(" ".join(lines).split())
                if block_text:
                    blocks.append({"text": block_text, "bbox": block.get("bbox")})
            preview_url = ""
            if page_num < limits["preview_pages"]:
                try:
                    pix = page.get_pixmap(matrix=fitz.Matrix(1.25, 1.25), alpha=False)
                    preview_url = "data:image/png;base64," + base64.b64encode(pix.tobytes("png")).decode("ascii")
                except Exception:
                    preview_url = ""
            raw_page_layouts.append({
                "page": page_num + 1,
                "width": page.rect.width,
                "height": page.rect.height,
                "preview_url": preview_url,
                "blocks": blocks,
            })

        doc.close()
        page_layouts = build_page_layouts(raw_page_layouts)

        # MD5 去重 ID
        paper_id = hashlib.md5(full_text[:500].encode()).hexdigest()[:12]

        # 提取标题 (第一页前 200 字符中找最大字号文本)
        title = metadata.get("title", "") or "Unknown Title"

        # 提取作者
        authors = metadata.get("author", "") or "Unknown"

        # 提取 DOI
        doi = ""
        doi_match = re.search(r'10\.\d{4,}/[^\s]+', full_text[:2000])
        if doi_match:
            doi = doi_match.group(0).rstrip(".,;")

        return {
            "id": f"pdf_{paper_id}",
            "title": title,
            "authors": authors,
            "year": _extract_year(full_text[:500]),
            "source": "PDF 导入",
            "abstract": _extract_abstract(full_text)[:1000],
            "full_text": full_text,
            "total_pages": total_pages,
            "doi": doi,
            "url": f"file://{file_path}",
            "page_texts": page_texts,
            "page_segments": build_page_segments(page_texts, page_layouts=page_layouts),
            "page_layouts": page_layouts,
            "extraction": {
                "processed_pages": processed_pages,
                "total_pages": total_pages,
                "truncated": processed_pages < total_pages or page_text_truncated or len(full_text) >= limits["max_full_text_chars"],
                "limits": limits,
            },
        }

    except Exception as e:
        return {"error": f"PDF 解析失败: {str(e)}"}

async def extract_pdf_metadata_only(file_path: str) -> dict:
    """仅提取 PDF 元数据 (更快)"""
    if not HAS_PYMUPDF:
        return {"error": "PyMuPDF 未安装"}

    try:
        doc = fitz.open(file_path)
        metadata = doc.metadata
        first_page_text = doc[0].get_text() if len(doc) > 0 else ""
        total_pages = len(doc)
        doc.close()

        return {
            "title": metadata.get("title", "") or "Unknown",
            "authors": metadata.get("author", "") or "Unknown",
            "subject": metadata.get("subject", ""),
            "keywords": metadata.get("keywords", ""),
            "total_pages": total_pages,
            "first_page_preview": first_page_text[:500],
        }
    except Exception as e:
        return {"error": str(e)}

# ═══════════════════════════════════════════
# 辅助函数
# ═══════════════════════════════════════════

def _extract_year(text: str) -> int:
    """从文本中提取年份"""
    # 常见年份格式: (2024), [2023], 发表于 2022 年
    year_patterns = [
        r'\((\d{4})\)',
        r'\[(\d{4})\]',
        r'published.*?(\d{4})',
        r'(\d{4}).*?Conference',
        r'©\s*(\d{4})',
        r'Copyright\s*©?\s*(\d{4})',
    ]
    for pattern in year_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            year = int(match.group(1))
            if 1900 <= year <= 2030:
                return year
    return 0

def _extract_abstract(text: str) -> str:
    """从全文开头提取摘要"""
    # 尝试匹配 "Abstract" / "摘要" 开头的段落
    patterns = [
        r'(?:Abstract|ABSTRACT|摘要)[\s:：\-—]+(.{100,1500})',
        r'(?:A\s*B\s*S\s*T\s*R\s*A\s*C\s*T)[\s:：\-—]+(.{100,1500})',
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.DOTALL)
        if match:
            abstract = match.group(1).strip()
            # 截断到下一个标题
            cutoff = re.search(r'\n\s*(?:1\.|I\.|Introduction|引言|绪论)', abstract)
            if cutoff:
                abstract = abstract[:cutoff.start()]
            return abstract

    # Fallback: 取前 500 字符
    return text[:500]
