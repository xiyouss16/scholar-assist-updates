"""
Feature 3: AI 总结调用
支持 Claude API、DeepSeek API、流式输出
"""
from __future__ import annotations
import json
import aiohttp
import ipaddress
import os
import socket
from typing import AsyncGenerator
from urllib.parse import urlsplit
from utils import LLM_CONFIG, DEFAULT_LLM

CUSTOM_PROVIDER_DEFAULTS = {
    "openai": {
        "name": "OpenAI",
        "protocol": "openai",
        "base_url": "https://api.openai.com",
        "model": "gpt-4o",
    },
    "deepseek": {
        "name": "DeepSeek",
        "protocol": "openai",
        "base_url": "https://api.deepseek.com",
        "model": "deepseek-v4-flash",
    },
    "claude": {
        "name": "Claude",
        "protocol": "anthropic",
        "base_url": "https://api.anthropic.com",
        "model": "claude-3-5-sonnet-latest",
    },
    "custom": {
        "name": "自定义",
        "protocol": "openai",
        "base_url": "",
        "model": "",
    },
}


def _unsafe_destination_ip(value: str) -> bool:
    address = ipaddress.ip_address(value)
    return any((
        address.is_private,
        address.is_loopback,
        address.is_link_local,
        address.is_multicast,
        address.is_reserved,
        address.is_unspecified,
    ))


def validate_outbound_ai_url(value: str) -> str:
    """Reject custom AI endpoints that could reach local or metadata services."""
    normalized = (value or "").strip().rstrip("/")
    parsed = urlsplit(normalized)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Base URL 仅支持有效的 HTTP/HTTPS 地址")
    if parsed.username or parsed.password:
        raise ValueError("Base URL 不能包含用户名或密码")
    if os.getenv("SCHOLAR_ASSIST_ALLOW_PRIVATE_AI_ENDPOINTS", "").strip() == "1":
        return normalized

    hostname = parsed.hostname.rstrip(".").lower()
    if hostname == "localhost" or hostname.endswith(".localhost"):
        raise ValueError("Base URL 不允许访问本机或内网地址")
    try:
        if _unsafe_destination_ip(hostname):
            raise ValueError("Base URL 不允许访问本机或内网地址")
        return normalized
    except ValueError as exc:
        if "不允许" in str(exc):
            raise

    try:
        addresses = {item[4][0] for item in socket.getaddrinfo(hostname, parsed.port or 443, type=socket.SOCK_STREAM)}
    except socket.gaierror as exc:
        raise ValueError("Base URL 域名无法解析") from exc
    if any(_unsafe_destination_ip(address) for address in addresses):
        raise ValueError("Base URL 不允许解析到本机或内网地址")
    return normalized


def normalize_custom_provider(
    provider: str,
    api_key: str,
    base_url: str,
    model: str,
) -> dict:
    """Merge user input with known provider defaults."""
    provider_id = (provider or "openai").strip().lower()
    defaults = CUSTOM_PROVIDER_DEFAULTS.get(provider_id, CUSTOM_PROVIDER_DEFAULTS["custom"])
    normalized_base_url = validate_outbound_ai_url(base_url or defaults["base_url"])
    normalized_model = (model or defaults["model"]).strip()
    if provider_id == "deepseek":
        normalized_model = normalized_model.lower()

    return {
        "id": provider_id if provider_id in CUSTOM_PROVIDER_DEFAULTS else "custom",
        "protocol": defaults["protocol"],
        "api_key": api_key.strip(),
        "base_url": normalized_base_url,
        "model": normalized_model,
    }


def build_openai_compatible_request(
    api_key: str,
    base_url: str,
    model: str,
    messages: list[dict],
    system_prompt: str,
    max_tokens: int,
    temperature: float,
) -> dict:
    """Build an OpenAI-compatible chat completions request."""
    formatted_messages = [{"role": "system", "content": system_prompt or "你是学术研究助手。"}]
    for msg in messages:
        formatted_messages.append({
            "role": msg.get("role", "user"),
            "content": msg.get("content", ""),
        })

    return {
        "url": f"{base_url.rstrip('/')}/v1/chat/completions",
        "headers": {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        "payload": {
            "model": model,
            "messages": formatted_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        },
    }


def build_anthropic_request(
    api_key: str,
    base_url: str,
    model: str,
    messages: list[dict],
    system_prompt: str,
    max_tokens: int,
    temperature: float,
) -> dict:
    """Build an Anthropic Messages API request."""
    formatted_messages = []
    for msg in messages:
        role = msg.get("role", "user")
        formatted_messages.append({
            "role": "assistant" if role == "assistant" else "user",
            "content": msg.get("content", ""),
        })

    return {
        "url": f"{base_url.rstrip('/')}/v1/messages",
        "headers": {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        "payload": {
            "model": model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system_prompt or "你是学术研究助手。",
            "messages": formatted_messages,
        },
    }


def build_custom_api_request(
    provider_config: dict,
    messages: list[dict],
    system_prompt: str,
    max_tokens: int,
    temperature: float,
) -> dict:
    """Build the provider-specific request for user-supplied API settings."""
    if provider_config["protocol"] == "anthropic":
        return build_anthropic_request(
            provider_config["api_key"],
            provider_config["base_url"],
            provider_config["model"],
            messages,
            system_prompt,
            max_tokens,
            temperature,
        )

    return build_openai_compatible_request(
        provider_config["api_key"],
        provider_config["base_url"],
        provider_config["model"],
        messages,
        system_prompt,
        max_tokens,
        temperature,
    )


async def post_ai_request(request: dict, provider_label: str = "API") -> str:
    """Send a provider request and normalize supported response formats."""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                request["url"],
                json=request["payload"],
                headers=request["headers"],
                timeout=aiohttp.ClientTimeout(total=60),
                allow_redirects=False,
            ) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    return f"[{provider_label} 错误 {resp.status}] {error_text[:300]}"

                data = await resp.json()
                if "choices" in data:
                    choices = data.get("choices", [])
                    if choices:
                        return choices[0].get("message", {}).get("content", "")
                if "content" in data:
                    for block in data.get("content", []):
                        if block.get("type") == "text":
                            return block.get("text", "")
                return f"[{provider_label} 返回为空]"

    except Exception as e:
        return f"[{provider_label} 调用异常] {str(e)}"

# ═══════════════════════════════════════════
# Claude API 调用 (非流式)
# ═══════════════════════════════════════════

CLAUDE_SYSTEM_PROMPT = """你是一个专业的学术研究助手，擅长分析和总结学术文献。
你的回答应该：
1. 使用学术化的语言，但保持清晰易懂
2. 结构分明，使用标题分层
3. 引用文献时标注作者和年份
4. 客观评价，不过度褒贬
5. 指出研究局限性和未来方向"""


async def call_claude(
    messages: list[dict],
    system_prompt: str = CLAUDE_SYSTEM_PROMPT,
    max_tokens: int = 4000,
    temperature: float = 0.3,
) -> str:
    """调用 Claude API"""
    config = LLM_CONFIG.get("claude", {})
    api_key = config.get("api_key", "")
    model = config.get("model", "claude-sonnet-4-6")
    base_url = config.get("base_url", "https://api.anthropic.com")

    if not api_key:
        return "[错误] 未配置 CLAUDE_API_KEY，请在 backend/.env 中设置"

    # 构建 Anthropic 格式消息
    system_content = system_prompt
    formatted_messages = []
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        formatted_messages.append({"role": role, "content": content})

    payload = {
        "model": model,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "system": system_content,
        "messages": formatted_messages,
    }

    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{base_url}/v1/messages",
                json=payload,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=60),
            ) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    return f"[Claude API 错误 {resp.status}] {error_text}"

                data = await resp.json()
                # Claude 返回格式: content[0].text
                content_blocks = data.get("content", [])
                for block in content_blocks:
                    if block.get("type") == "text":
                        return block.get("text", "")
                return "[Claude 返回为空]"

    except Exception as e:
        return f"[Claude 调用异常] {str(e)}"

# ═══════════════════════════════════════════
# DeepSeek API 调用 (非流式)
# ═══════════════════════════════════════════

DEEPSEEK_SYSTEM_PROMPT = """你是一个专业的学术研究助手，擅长分析和总结学术文献。
请用学术化的中文回答，结构清晰，客观严谨。"""


async def call_deepseek(
    messages: list[dict],
    system_prompt: str = DEEPSEEK_SYSTEM_PROMPT,
    max_tokens: int = 4000,
    temperature: float = 0.3,
    provider: str = "deepseek",
) -> str:
    """调用 OpenAI 兼容 API（DeepSeek/OpenAI 等）"""
    config = LLM_CONFIG.get(provider, LLM_CONFIG.get("deepseek", {}))
    api_key = config.get("api_key", "")
    model = config.get("model", "deepseek-chat")
    base_url = config.get("base_url", "https://api.deepseek.com")

    if not api_key:
        env_name = f"{provider.upper()}_API_KEY"
        return f"[错误] 未配置 {env_name}，请在 backend/.env 中设置"

    request = build_openai_compatible_request(
        api_key,
        base_url,
        model,
        messages,
        system_prompt,
        max_tokens,
        temperature,
    )
    return await post_ai_request(request, config.get("name", provider.title()))

# ═══════════════════════════════════════════
# 统一 AI 调用
# ═══════════════════════════════════════════

async def call_ai(
    messages: list[dict],
    system_prompt: str = "",
    provider: str = "",
    max_tokens: int = 4000,
    temperature: float = 0.3,
) -> str:
    """统一 AI 调用，自动路由到可用的 provider"""
    provider = provider or DEFAULT_LLM

    if provider == "claude":
        return await call_claude(messages, system_prompt or CLAUDE_SYSTEM_PROMPT, max_tokens, temperature)
    elif provider == "deepseek":
        return await call_deepseek(messages, system_prompt or DEEPSEEK_SYSTEM_PROMPT, max_tokens, temperature)
    elif provider == "openai":
        return await call_deepseek(messages, system_prompt or DEEPSEEK_SYSTEM_PROMPT, max_tokens, temperature, "openai")
    else:
        # 默认尝试 deepseek (最便宜)
        return await call_deepseek(messages, system_prompt, max_tokens, temperature)

# ═══════════════════════════════════════════
# 文献总结专项函数
# ═══════════════════════════════════════════

SUMMARY_SYSTEM_PROMPT = """你是资深学术审稿人，请按以下结构总结文献：

## 研究背景与问题
（2-3句话说明研究背景和核心要解决的问题）

## 核心方法
（方法名称、关键创新点、技术路线）

## 主要发现
（关键实验结果和核心结论）

## 贡献与局限
（本文贡献 + 方法局限性）

## 与你研究的相关性
（这篇文献与你当前研究的相关程度及原因）

请用中文回答，保持学术严谨。"""


async def summarize_paper(paper_info: dict, user_context: str = "") -> str:
    """总结单篇文献"""
    content = f"""请总结以下学术文献：

**标题**: {paper_info.get('title', 'Unknown')}
**作者**: {paper_info.get('authors', 'Unknown')}
**年份**: {paper_info.get('year', 'Unknown')}
**来源**: {paper_info.get('source', 'Unknown')}
**摘要**: {paper_info.get('abstract', '无摘要')}

"""
    if user_context:
        content += f"**用户的研究方向**: {user_context}\n"

    content += "\n请按照结构化的方式总结此文献。"

    return await call_ai(
        messages=[{"role": "user", "content": content}],
        system_prompt=SUMMARY_SYSTEM_PROMPT,
        max_tokens=2000,
    )


async def summarize_multiple_papers(
    papers: list[dict],
    user_topic: str = "",
) -> str:
    """总结多篇文献，生成综述"""
    papers_text = ""
    for i, p in enumerate(papers, 1):
        papers_text += f"""{i}. **{p.get('title', 'Unknown')}**
   作者: {p.get('authors', 'Unknown')} ({p.get('year', '?')})
   来源: {p.get('source', 'Unknown')}
   摘要: {p.get('abstract', '无')[:300]}
   DOI: {p.get('doi', '')}
   URL: {p.get('url', '')}

"""

    content = f"""请基于以下 {len(papers)} 篇文献，写一份学术文献综述总结：

研究主题: {user_topic or '综合研究'}

文献列表：
{papers_text}

请按以下结构组织综述：
1. 研究趋势概述
2. 关键方法对比（含表格）
3. 核心发现汇总
4. 研究空白与未来方向
5. 各文献相关性评估

使用学术化中文，引用文献时用 [序号] 标注。"""

    return await call_ai(
        messages=[{"role": "user", "content": content}],
        system_prompt="你是资深学术综述撰写专家，擅长归纳总结多篇文献的核心内容。",
        max_tokens=4000,
    )


async def generate_project_knowledge_brief(
    papers: list[dict],
    user_topic: str = "",
) -> str:
    """Generate a project-level knowledge brief from selected papers."""
    papers_text = ""
    for i, p in enumerate(papers, 1):
        papers_text += f"""{i}. 标题: {p.get('title', 'Unknown')}
   作者: {p.get('authors', 'Unknown')} ({p.get('year', '?')})
   来源: {p.get('source', 'Unknown')}
   摘要: {(p.get('abstract') or p.get('abstract_text') or '无')[:900]}
   DOI: {p.get('doi', '')}
   URL: {p.get('url', '')}

"""

    content = f"""请把以下文献整理成一个“项目知识库精读报告”。

项目/领域主题: {user_topic or '用户当前研究主题'}

文献列表:
{papers_text}

请严格按以下结构输出，中文回答，避免空泛概括：

## 1. 项目知识地图
- 用 4-6 条 bullet 概括该领域的核心问题、主流方法和发展脉络。

## 2. 论文角色分工
- 把每篇论文归类为：奠基论文 / 方法论文 / 应用论文 / 综述论文 / 对比基线 / 其他。
- 说明它在项目知识库中的用途。

## 3. 方法与证据表
请给出 Markdown 表格，列为：论文、核心方法、数据/样本、关键指标或结论、局限性、与项目相关度。

## 4. 研究空白与机会
- 提炼 3-5 个可以继续阅读、实验或写作的切入点。

## 5. 下一步阅读队列
- 推荐下一批应该补充检索的关键词，中英文都给出。

如果某篇文献信息不足，请明确写“信息不足”，不要编造实验数据。"""

    return await call_ai(
        messages=[{"role": "user", "content": content}],
        system_prompt="你是严谨的科研项目知识库助手，擅长把多篇论文组织为可追问、可复用、可写综述的知识结构。信息不足时必须说明不足。",
        max_tokens=5000,
        temperature=0.2,
    )


# ═══════════════════════════════════════════
# Feature 10: 用户自定义 API 配置
# ═══════════════════════════════════════════

async def call_ai_with_custom_config(
    messages: list[dict],
    system_prompt: str = "",
    provider: str = "openai",
    api_key: str = "",
    base_url: str = "",
    model: str = "",
    max_tokens: int = 4000,
    temperature: float = 0.3,
) -> str:
    """
    使用用户自定义 API 配置调用 AI

    Args:
        provider: "openai"、"deepseek"、"claude" 或 "custom"
        api_key: 用户的 API Key
        base_url: 用户自定义 base_url (如 https://api.openai.com)
        model: 模型名称 (如 gpt-4o, deepseek-chat)
    """
    provider_config = normalize_custom_provider(provider, api_key, base_url, model)
    if not provider_config["api_key"]:
        return "[错误] 请先配置 API Key（在设置中填入 DeepSeek、ChatGPT、Claude 或自定义 API Key）"
    if not provider_config["base_url"] or not provider_config["model"]:
        return "[错误] 请填写 Base URL 和模型名称"

    request = build_custom_api_request(
        provider_config,
        messages,
        system_prompt,
        max_tokens,
        temperature,
    )
    return await post_ai_request(request, CUSTOM_PROVIDER_DEFAULTS.get(provider_config["id"], {}).get("name", "API"))


async def extract_key_info(paper_info: dict) -> dict:
    """提取文献关键信息索引"""
    content = f"""请从以下文献中提取关键信息，以 JSON 格式返回：

标题: {paper_info.get('title', 'Unknown')}
摘要: {paper_info.get('abstract', '无')}

请返回如下 JSON (只返回 JSON，不要其他文字):
{{
  "research_question": "研究问题 (1句话)",
  "core_method": "核心方法名称和简述",
  "key_findings": "关键发现 (1-2句话)",
  "dataset": "使用的数据集名称",
  "limitations": "局限性 (1句话)",
  "innovation": "创新点 (1句话)"
}}"""

    result = await call_ai(
        messages=[{"role": "user", "content": content}],
        system_prompt="你是学术文献分析专家，只返回要求的 JSON 格式。",
        max_tokens=1000,
        temperature=0.1,
    )

    # 尝试解析 JSON
    try:
        # 提取 JSON 部分
        import re
        json_match = re.search(r'\{[\s\S]*\}', result)
        if json_match:
            return json.loads(json_match.group())
    except Exception:
        pass

    return {
        "research_question": result,
        "core_method": "",
        "key_findings": "",
        "dataset": "",
        "limitations": "",
        "innovation": "",
    }
