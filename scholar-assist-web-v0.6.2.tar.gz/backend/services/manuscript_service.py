"""Persistent manuscript and version storage for the Web writing workspace."""
from __future__ import annotations

import json
import re
import sqlite3
import uuid

from services.library_service import connect_library_db, ensure_workspace


class ManuscriptNotFoundError(ValueError):
    pass


class ManuscriptConflictError(ValueError):
    pass


def _word_count(content: str) -> int:
    return len(re.findall(r"[\u3400-\u9fff]|[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)*", content or ""))


def _json_object(raw: str | None) -> dict:
    try:
        value = json.loads(raw or "{}")
        return value if isinstance(value, dict) else {}
    except (TypeError, json.JSONDecodeError):
        return {}


def init_manuscript_db(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS manuscripts (
            id TEXT PRIMARY KEY,
            workspace_id TEXT NOT NULL,
            title TEXT NOT NULL,
            content TEXT NOT NULL DEFAULT '',
            template_id TEXT NOT NULL DEFAULT 'master',
            paper_format_id TEXT NOT NULL DEFAULT 'degree',
            citation_format TEXT NOT NULL DEFAULT 'gbt7714',
            profile_json TEXT NOT NULL DEFAULT '{}',
            status TEXT NOT NULL DEFAULT 'draft',
            word_count INTEGER NOT NULL DEFAULT 0,
            revision INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
            updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
            FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_manuscripts_workspace_updated
        ON manuscripts(workspace_id, updated_at DESC);

        CREATE TABLE IF NOT EXISTS manuscript_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            manuscript_id TEXT NOT NULL,
            workspace_id TEXT NOT NULL,
            label TEXT NOT NULL,
            content TEXT NOT NULL,
            word_count INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
            FOREIGN KEY (manuscript_id) REFERENCES manuscripts(id) ON DELETE CASCADE,
            FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_manuscript_versions_manuscript_created
        ON manuscript_versions(manuscript_id, created_at DESC, id DESC);
        """
    )
    conn.commit()


def _connect() -> sqlite3.Connection:
    conn = connect_library_db()
    init_manuscript_db(conn)
    return conn


def _manuscript_from_row(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "workspace_id": row["workspace_id"],
        "title": row["title"],
        "content": row["content"],
        "template_id": row["template_id"],
        "paper_format_id": row["paper_format_id"],
        "citation_format": row["citation_format"],
        "profile": _json_object(row["profile_json"]),
        "status": row["status"],
        "word_count": int(row["word_count"] or 0),
        "revision": int(row["revision"] or 1),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def _version_from_row(row: sqlite3.Row) -> dict:
    return {
        "id": int(row["id"]),
        "manuscript_id": row["manuscript_id"],
        "workspace_id": row["workspace_id"],
        "label": row["label"],
        "content": row["content"],
        "word_count": int(row["word_count"] or 0),
        "created_at": row["created_at"],
    }


def create_manuscript(data: dict, workspace_id: str | None = None) -> dict:
    workspace_id = ensure_workspace(workspace_id)
    manuscript_id = f"ms_{uuid.uuid4().hex}"
    title = str(data.get("title") or "未命名论文").strip() or "未命名论文"
    content = str(data.get("content") or "")
    profile = data.get("profile") if isinstance(data.get("profile"), dict) else {}
    with _connect() as conn:
        conn.execute(
            """
            INSERT INTO manuscripts (
                id, workspace_id, title, content, template_id, paper_format_id,
                citation_format, profile_json, status, word_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                manuscript_id,
                workspace_id,
                title,
                content,
                str(data.get("template_id") or "master"),
                str(data.get("paper_format_id") or "degree"),
                str(data.get("citation_format") or "gbt7714"),
                json.dumps(profile, ensure_ascii=False),
                str(data.get("status") or "draft"),
                _word_count(content),
            ),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM manuscripts WHERE id = ?", (manuscript_id,)).fetchone()
        return _manuscript_from_row(row)


def list_manuscripts(workspace_id: str | None = None, include_archived: bool = False) -> list[dict]:
    workspace_id = ensure_workspace(workspace_id)
    with _connect() as conn:
        sql = "SELECT * FROM manuscripts WHERE workspace_id = ?"
        params: list[object] = [workspace_id]
        if not include_archived:
            sql += " AND status != ?"
            params.append("archived")
        sql += " ORDER BY updated_at DESC, created_at DESC"
        return [_manuscript_from_row(row) for row in conn.execute(sql, params).fetchall()]


def get_manuscript(manuscript_id: str, workspace_id: str | None = None) -> dict:
    workspace_id = ensure_workspace(workspace_id)
    with _connect() as conn:
        row = conn.execute(
            "SELECT * FROM manuscripts WHERE id = ? AND workspace_id = ?",
            (manuscript_id, workspace_id),
        ).fetchone()
        if not row:
            raise ManuscriptNotFoundError("manuscript not found")
        return _manuscript_from_row(row)


def update_manuscript(manuscript_id: str, data: dict, workspace_id: str | None = None) -> dict:
    workspace_id = ensure_workspace(workspace_id)
    with _connect() as conn:
        row = conn.execute(
            "SELECT * FROM manuscripts WHERE id = ? AND workspace_id = ?",
            (manuscript_id, workspace_id),
        ).fetchone()
        if not row:
            raise ManuscriptNotFoundError("manuscript not found")
        expected_revision = data.get("expected_revision")
        current_revision = int(row["revision"] or 1)
        if expected_revision is not None and int(expected_revision) != current_revision:
            raise ManuscriptConflictError("a newer revision already exists")

        title = str(data.get("title", row["title"]) or "未命名论文").strip() or "未命名论文"
        content = str(data.get("content", row["content"]) or "")
        profile = data.get("profile") if isinstance(data.get("profile"), dict) else _json_object(row["profile_json"])
        values = (
            title,
            content,
            str(data.get("template_id", row["template_id"]) or "master"),
            str(data.get("paper_format_id", row["paper_format_id"]) or "degree"),
            str(data.get("citation_format", row["citation_format"]) or "gbt7714"),
            json.dumps(profile, ensure_ascii=False),
            str(data.get("status", row["status"]) or "draft"),
            _word_count(content),
            current_revision + 1,
            manuscript_id,
            workspace_id,
            current_revision,
        )
        cursor = conn.execute(
            """
            UPDATE manuscripts
            SET title = ?, content = ?, template_id = ?, paper_format_id = ?,
                citation_format = ?, profile_json = ?, status = ?, word_count = ?,
                revision = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
            WHERE id = ? AND workspace_id = ? AND revision = ?
            """,
            values,
        )
        if cursor.rowcount != 1:
            raise ManuscriptConflictError("a newer revision already exists")
        conn.commit()
        updated = conn.execute("SELECT * FROM manuscripts WHERE id = ?", (manuscript_id,)).fetchone()
        return _manuscript_from_row(updated)


def archive_manuscript(manuscript_id: str, workspace_id: str | None = None) -> dict:
    current = get_manuscript(manuscript_id, workspace_id)
    return update_manuscript(
        manuscript_id,
        {"status": "archived", "expected_revision": current["revision"]},
        workspace_id,
    )


def create_manuscript_version(
    manuscript_id: str,
    label: str,
    content: str | None = None,
    workspace_id: str | None = None,
) -> dict:
    workspace_id = ensure_workspace(workspace_id)
    current = get_manuscript(manuscript_id, workspace_id)
    version_content = current["content"] if content is None else str(content)
    with _connect() as conn:
        cursor = conn.execute(
            """
            INSERT INTO manuscript_versions (manuscript_id, workspace_id, label, content, word_count)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                manuscript_id,
                workspace_id,
                (label or "手动保存").strip() or "手动保存",
                version_content,
                _word_count(version_content),
            ),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM manuscript_versions WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return _version_from_row(row)


def list_manuscript_versions(manuscript_id: str, workspace_id: str | None = None) -> list[dict]:
    workspace_id = ensure_workspace(workspace_id)
    get_manuscript(manuscript_id, workspace_id)
    with _connect() as conn:
        rows = conn.execute(
            """
            SELECT * FROM manuscript_versions
            WHERE manuscript_id = ? AND workspace_id = ?
            ORDER BY created_at DESC, id DESC
            """,
            (manuscript_id, workspace_id),
        ).fetchall()
        return [_version_from_row(row) for row in rows]


def restore_manuscript_version(
    manuscript_id: str,
    version_id: int,
    expected_revision: int | None,
    workspace_id: str | None = None,
) -> dict:
    workspace_id = ensure_workspace(workspace_id)
    current = get_manuscript(manuscript_id, workspace_id)
    if expected_revision is not None and current["revision"] != int(expected_revision):
        raise ManuscriptConflictError("a newer revision already exists")
    with _connect() as conn:
        row = conn.execute(
            """
            SELECT * FROM manuscript_versions
            WHERE id = ? AND manuscript_id = ? AND workspace_id = ?
            """,
            (version_id, manuscript_id, workspace_id),
        ).fetchone()
        if not row:
            raise ManuscriptNotFoundError("manuscript version not found")
        version = _version_from_row(row)
    create_manuscript_version(manuscript_id, "Before restoring version", current["content"], workspace_id)
    return update_manuscript(
        manuscript_id,
        {"content": version["content"], "expected_revision": current["revision"]},
        workspace_id,
    )


def list_workspace_versions(workspace_id: str | None = None) -> list[dict]:
    workspace_id = ensure_workspace(workspace_id)
    with _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM manuscript_versions WHERE workspace_id = ? ORDER BY created_at DESC, id DESC",
            (workspace_id,),
        ).fetchall()
        return [_version_from_row(row) for row in rows]

