"""Local evidence indexing and hybrid retrieval for grounded literature QA."""
from __future__ import annotations

import math
import re
import json
import hashlib
from collections import Counter
from pathlib import Path
import requests


VECTOR_SIZE = 384


def stable_token_bucket(token: str) -> int:
    """Map a token to a stable vector bucket across Python processes."""
    digest = hashlib.sha256((token or "").encode("utf-8")).hexdigest()
    return int(digest[:12], 16) % VECTOR_SIZE


def tokenize(text: str) -> list[str]:
    """Tokenize mixed Chinese/English academic text without external dependencies."""
    lowered = (text or "").lower()
    latin = re.findall(r"[a-z][a-z0-9_+\-]{1,}", lowered)
    chinese_chars = re.findall(r"[\u4e00-\u9fff]", lowered)
    chinese_bigrams = ["".join(chinese_chars[i:i + 2]) for i in range(max(0, len(chinese_chars) - 1))]
    return [token for token in [*latin, *chinese_bigrams] if len(token.strip()) > 1]


def _chunk_text(text: str, max_chars: int = 900, overlap: int = 120) -> list[str]:
    compact = " ".join((text or "").split())
    if not compact:
        return []
    chunks = []
    start = 0
    while start < len(compact):
        end = min(len(compact), start + max_chars)
        chunks.append(compact[start:end])
        if end >= len(compact):
            break
        start = max(0, end - overlap)
    return chunks


def _hash_vector(tokens: list[str], idf: dict[str, float]) -> dict[int, float]:
    counts = Counter(tokens)
    vector: dict[int, float] = {}
    for token, count in counts.items():
        bucket = stable_token_bucket(token)
        vector[bucket] = vector.get(bucket, 0.0) + (1.0 + math.log(count)) * idf.get(token, 1.0)
    norm = math.sqrt(sum(value * value for value in vector.values()))
    if norm:
        vector = {key: value / norm for key, value in vector.items()}
    return vector


def normalize_dense_vector(values: list[float]) -> dict[int, float]:
    """Normalize a dense provider embedding into the sparse vector shape used by retrieval."""
    vector = {index: float(value) for index, value in enumerate(values or []) if float(value) != 0.0}
    norm = math.sqrt(sum(value * value for value in vector.values()))
    if norm:
        vector = {key: value / norm for key, value in vector.items()}
    return vector


def embed_texts_with_openai_compatible(
    texts: list[str],
    api_key: str = "",
    base_url: str = "https://api.openai.com/v1",
    model: str = "text-embedding-3-small",
    timeout: int = 30,
) -> list[dict[int, float]]:
    """Call an OpenAI-compatible embeddings endpoint and normalize vectors.

    The app keeps the local hash index as the default free fallback; this helper
    is only used when a caller explicitly supplies an embedding provider.
    """
    clean_texts = [text for text in texts if text]
    if not clean_texts or not api_key.strip():
        return []
    endpoint = base_url.rstrip("/")
    if not endpoint.endswith("/embeddings"):
        endpoint = f"{endpoint}/embeddings"
    response = requests.post(
        endpoint,
        headers={"Authorization": f"Bearer {api_key.strip()}", "Content-Type": "application/json"},
        json={"model": model, "input": clean_texts},
        timeout=timeout,
    )
    response.raise_for_status()
    data = response.json().get("data", [])
    return [normalize_dense_vector(item.get("embedding", [])) for item in data]


def _cosine(a: dict[int, float], b: dict[int, float]) -> float:
    if not a or not b:
        return 0.0
    small, large = (a, b) if len(a) < len(b) else (b, a)
    return sum(value * large.get(key, 0.0) for key, value in small.items())


def build_evidence_chunks(papers: list[dict]) -> list[dict]:
    """Flatten papers into page-aware chunks suitable for local retrieval."""
    chunks: list[dict] = []
    for paper_index, paper in enumerate(papers, 1):
        base = {
            "paper_index": paper_index,
            "paper_id": paper.get("id", ""),
            "title": paper.get("title", "Unknown"),
            "year": paper.get("year", "n.d."),
            "citation_key": paper.get("citation_key", ""),
        }
        sources = [
            {"kind": "abstract", "page": 0, "text": paper.get("abstract") or paper.get("abstract_text") or ""},
            {"kind": "notes", "page": 0, "text": paper.get("notes") or ""},
        ]
        for segment in paper.get("page_segments", []) or []:
            sources.append({"kind": "pdf", "page": segment.get("page", 0), "text": segment.get("text", "")})
        for source in sources:
            for chunk_index, chunk in enumerate(_chunk_text(source.get("text", "")), 1):
                chunks.append({
                    **base,
                    "chunk_id": f"P{paper_index}-{source['kind']}-{source.get('page', 0)}-{chunk_index}",
                    "kind": source["kind"],
                    "page": source.get("page", 0),
                    "text": chunk,
                    "tokens": tokenize(chunk),
                })
    return chunks


def build_evidence_index(papers: list[dict], embedding_vectors: list[list[float]] | list[dict[int, float]] | None = None) -> dict:
    """Build an in-memory evidence index with provider embeddings or hashed TF-IDF fallback."""
    chunks = build_evidence_chunks(papers)
    doc_freq: Counter[str] = Counter()
    for chunk in chunks:
        doc_freq.update(set(chunk["tokens"]))
    total = max(1, len(chunks))
    idf = {
        token: math.log((1 + total) / (1 + freq)) + 1.0
        for token, freq in doc_freq.items()
    }
    use_external_embeddings = bool(embedding_vectors) and len(embedding_vectors or []) == len(chunks)
    for index, chunk in enumerate(chunks):
        if use_external_embeddings:
            raw_vector = (embedding_vectors or [])[index]
            chunk["vector"] = raw_vector if isinstance(raw_vector, dict) else normalize_dense_vector(raw_vector)
            chunk["vector_mode"] = "external_embedding"
        else:
            chunk["vector"] = _hash_vector(chunk["tokens"], idf)
            chunk["vector_mode"] = "hash_tfidf"
    return {
        "chunks": chunks,
        "idf": idf,
        "stats": {
            "papers": len(papers),
            "chunks": len(chunks),
            "tokens": sum(len(chunk["tokens"]) for chunk in chunks),
            "vector_mode": "external_embedding" if use_external_embeddings else "hash_tfidf",
        },
    }


def _index_base_dir(base_dir: str | Path | None = None) -> Path:
    root = Path(base_dir) if base_dir else Path.home() / ".scholar-assist" / "evidence-index"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _safe_project_id(project_id: str) -> str:
    clean = re.sub(r"[^a-zA-Z0-9_\-\u4e00-\u9fff]+", "-", project_id or "default").strip("-")
    return clean or "default"


def persist_evidence_index(
    project_id: str,
    papers: list[dict],
    base_dir: str | Path | None = None,
    embedding_vectors: list[list[float]] | list[dict[int, float]] | None = None,
) -> dict:
    """Build and persist a project evidence index for reuse after restart."""
    index = build_evidence_index(papers, embedding_vectors=embedding_vectors)
    target = _index_base_dir(base_dir) / f"{_safe_project_id(project_id)}.json"
    serializable_chunks = []
    for chunk in index["chunks"]:
        serializable_chunks.append({
            **chunk,
            "vector": {str(key): value for key, value in chunk.get("vector", {}).items()},
        })
    payload = {
        "version": 1,
        "project_id": project_id or "default",
        "vector_size": VECTOR_SIZE,
        "idf": index["idf"],
        "stats": index["stats"],
        "chunks": serializable_chunks,
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return {**payload, "path": str(target)}


def load_persisted_evidence_index(project_id: str, base_dir: str | Path | None = None) -> dict:
    """Load a persisted evidence index and restore sparse vector keys."""
    target = _index_base_dir(base_dir) / f"{_safe_project_id(project_id)}.json"
    if not target.exists():
        return {"version": 1, "project_id": project_id or "default", "vector_size": VECTOR_SIZE, "idf": {}, "stats": {"papers": 0, "chunks": 0, "tokens": 0}, "chunks": [], "path": str(target)}
    payload = json.loads(target.read_text(encoding="utf-8"))
    chunks = []
    for chunk in payload.get("chunks", []):
        chunks.append({
            **chunk,
            "vector": {int(key): value for key, value in (chunk.get("vector") or {}).items()},
        })
    payload["chunks"] = chunks
    payload["path"] = str(target)
    return payload


def _search_built_evidence_index(
    question: str,
    index: dict,
    limit: int = 10,
    candidate_limit: int = 40,
    semantic_weight: float = 0.65,
    diversity: float = 0.25,
) -> list[dict]:
    """Retrieve evidence from an already built or reloaded index."""
    chunks = index["chunks"]
    query_tokens = tokenize(question)
    query_vector = _hash_vector(query_tokens, index["idf"])
    query_terms = set(query_tokens)
    if not chunks:
        return []

    candidates = []
    for chunk in chunks:
        token_set = set(chunk["tokens"])
        lexical = len(query_terms & token_set) / max(1, len(query_terms))
        semantic = _cosine(query_vector, chunk["vector"])
        source_bonus = 0.08 if chunk["kind"] == "pdf" else 0.03 if chunk["kind"] == "notes" else 0.0
        score = semantic_weight * semantic + (1 - semantic_weight) * lexical + source_bonus
        if score <= 0:
            continue
        candidates.append({
            **{key: value for key, value in chunk.items() if key not in {"tokens", "vector"}},
            "semantic_score": round(semantic, 4),
            "keyword_score": round(lexical, 4),
            "score": round(score, 4),
            "_vector": chunk["vector"],
        })

    candidates.sort(key=lambda item: item["score"], reverse=True)
    pool = candidates[:max(limit, candidate_limit)]
    selected: list[dict] = []
    while pool and len(selected) < limit:
        best_index = 0
        best_score = -1e9
        for index_pos, candidate in enumerate(pool):
            max_similarity = max((_cosine(candidate["_vector"], chosen["_vector"]) for chosen in selected), default=0.0)
            rerank_score = (1 - diversity) * candidate["score"] - diversity * max_similarity
            if rerank_score > best_score:
                best_score = rerank_score
                best_index = index_pos
        selected.append(pool.pop(best_index))

    cards = []
    for index_pos, card in enumerate(selected, 1):
        cards.append({
            "id": f"E{index_pos}",
            "paper_index": card["paper_index"],
            "paper_id": card["paper_id"],
            "title": card["title"],
            "year": card["year"],
            "kind": card["kind"],
            "page": card["page"],
            "chunk_id": card["chunk_id"],
            "score": card["score"],
            "semantic_score": card["semantic_score"],
            "keyword_score": card["keyword_score"],
            "text": card["text"],
            "citation_key": card["citation_key"],
        })
    return cards


def search_evidence_cards(
    question: str,
    papers: list[dict],
    limit: int = 10,
    candidate_limit: int = 40,
    semantic_weight: float = 0.65,
    diversity: float = 0.25,
) -> list[dict]:
    """Retrieve evidence with hybrid lexical/vector scoring and MMR reranking."""
    return _search_built_evidence_index(
        question,
        build_evidence_index(papers),
        limit=limit,
        candidate_limit=candidate_limit,
        semantic_weight=semantic_weight,
        diversity=diversity,
    )


def search_persisted_evidence_cards(
    question: str,
    project_id: str,
    limit: int = 10,
    candidate_limit: int = 40,
    semantic_weight: float = 0.65,
    diversity: float = 0.25,
    base_dir: str | Path | None = None,
) -> tuple[list[dict], dict]:
    """Search a project index loaded from disk without rebuilding it from UI data."""
    index = load_persisted_evidence_index(project_id, base_dir)
    cards = _search_built_evidence_index(
        question,
        index,
        limit=limit,
        candidate_limit=candidate_limit,
        semantic_weight=semantic_weight,
        diversity=diversity,
    )
    return cards, index.get("stats", {"papers": 0, "chunks": 0, "tokens": 0})


def build_evidence_gap_report(question: str, papers: list[dict]) -> dict:
    """Return a user-actionable refusal payload when retrieval finds no evidence."""
    query_tokens = tokenize(question)
    title_terms = []
    for paper in papers[:6]:
        title = str(paper.get("title") or "").strip()
        if title:
            title_terms.append(title[:48])
    suggested = []
    if query_tokens:
        suggested.append(" ".join(query_tokens[:6]))
    suggested.extend(title_terms[:3])
    suggested = [item for index, item in enumerate(suggested) if item and item not in suggested[:index]][:5]
    return {
        "status": "insufficient_evidence",
        "refusal": (
            "当前项目库没有检索到能支撑这个问题的证据。为了避免编造作者、数据、页码或结论，"
            "本次不会生成论文段落。请先导入相关 PDF、补全文献摘要/笔记，或换一个更贴近项目库的检索问题。"
        ),
        "missing_evidence": [
            "至少 1 条带摘要、PDF 页码片段或阅读笔记的文献证据",
            "可追溯的 citation_key 或 PDF 页码",
            "与当前章节问题直接相关的方法、结果或局限描述",
        ],
        "suggested_queries": suggested or ["补充当前章节关键词", "导入 PDF 后重建证据索引"],
    }


def build_answer_with_citations_prompt(question: str, papers: list[dict], limit: int = 10) -> dict:
    """Build a PaperQA-style prompt using retrieved and reranked evidence."""
    cards = search_evidence_cards(question, papers, limit)
    stats = build_evidence_index(papers)["stats"]
    if not cards:
        gap = build_evidence_gap_report(question, papers)
        prompt = (
            "证据不足，禁止生成论文结论。\n"
            f"问题：{question}\n"
            f"原因：{gap['refusal']}\n"
            "请向用户返回缺证据清单和建议检索词，不要编造任何段落。"
        )
        return {
            "prompt": prompt,
            "evidence": [],
            "index_stats": stats,
            **gap,
        }
    evidence = []
    for card in cards:
        page = f"，第 {card['page']} 页" if card.get("page") else ""
        key = f" [@{card['citation_key']}]" if card.get("citation_key") else ""
        evidence.append(
            f"{card['id']}. {card['title']} ({card['year']}){page}{key}\n"
            f"来源：{card['kind']} · score={card['score']} · semantic={card['semantic_score']} · keyword={card['keyword_score']}\n"
            f"证据：{card['text']}"
        )
    prompt = (
        "请像严谨的文献问答系统一样回答问题。\n"
        "规则：\n"
        "1. 只能使用 Evidence 中的信息。\n"
        "2. 每个关键结论后标注证据编号，例如 [E1]；有 citation_key 时保留 Pandoc 引用。\n"
        "3. 区分事实、推断和证据不足；不要编造作者、数据、页码或实验结论。\n"
        "4. 最后输出“证据列表”，列出使用了哪些证据编号。\n\n"
        f"问题：{question}\n\n"
        "Evidence:\n" + ("\n\n".join(evidence) if evidence else "没有检索到可用证据。")
    )
    return {
        "prompt": prompt,
        "evidence": cards,
        "index_stats": stats,
        "status": "ready",
        "refusal": "",
        "missing_evidence": [],
        "suggested_queries": [],
    }


def _first_sentence(text: str, max_chars: int = 180) -> str:
    compact = " ".join((text or "").split())
    if not compact:
        return ""
    parts = re.split(r"(?<=[。！？.!?])\s+", compact)
    sentence = parts[0] if parts else compact
    return sentence[:max_chars].rstrip()


def build_traceable_knowledge_answer(question: str, papers: list[dict], limit: int = 8) -> dict:
    """Return a PaperQA-like answer contract with explicit provenance.

    This intentionally produces a conservative evidence-linked answer skeleton,
    not an ungrounded final essay. A downstream LLM can polish it, but every
    claim remains tied to evidence ids.
    """
    prompt_payload = build_answer_with_citations_prompt(question, papers, limit)
    if prompt_payload.get("status") == "insufficient_evidence":
        return {
            **prompt_payload,
            "answer_markdown": "证据不足：当前项目库没有可追溯材料支撑该问题，因此不会生成结论性回答。",
            "claims": [],
            "provenance_map": {},
            "citation_keys": [],
            "next_actions": prompt_payload.get("suggested_queries", []),
        }

    cards = prompt_payload.get("evidence", [])
    claims = []
    lines = [
        f"### 可追溯回答：{question}",
        "",
        "以下结论只基于当前项目库证据生成；需要正式写入论文时，应再由用户核对原文页码。",
    ]
    provenance_map = {}
    citation_keys = []
    for card in cards[: min(limit, 5)]:
        evidence_id = card.get("id", "")
        citation_key = str(card.get("citation_key") or "").strip()
        citation = f" [@{citation_key}]" if citation_key else ""
        if citation_key:
            citation_keys.append(f"@{citation_key}")
        claim_text = _first_sentence(card.get("text", "")) or "该证据包含与问题相关的信息。"
        claims.append({
            "claim": claim_text,
            "evidence_ids": [evidence_id],
            "confidence": "medium" if card.get("score", 0) < 0.45 else "high",
            "citation": citation.strip(),
        })
        lines.append(f"- {claim_text} [{evidence_id}]{citation}")
        provenance_map[evidence_id] = {
            "paper_id": card.get("paper_id", ""),
            "title": card.get("title", ""),
            "year": card.get("year", "n.d."),
            "kind": card.get("kind", ""),
            "page": card.get("page", 0),
            "chunk_id": card.get("chunk_id", ""),
            "score": card.get("score", 0),
            "text": card.get("text", ""),
            "citation_key": citation_key,
        }

    lines.extend([
        "",
        "### 证据列表",
        *[
            f"- [{card.get('id')}] {card.get('title')} ({card.get('year')})"
            + (f"，第 {card.get('page')} 页" if card.get("page") else "")
            for card in cards[: min(limit, 5)]
        ],
        "",
        "### 仍需核对",
        "- 检查每条证据的原文页码、实验条件和数据范围。",
        "- 如果要写入论文正文，需要把证据转换为所在学校/期刊要求的引用格式。",
    ])
    return {
        **prompt_payload,
        "answer_markdown": "\n".join(lines),
        "claims": claims,
        "provenance_map": provenance_map,
        "citation_keys": list(dict.fromkeys(citation_keys)),
        "next_actions": [
            "打开证据页码核对原文",
            "把高置信 claims 插入对应章节",
            "对低置信 claims 补充 PDF 或阅读笔记",
        ],
    }
