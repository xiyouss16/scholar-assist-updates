"""
Feature 1+8+9: 学术搜索引擎对接
— 搜索分类 (作者/期刊/标题/概述)
— 中英文自动双搜索
— 中断支持 (通过 asyncio 取消)
"""
from __future__ import annotations
import asyncio
import time
import re
import os
from typing import Optional
from dataclasses import dataclass, field
import requests
from scholarly import scholarly, ProxyGenerator
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

# ═══════════════════════════════════════════
# 数据模型
# ═══════════════════════════════════════════

@dataclass
class PaperResult:
    id: str
    title: str
    authors: str
    year: int
    source: str
    abstract: str
    url: str
    doi: str = ""
    citations: int = 0
    relevance: int = 0
    keywords: list = field(default_factory=list)
    source_engine: str = ""
    search_language: str = ""  # "zh" | "en" | "both"

# ═══════════════════════════════════════════
# 中英文检测 & 翻译
# ═══════════════════════════════════════════

def contains_chinese(text: str) -> bool:
    """检测文本是否包含中文"""
    return bool(re.search(r'[一-鿿]', text))

def contains_english(text: str) -> bool:
    """检测文本是否包含英文"""
    return bool(re.search(r'[a-zA-Z]', text))

def extract_english_terms(text: str) -> str:
    """从中文文本中提取英文术语（括号内的英文）"""
    # 提取括号内的英文: 如 "Transformer (自注意力机制)" → "Transformer"
    english_terms = re.findall(r'\b([A-Z][a-zA-Z]+(?:[\s-][A-Z][a-zA-Z]+)*)\b', text)
    return " ".join(english_terms)

def build_dual_query(original_query: str) -> list[tuple[str, str]]:
    """
    根据输入构建中英文查询列表
    返回 [(query, lang), ...]
    """
    queries = []
    has_cn = contains_chinese(original_query)
    has_en = contains_english(original_query)

    if has_cn and has_en:
        # 混合输入：直接用原查询 + 提取英文术语单独搜索
        queries.append((original_query, "zh"))
        eng_terms = extract_english_terms(original_query)
        if eng_terms:
            queries.append((eng_terms, "en"))
    elif has_cn:
        # 纯中文：用原查询 + 提取英文术语
        queries.append((original_query, "zh"))
        eng_terms = extract_english_terms(original_query)
        if eng_terms:
            queries.append((eng_terms, "en"))
        # 也试试用原中文查询直接搜英文数据库（有些引擎支持中文搜索）
        queries.append((original_query, "en"))
    else:
        # 纯英文或其他语言
        queries.append((original_query, "en"))

    return queries

# ═══════════════════════════════════════════
# 搜索分类：构建分类查询
# ═══════════════════════════════════════════

SearchCategory = str  # "all" | "title" | "author" | "journal" | "abstract"

def build_categorized_query(query: str, category: SearchCategory) -> str:
    """根据搜索分类构建特定格式的查询"""
    if category == "all" or category == "title":
        return query  # 标题搜索直接用原查询
    elif category == "author":
        # 作者搜索：添加 author: 前缀
        return f"author:{query}"
    elif category == "journal":
        return f"journal:{query}"
    elif category == "abstract":
        return f"abstract:{query}"
    return query

# ═══════════════════════════════════════════
# Semantic Scholar API
# ═══════════════════════════════════════════

SEMANTIC_SCHOLAR_URL = "https://api.semanticscholar.org/graph/v1/paper/search"

# Semantic Scholar 支持的高级搜索字段
SS_FIELD_MAP = {
    "title": "title",
    "author": "author",
    "journal": "journal",
    "abstract": "abstract",
    "all": "",
}

async def search_semantic_scholar(
    query: str,
    limit: int = 20,
    category: SearchCategory = "all",
    search_lang: str = "en"
) -> list[PaperResult]:
    """通过 Semantic Scholar API 搜索论文"""
    results = []
    try:
        # 根据分类选择搜索策略
        if category == "author":
            # 使用 author search endpoint
            url = "https://api.semanticscholar.org/graph/v1/author/search"
            params = {
                "query": query,
                "limit": min(limit, 50),
                "fields": "name,affiliations,paperCount,hIndex"
            }
            resp = requests.get(url, params=params, headers={"User-Agent": "ScholarAssist/1.0"}, timeout=15)
            resp.raise_for_status()
            data = resp.json()
            # 获取作者的论文
            author_ids = [a.get("authorId", "") for a in data.get("data", [])[:3] if a.get("authorId")]
            for aid in author_ids:
                papers_url = f"https://api.semanticscholar.org/graph/v1/author/{aid}/papers"
                papers_params = {"limit": min(limit // len(author_ids), 20),
                                 "fields": "title,authors,year,abstract,url,externalIds,citationCount,journal"}
                try:
                    papers_resp = requests.get(papers_url, params=papers_params, headers={"User-Agent": "ScholarAssist/1.0"}, timeout=10)
                    papers_resp.raise_for_status()
                    papers_data = papers_resp.json()
                    for j, paper in enumerate(papers_data.get("data", [])):
                        results.append(_parse_ss_paper(paper, j, search_lang))
                except Exception:
                    continue
        else:
            # 标准关键词搜索
            if category == "journal":
                q = f"{query}"  # Semantic Scholar 自动处理期刊匹配
            else:
                q = query

            params = {
                "query": q,
                "limit": min(limit, 100),
                "fields": "title,authors,year,abstract,url,externalIds,citationCount,journal,publicationTypes"
            }
            resp = requests.get(SEMANTIC_SCHOLAR_URL, params=params,
                              headers={"User-Agent": "ScholarAssist/1.0"}, timeout=15)
            resp.raise_for_status()
            data = resp.json()

            for i, paper in enumerate(data.get("data", [])):
                results.append(_parse_ss_paper(paper, i, search_lang))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[Semantic Scholar] 搜索出错: {e}")
    return results

def _parse_ss_paper(paper: dict, index: int, search_lang: str = "en") -> PaperResult:
    """解析 Semantic Scholar 论文数据"""
    authors_list = paper.get("authors", [])
    author_names = ", ".join([a.get("name", "") for a in authors_list[:5]])
    if len(authors_list) > 5:
        author_names += " et al."

    ext_ids = paper.get("externalIds", {})
    doi = ext_ids.get("DOI", "")
    paper_url = paper.get("url", "")
    if not paper_url and doi:
        paper_url = f"https://doi.org/{doi}"

    journal = paper.get("journal", {})
    source = journal.get("name", "") if journal else (paper.get("publicationTypes", [""])[0] if paper.get("publicationTypes") else "Unknown")

    return PaperResult(
        id=f"ss_{paper.get('paperId', index)}",
        title=paper.get("title", "Unknown Title"),
        authors=author_names,
        year=paper.get("year", 0) or 0,
        source=source or "Unknown",
        abstract=paper.get("abstract", "") or "",
        url=paper_url,
        doi=doi,
        citations=paper.get("citationCount", 0) or 0,
        keywords=paper.get("publicationTypes", []) or [],
        relevance=100 - index * 2,
        source_engine="Semantic Scholar",
        search_language=search_lang,
    )


def _safe_int(value, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _normalize_doi(doi: str) -> str:
    return (doi or "").replace("https://doi.org/", "").replace("http://doi.org/", "").strip()


def _abstract_from_inverted_index(index: dict) -> str:
    if not index:
        return ""
    positioned_words = []
    for word, positions in index.items():
        for pos in positions:
            positioned_words.append((pos, word))
    return " ".join(word for _, word in sorted(positioned_words))


def _engine_id(prefix: str, raw_id: str | int) -> str:
    safe = re.sub(r"[^a-zA-Z0-9_-]+", "_", str(raw_id)).strip("_")
    return f"{prefix}_{safe or 'unknown'}"


# ═══════════════════════════════════════════
# OpenAlex API
# ═══════════════════════════════════════════

async def search_openalex(
    query: str,
    limit: int = 20,
    category: SearchCategory = "all",
    search_lang: str = "en",
) -> list[PaperResult]:
    results = []
    try:
        params = {
            "search": query,
            "per-page": min(limit, 50),
            "mailto": os.getenv("OPENALEX_MAILTO", "scholar-assist@example.com"),
        }
        if category == "title":
            params["filter"] = f"title.search:{query}"
            params.pop("search", None)
        elif category == "author":
            params["filter"] = f"authorships.author.display_name.search:{query}"
            params.pop("search", None)
        elif category == "journal":
            params["filter"] = f"primary_location.source.display_name.search:{query}"
            params.pop("search", None)

        resp = requests.get("https://api.openalex.org/works", params=params, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        for i, item in enumerate(data.get("results", [])[:limit]):
            results.append(_parse_openalex_work(item, i, search_lang))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[OpenAlex] 搜索出错: {e}")
    return results


def _parse_openalex_work(work: dict, index: int, search_lang: str = "en") -> PaperResult:
    authors = []
    for authorship in work.get("authorships", [])[:5]:
        name = authorship.get("author", {}).get("display_name", "")
        if name:
            authors.append(name)
    author_names = ", ".join(authors)
    if len(work.get("authorships", [])) > 5:
        author_names += " et al."

    primary_location = work.get("primary_location") or {}
    source = (primary_location.get("source") or {}).get("display_name", "") or "OpenAlex"
    doi = _normalize_doi(work.get("doi", ""))
    url = primary_location.get("landing_page_url") or (f"https://doi.org/{doi}" if doi else work.get("id", ""))
    raw_id = str(work.get("id", index)).split("/")[-1]

    return PaperResult(
        id=_engine_id("openalex", raw_id),
        title=work.get("display_name", "Unknown Title"),
        authors=author_names,
        year=_safe_int(work.get("publication_year")),
        source=source,
        abstract=_abstract_from_inverted_index(work.get("abstract_inverted_index", {}))[:1200],
        url=url,
        doi=doi,
        citations=_safe_int(work.get("cited_by_count")),
        relevance=96 - index * 2,
        keywords=[c.get("display_name", "") for c in work.get("concepts", [])[:5] if c.get("display_name")],
        source_engine="OpenAlex",
        search_language=search_lang,
    )


# ═══════════════════════════════════════════
# PubMed API
# ═══════════════════════════════════════════

async def search_pubmed(
    query: str,
    limit: int = 20,
    category: SearchCategory = "all",
    search_lang: str = "en",
) -> list[PaperResult]:
    results = []
    try:
        term = query
        if category == "title":
            term = f"{query}[Title]"
        elif category == "author":
            term = f"{query}[Author]"
        elif category == "journal":
            term = f"{query}[Journal]"

        search_resp = requests.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
            params={"db": "pubmed", "term": term, "retmode": "json", "retmax": min(limit, 50)},
            timeout=15,
        )
        search_resp.raise_for_status()
        ids = search_resp.json().get("esearchresult", {}).get("idlist", [])
        if not ids:
            return results

        summary_resp = requests.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi",
            params={"db": "pubmed", "id": ",".join(ids), "retmode": "json"},
            timeout=15,
        )
        summary_resp.raise_for_status()
        data = summary_resp.json().get("result", {})
        for i, pmid in enumerate(ids[:limit]):
            item = data.get(pmid)
            if item:
                results.append(_parse_pubmed_summary(pmid, item, i, search_lang))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[PubMed] 搜索出错: {e}")
    return results


def _parse_pubmed_summary(pmid: str, item: dict, index: int, search_lang: str = "en") -> PaperResult:
    authors = ", ".join([a.get("name", "") for a in item.get("authors", [])[:5] if a.get("name")])
    if len(item.get("authors", [])) > 5:
        authors += " et al."
    doi = ""
    for article_id in item.get("articleids", []):
        if article_id.get("idtype") == "doi":
            doi = article_id.get("value", "")
            break
    year_match = re.search(r"\d{4}", item.get("sortpubdate", "") or item.get("pubdate", ""))

    return PaperResult(
        id=f"pubmed_{pmid}",
        title=item.get("title", "Unknown Title"),
        authors=authors,
        year=_safe_int(year_match.group(0) if year_match else 0),
        source=item.get("fulljournalname", "") or item.get("source", "") or "PubMed",
        abstract="",
        url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
        doi=doi,
        citations=0,
        relevance=92 - index * 2,
        keywords=["医学", "PubMed"],
        source_engine="PubMed",
        search_language=search_lang,
    )

# ═══════════════════════════════════════════
# arXiv API
# ═══════════════════════════════════════════

async def search_arxiv(
    query: str,
    limit: int = 20,
    category: SearchCategory = "all",
    search_lang: str = "en"
) -> list[PaperResult]:
    """通过 arXiv API 搜索论文（支持分类搜索）"""
    results = []
    try:
        import urllib.parse
        import xml.etree.ElementTree as ET

        # 根据分类构建搜索查询
        if category == "author":
            search_field = "au"
        elif category == "title":
            search_field = "ti"
        elif category == "abstract":
            search_field = "abs"
        elif category == "journal":
            search_field = "jr"
        else:
            search_field = "all"

        encoded_query = urllib.parse.quote(query)
        url = (f"http://export.arxiv.org/api/query?"
               f"search_query={search_field}:{encoded_query}&start=0&max_results={min(limit, 30)}&sortBy=relevance")
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()

        ns = {"atom": "http://www.w3.org/2005/Atom", "arxiv": "http://arxiv.org/schemas/atom"}
        root = ET.fromstring(resp.text)
        entries = root.findall("atom:entry", ns)

        for i, entry in enumerate(entries[:limit]):
            title = entry.find("atom:title", ns)
            title_text = " ".join((title.text or "").split()) if title is not None else "Unknown"

            authors_list = entry.findall("atom:author/atom:name", ns)
            author_names = ", ".join([a.text for a in authors_list[:5] if a.text])
            if len(authors_list) > 5:
                author_names += " et al."

            summary = entry.find("atom:summary", ns)
            abstract = " ".join((summary.text or "").split()[:500]) if summary is not None else ""

            paper_url = ""
            for link in entry.findall("atom:link", ns):
                if link.attrib.get("rel") == "alternate":
                    paper_url = link.attrib.get("href", "")

            published = entry.find("atom:published", ns)
            year = int((published.text or "2000")[:4]) if published is not None else 2000

            results.append(PaperResult(
                id=f"arxiv_{i}",
                title=title_text,
                authors=author_names,
                year=year,
                source="arXiv",
                abstract=abstract,
                url=paper_url,
                relevance=98 - i * 2,
                keywords=[],
                source_engine="arXiv",
                search_language=search_lang,
            ))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[arXiv] 搜索出错: {e}")
    return results

# ═══════════════════════════════════════════
# Google Scholar
# ═══════════════════════════════════════════

async def search_google_scholar(
    query: str,
    limit: int = 10,
    category: SearchCategory = "all",
    search_lang: str = "en"
) -> list[PaperResult]:
    """
    通过 SERP API 搜索 Google Scholar

    Google Scholar 没有官方开放 API，直接抓取容易超时、触发验证码或封 IP。
    生产使用时请配置 SERPAPI_KEY 或 SEARCHAPI_KEY。旧 scholarly 抓取仅在
    GOOGLE_SCHOLAR_SCRAPER_FALLBACK=1 时启用，避免默认搜索卡住。
    """
    serpapi_key = os.getenv("SERPAPI_KEY", "").strip()
    searchapi_key = os.getenv("SEARCHAPI_KEY", "").strip()

    if serpapi_key:
        return await search_google_scholar_serpapi(query, limit, category, search_lang, serpapi_key)
    if searchapi_key:
        return await search_google_scholar_searchapi(query, limit, category, search_lang, searchapi_key)
    if os.getenv("GOOGLE_SCHOLAR_SCRAPER_FALLBACK", "").strip() != "1":
        print("[Google Scholar] SERPAPI_KEY/SEARCHAPI_KEY not configured; direct scraping skipped to avoid timeout")
        return []

    results = []
    error_msg = ""

    try:
        # 先尝试直连 (国外用户可直接访问)
        try:
            scholarly.use_proxy(None)  # 清除之前的代理设置
        except Exception:
            pass

        search_query = scholarly.search_pubs(query)
        # 用 timeout 包裹 first next() 来检测连通性
        first_paper = None
        try:
            first_paper = next(search_query)
        except StopIteration:
            pass
        except Exception as e:
            error_msg = f"直连失败: {e}"

        # 如果直连失败，尝试使用免费代理
        if first_paper is None and error_msg:
            print(f"[Google Scholar] 直连失败，尝试代理...")
            try:
                pg = ProxyGenerator()
                success = pg.FreeProxies()
                if success:
                    scholarly.use_proxy(pg)
                    search_query = scholarly.search_pubs(query)
                    first_paper = next(search_query)
                    error_msg = ""  # 代理成功
                else:
                    error_msg = "免费代理不可用 (需 VPN 访问 Google)"
            except StopIteration:
                pass
            except Exception as e:
                error_msg = f"代理也失败: {e}"

        # 如果拿到了第一篇，继续处理
        if first_paper is not None:
            # 处理第一篇
            _parse_and_add_gs_paper(results, first_paper, 0, search_lang, category, query)
            # 继续读取剩余
            for i in range(1, min(limit, 15)):
                try:
                    paper = next(search_query)
                    _parse_and_add_gs_paper(results, paper, i, search_lang, category, query)
                except StopIteration:
                    break
                except Exception:
                    continue

    except asyncio.CancelledError:
        raise
    except Exception as e:
        error_msg = str(e)

    if not results and error_msg:
        print(f"[Google Scholar] 搜索失败: {error_msg}")
    return results


async def search_google_scholar_serpapi(
    query: str,
    limit: int = 10,
    category: SearchCategory = "all",
    search_lang: str = "en",
    api_key: str = "",
) -> list[PaperResult]:
    """通过 SerpApi 的 Google Scholar API 搜索论文。"""
    results: list[PaperResult] = []
    try:
        params = {
            "engine": "google_scholar",
            "q": _google_scholar_query(query, category),
            "api_key": api_key,
            "num": min(limit, 20),
            "hl": "zh-CN" if search_lang == "zh" else "en",
        }
        resp = requests.get("https://serpapi.com/search.json", params=params, timeout=20)
        resp.raise_for_status()
        data = resp.json()
        for i, item in enumerate(data.get("organic_results", [])[:limit]):
            results.append(_parse_serpapi_google_scholar_result(item, i, search_lang))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[Google Scholar/SerpApi] 搜索失败: {e}")
    return results


async def search_google_scholar_searchapi(
    query: str,
    limit: int = 10,
    category: SearchCategory = "all",
    search_lang: str = "en",
    api_key: str = "",
) -> list[PaperResult]:
    """通过 SearchApi 的 Google Scholar API 搜索论文。"""
    results: list[PaperResult] = []
    try:
        params = {
            "engine": "google_scholar",
            "q": _google_scholar_query(query, category),
            "api_key": api_key,
            "num": min(limit, 20),
            "hl": "zh-CN" if search_lang == "zh" else "en",
        }
        resp = requests.get("https://www.searchapi.io/api/v1/search", params=params, timeout=20)
        resp.raise_for_status()
        data = resp.json()
        for i, item in enumerate(data.get("organic_results", [])[:limit]):
            results.append(_parse_serpapi_google_scholar_result(item, i, search_lang))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[Google Scholar/SearchApi] 搜索失败: {e}")
    return results


def _google_scholar_query(query: str, category: SearchCategory) -> str:
    if category == "author":
        return f'author:"{query}"'
    if category == "journal":
        return f'source:"{query}"'
    if category == "title":
        return f'intitle:"{query}"'
    return query


def _parse_serpapi_google_scholar_result(item: dict, index: int, search_lang: str = "en") -> PaperResult:
    """解析 SerpApi/SearchApi 返回的 Google Scholar 结果。"""
    publication_info = item.get("publication_info", {}) or {}
    summary = publication_info.get("summary", "") or ""
    authors_data = publication_info.get("authors", []) or []
    authors = ", ".join([a.get("name", "") for a in authors_data[:5] if a.get("name")])
    if not authors:
        authors = summary.split(" - ", 1)[0] if summary else ""

    year = 0
    year_match = re.search(r"\b(19|20)\d{2}\b", summary)
    if year_match:
        year = int(year_match.group(0))

    inline_links = item.get("inline_links", {}) or {}
    cited_by = inline_links.get("cited_by", {}) or {}
    citations = _safe_int(cited_by.get("total", 0), 0)
    result_id = item.get("result_id") or item.get("position") or index

    return PaperResult(
        id=_engine_id("gs", result_id),
        title=item.get("title", "Unknown Title"),
        authors=authors,
        year=year,
        source="Google Scholar",
        abstract=(item.get("snippet", "") or "")[:1000],
        url=item.get("link", "") or item.get("serpapi_link", ""),
        citations=citations,
        relevance=92 - index * 2,
        keywords=["Google Scholar API"],
        source_engine="Google Scholar",
        search_language=search_lang,
    )


def _parse_and_add_gs_paper(
    results: list, paper: dict, index: int, search_lang: str, category: str, query: str
):
    """解析 scholarly 返回的单篇论文并加入结果列表"""
    bib = paper.get("bib", {})
    title = bib.get("title", "Unknown Title")
    authors = bib.get("author", "")
    if isinstance(authors, list):
        authors = ", ".join(authors[:5])
    year_str = bib.get("pub_year", "0")
    year = int(year_str) if year_str and str(year_str).isdigit() else 0
    abstract = bib.get("abstract", "") or paper.get("abstract", "") or ""
    source = bib.get("venue", "") or bib.get("journal", "") or "Google Scholar"
    paper_url = bib.get("url", "") or paper.get("eprint_url", "") or paper.get("pub_url", "")

    # 分类过滤
    if category == "author":
        if query.lower() not in authors.lower():
            return
    elif category == "journal":
        if query.lower() not in source.lower():
            return

    results.append(PaperResult(
        id=f"gs_{index}", title=title, authors=authors, year=year,
        source=source, abstract=str(abstract)[:1000],
        url=paper_url, citations=paper.get("num_citations", 0) or 0,
        relevance=90 - index * 2, source_engine="Google Scholar",
        search_language=search_lang,
    ))

# ═══════════════════════════════════════════
# CNKI / 知网
# ═══════════════════════════════════════════

CNKI_SEARCH_URL = "https://kns.cnki.net/kns8s/defaultresult/index"


async def search_cnki(
    query: str,
    limit: int = 10,
    category: SearchCategory = "all",
    search_lang: str = "zh",
) -> list[PaperResult]:
    """
    尝试抓取知网公开搜索结果。

    知网搜索页经常要求滑块/验证码验证；本函数只检测并停止，不做任何验证码绕过。
    推荐把知网作为实验源，并通过前端外部入口人工打开补查。
    """
    try:
        resp = requests.get(
            _build_cnki_search_url(query, category),
            headers={
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            },
            timeout=12,
            allow_redirects=True,
        )
        resp.encoding = resp.apparent_encoding or "utf-8"
        html = resp.text
        if _cnki_contains_verification(html) or "/verify/" in resp.url:
            print("[知网] 触发安全验证，已停止自动抓取")
            return []
        return _parse_cnki_html(html, search_lang, limit)
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[知网] 搜索出错: {e}")
        return []


def _build_cnki_search_url(query: str, category: SearchCategory = "all") -> str:
    import urllib.parse

    # CNKI 前端仍会按 kw 进入检索页；字段高级检索需要站内状态，实验源只做公开关键词入口。
    return f"{CNKI_SEARCH_URL}?kw={urllib.parse.quote(query)}"


def _cnki_contains_verification(html: str) -> bool:
    lowered = html.lower()
    return (
        "安全验证" in html
        or "验证码" in html
        or "blockpuzzle" in lowered
        or "/verify/" in lowered
        or "captcha" in lowered
    )


def _parse_cnki_html(html: str, search_lang: str = "zh", limit: int = 10) -> list[PaperResult]:
    results: list[PaperResult] = []
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        return results

    soup = BeautifulSoup(html, "html.parser")
    rows = soup.select(".result-table-list tbody tr, table.result-table-list tr, .result-table-list tr")
    if not rows:
        rows = soup.select(".result .result-item, .list-item")

    for index, row in enumerate(rows[:limit]):
        title_el = row.select_one("a.fz14, td.name a, .name a, .title a, h3 a")
        if not title_el:
            continue
        title = title_el.get_text(" ", strip=True)
        if not title:
            continue
        href = title_el.get("href", "") or ""
        if href.startswith("//"):
            url = f"https:{href}"
        elif href.startswith("/"):
            url = f"https://kns.cnki.net{href}"
        else:
            url = href

        authors = _cnki_cell_text(row, [".author", "td.author", "td:nth-child(2)"])
        source = _cnki_cell_text(row, [".source", "td.source", "td:nth-child(3)"]) or "中国知网"
        date_text = _cnki_cell_text(row, [".date", "td.date", "td:nth-child(4)"])
        year_match = re.search(r"\b(19|20)\d{2}\b", date_text)
        year = int(year_match.group(0)) if year_match else 0

        results.append(PaperResult(
            id=_engine_id("cnki", url or title or index),
            title=title,
            authors=authors,
            year=year,
            source=source,
            abstract="",
            url=url,
            relevance=86 - index * 2,
            keywords=["知网"],
            source_engine="知网",
            search_language=search_lang,
        ))
    return results


def _cnki_cell_text(row, selectors: list[str]) -> str:
    for selector in selectors:
        el = row.select_one(selector)
        if el:
            return el.get_text(" ", strip=True)
    return ""

# ═══════════════════════════════════════════
# 百度学术
# ═══════════════════════════════════════════

async def search_baidu_xueshu(
    query: str,
    limit: int = 15,
    category: SearchCategory = "all",
    search_lang: str = "zh"
) -> list[PaperResult]:
    """
    通过百度学术搜索

    使用 BeautifulSoup 解析搜索结果页。如果 BeautifulSoup 不可用，
    回退到正则匹配。百度学术偶尔会弹出验证码，此时返回空结果。
    """
    results = []
    try:
        import urllib.parse

        type_map = {"title": "title", "author": "author", "all": "", "abstract": "keyword", "journal": "journal"}
        baidu_type = type_map.get(category, "")

        encoded_query = urllib.parse.quote(query)
        url = f"https://xueshu.baidu.com/s?wd={encoded_query}&pn=0&rsv_bp=0&tn=SE_baiduxueshu_c1gjeupa"
        if baidu_type:
            url += f"&type={baidu_type}"

        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
        }
        resp = requests.get(url, headers=headers, timeout=20)
        resp.raise_for_status()
        html = resp.text

        # 检查是否被验证码拦截
        if "验证" in html and ("码" in html or "点击" in html):
            print("[百度学术] 触发验证码，搜索被拦截")
            return results

        # 尝试使用 BeautifulSoup 解析
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, "html.parser")
            result_items = soup.select(".result-item, .sc_content, [class*='result']") or soup.select("div[class*='result']")

            if result_items:
                for i, item in enumerate(result_items[:limit]):
                    title_el = item.select_one("h3 a, .title a, a.title, [class*='title'] a")
                    title = title_el.get_text(strip=True) if title_el else ""

                    authors_el = item.select_one(".author, .sc_info, [class*='author'], [class*='info']")
                    authors_text = authors_el.get_text(strip=True) if authors_el else ""

                    abstract_el = item.select_one(".abstract, .sc_abstract, [class*='abstract'], [class*='desc']")
                    abstract = abstract_el.get_text(strip=True) if abstract_el else ""

                    link_el = item.select_one("a[href*='s?wd='], a[data-url]")
                    paper_url = ""
                    if link_el:
                        paper_url = link_el.get("href", "") or link_el.get("data-url", "")

                    if not title:
                        continue

                    year = 0
                    year_match = re.search(r'(\d{4})', authors_text)
                    if year_match:
                        year = int(year_match.group(1))

                    results.append(PaperResult(
                        id=f"bd_{i}", title=title, authors=authors_text, year=year,
                        source="百度学术", abstract=abstract[:500],
                        url=paper_url, relevance=85 - i * 3,
                        source_engine="百度学术", search_language=search_lang,
                    ))
                return results
        except ImportError:
            pass  # BeautifulSoup 不可用，用下面的正则回退方案

        # 正则回退方案 (多套模式尝试)
        patterns_sets = [
            # 模式组 1: 新版百度学术
            {
                "title": re.compile(r'<h3[^>]*>\s*<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>', re.DOTALL | re.IGNORECASE),
                "info": re.compile(r'<div[^>]*class="[^"]*info[^"]*"[^>]*>(.*?)</div>', re.DOTALL | re.IGNORECASE),
                "abstract": re.compile(r'<div[^>]*class="[^"]*abstract[^"]*"[^>]*>(.*?)</div>', re.DOTALL | re.IGNORECASE),
            },
            # 模式组 2: 旧版百度学术
            {
                "title": re.compile(r'<a[^>]*class="[^"]*title[^"]*"[^>]*href="([^"]*)"[^>]*>(.*?)</a>', re.DOTALL | re.IGNORECASE),
                "info": re.compile(r'<p[^>]*class="[^"]*author[^"]*"[^>]*>(.*?)</p>', re.DOTALL | re.IGNORECASE),
                "abstract": re.compile(r'<p[^>]*class="[^"]*abstract[^"]*"[^>]*>(.*?)</p>', re.DOTALL | re.IGNORECASE),
            },
        ]

        for patterns in patterns_sets:
            title_matches = patterns["title"].findall(html)[:limit]
            if title_matches:
                info_matches = patterns["info"].findall(html)
                abstract_matches = patterns["abstract"].findall(html)

                for i, match in enumerate(title_matches):
                    if isinstance(match, tuple) and len(match) == 2:
                        paper_url, title = match
                    else:
                        title = str(match)
                        paper_url = ""
                    title = re.sub(r'<[^>]+>', '', title).strip()
                    if not title:
                        continue

                    info_text = ""
                    if i < len(info_matches):
                        info_text = re.sub(r'<[^>]+>', '', info_matches[i]).strip()

                    abstract = ""
                    if i < len(abstract_matches):
                        abstract = re.sub(r'<[^>]+>', '', abstract_matches[i]).strip()

                    year = 0
                    year_match = re.search(r'(\d{4})', info_text)
                    if year_match:
                        year = int(year_match.group(1))

                    results.append(PaperResult(
                        id=f"bd_{i}", title=title, authors=info_text, year=year,
                        source="百度学术", abstract=abstract[:500],
                        url=paper_url, relevance=85 - i * 3,
                        source_engine="百度学术", search_language=search_lang,
                    ))
                break  # 某一组成功就退出

        if not results:
            print("[百度学术] 无法解析搜索结果 (HTML 结构可能已变更)")

    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[百度学术] 搜索出错: {e}")
    return results

# ═══════════════════════════════════════════
# Crossref API
# ═══════════════════════════════════════════

async def search_crossref(
    query: str,
    limit: int = 20,
    category: SearchCategory = "all",
    search_lang: str = "en"
) -> list[PaperResult]:
    """通过 Crossref API 搜索（支持分类过滤）"""
    results = []
    try:
        url = "https://api.crossref.org/works"
        params = {"query": query, "rows": min(limit, 50), "sort": "relevance"}

        # 分类过滤
        if category == "author":
            params["filter"] = f"author:{query}"
            params.pop("query", None)
            url = "https://api.crossref.org/works"
        elif category == "title":
            params["query.title"] = query
        elif category == "journal":
            # 搜索期刊名称
            journals_url = "https://api.crossref.org/journals"
            j_params = {"query": query, "rows": 3}
            j_resp = requests.get(journals_url, params=j_params, timeout=10)
            if j_resp.ok:
                j_data = j_resp.json()
                issns = []
                for item in j_data.get("message", {}).get("items", []):
                    issn = item.get("ISSN", [""])[0]
                    if issn:
                        issns.append(issn)
                if issns:
                    params["filter"] = f"issn:{','.join(issns[:3])}"
                    params.pop("query", None)

        resp = requests.get(url, params=params, timeout=15)
        resp.raise_for_status()
        data = resp.json()

        items = data.get("message", {}).get("items", [])
        for i, item in enumerate(items[:limit]):
            title_list = item.get("title", ["Unknown Title"])
            title = title_list[0] if title_list else "Unknown Title"
            authors_list = item.get("author", [])
            author_names = ", ".join([
                f"{a.get('given', '')} {a.get('family', '')}".strip()
                for a in authors_list[:5]
            ])
            if len(authors_list) > 5:
                author_names += " et al."
            year = item.get("created", {}).get("date-parts", [[2000]])[0][0]
            source = item.get("container-title", ["Unknown"])[0] if item.get("container-title") else "Unknown"
            doi = item.get("DOI", "")
            paper_url = f"https://doi.org/{doi}" if doi else ""

            results.append(PaperResult(
                id=f"cr_{doi or i}", title=title, authors=author_names, year=year,
                source=source, abstract=str(item.get("abstract", "") or "")[:800],
                url=paper_url, doi=doi, relevance=80 - i * 2,
                source_engine="Crossref", search_language=search_lang,
            ))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[Crossref] 搜索出错: {e}")
    return results


# ═══════════════════════════════════════════
# DBLP API
# ═══════════════════════════════════════════

async def search_dblp(
    query: str,
    limit: int = 20,
    category: SearchCategory = "all",
    search_lang: str = "en",
) -> list[PaperResult]:
    results = []
    try:
        q = query
        if category == "author":
            q = f"author:{query}"
        elif category == "title":
            q = f"title:{query}"

        resp = requests.get(
            "https://dblp.org/search/publ/api",
            params={"q": q, "format": "json", "h": min(limit, 50)},
            timeout=15,
        )
        resp.raise_for_status()
        hits = resp.json().get("result", {}).get("hits", {}).get("hit", [])
        if isinstance(hits, dict):
            hits = [hits]
        for i, hit in enumerate(hits[:limit]):
            results.append(_parse_dblp_hit(hit, i, search_lang))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[DBLP] 搜索出错: {e}")
    return results


def _parse_dblp_hit(hit: dict, index: int, search_lang: str = "en") -> PaperResult:
    info = hit.get("info", {})
    authors_field = info.get("authors", {}).get("author", [])
    if isinstance(authors_field, dict):
        authors_field = [authors_field]
    authors = ", ".join([a.get("text", "") if isinstance(a, dict) else str(a) for a in authors_field[:5]])
    if len(authors_field) > 5:
        authors += " et al."

    return PaperResult(
        id=_engine_id("dblp", info.get("key", index)),
        title=info.get("title", "Unknown Title"),
        authors=authors,
        year=_safe_int(info.get("year")),
        source=info.get("venue", "") or "DBLP",
        abstract="",
        url=info.get("url", ""),
        doi=_normalize_doi(info.get("doi", "")),
        citations=0,
        relevance=88 - index * 2,
        keywords=["计算机科学", "DBLP"],
        source_engine="DBLP",
        search_language=search_lang,
    )


# ═══════════════════════════════════════════
# Unpaywall API
# ═══════════════════════════════════════════

async def search_unpaywall(
    query: str,
    limit: int = 20,
    category: SearchCategory = "all",
    search_lang: str = "en",
) -> list[PaperResult]:
    results = []
    try:
        email = os.getenv("UNPAYWALL_EMAIL", "scholar-assist@example.com")
        resp = requests.get(
            "https://api.unpaywall.org/v2/search",
            params={"query": query, "email": email, "page": 1, "is_oa": "true"},
            timeout=15,
        )
        resp.raise_for_status()
        items = resp.json().get("results", [])
        for i, item in enumerate(items[:limit]):
            response = item.get("response", item)
            best_oa = response.get("best_oa_location") or {}
            results.append(PaperResult(
                id=_engine_id("unpaywall", response.get("doi", i)),
                title=response.get("title", "Unknown Title"),
                authors=", ".join([a.get("author_name", "") for a in response.get("z_authors", [])[:5] if a.get("author_name")]),
                year=_safe_int(response.get("year")),
                source=response.get("journal_name", "") or "Unpaywall",
                abstract="",
                url=best_oa.get("url_for_pdf") or best_oa.get("url") or (f"https://doi.org/{response.get('doi')}" if response.get("doi") else ""),
                doi=response.get("doi", ""),
                citations=0,
                relevance=86 - i * 2,
                keywords=["开放获取", "OA"],
                source_engine="Unpaywall",
                search_language=search_lang,
            ))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[Unpaywall] 搜索出错: {e}")
    return results


# ═══════════════════════════════════════════
# Papers with Code API
# ═══════════════════════════════════════════

async def search_papers_with_code(
    query: str,
    limit: int = 20,
    category: SearchCategory = "all",
    search_lang: str = "en",
) -> list[PaperResult]:
    results = []
    try:
        resp = requests.get(
            "https://paperswithcode.com/api/v1/papers/",
            params={"q": query, "page_size": min(limit, 50)},
            timeout=15,
        )
        resp.raise_for_status()
        if "json" not in (resp.headers.get("content-type") or "").lower():
            return results
        for i, item in enumerate(resp.json().get("results", [])[:limit]):
            results.append(_parse_papers_with_code_item(item, i, search_lang))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print(f"[Papers with Code] 搜索出错: {e}")
    return results


def _parse_papers_with_code_item(item: dict, index: int, search_lang: str = "en") -> PaperResult:
    authors = item.get("authors", "")
    if isinstance(authors, list):
        authors = ", ".join([str(a) for a in authors[:5]])
    year = 0
    year_match = re.search(r"\d{4}", item.get("published", "") or item.get("date", ""))
    if year_match:
        year = _safe_int(year_match.group(0))
    url = item.get("url_abs") or item.get("url_pdf") or item.get("paper_url") or ""
    keywords = ["有代码"] if item.get("repository_url") or item.get("url_code") else []
    keywords.append("Papers with Code")

    return PaperResult(
        id=_engine_id("pwc", item.get("id", index)),
        title=item.get("title", "Unknown Title"),
        authors=authors,
        year=year,
        source=item.get("conference", "") or "Papers with Code",
        abstract=(item.get("abstract", "") or "")[:1200],
        url=url,
        doi=_normalize_doi(item.get("doi", "")),
        citations=0,
        relevance=90 - index * 2,
        keywords=keywords,
        source_engine="Papers with Code",
        search_language=search_lang,
    )

# ═══════════════════════════════════════════
# 统一搜索接口 (支持中英文双搜索 + 分类)
# ═══════════════════════════════════════════

ENGINE_MAP = {
    "semantic_scholar": search_semantic_scholar,
    "arxiv": search_arxiv,
    "google_scholar": search_google_scholar,
    "cnki": search_cnki,
    "baidu_xueshu": search_baidu_xueshu,
    "crossref": search_crossref,
    "openalex": search_openalex,
    "pubmed": search_pubmed,
    "dblp": search_dblp,
    "unpaywall": search_unpaywall,
    "papers_with_code": search_papers_with_code,
}

DEFAULT_RANK_WEIGHTS = {
    "relevance": 0.45,
    "recency": 0.2,
    "citations": 0.25,
    "novelty": 0.1,
}


def _normalized_rank_weights(weights: dict | None) -> dict:
    raw = {**DEFAULT_RANK_WEIGHTS, **(weights or {})}
    cleaned = {k: max(0.0, float(raw.get(k, 0.0))) for k in DEFAULT_RANK_WEIGHTS}
    total = sum(cleaned.values()) or 1.0
    return {k: v / total for k, v in cleaned.items()}


def apply_weighted_ranking(papers: list[PaperResult], weights: dict | None = None) -> list[PaperResult]:
    """Apply weighted ranking and return a new list sorted by final score."""
    if not papers:
        return []
    normalized = _normalized_rank_weights(weights)
    current_year = time.localtime().tm_year
    max_citations = max([p.citations for p in papers] + [1])

    ranked = []
    for paper in papers:
        relevance_score = max(0.0, min(1.0, paper.relevance / 100))
        recency_score = 0.0
        if paper.year:
            recency_score = max(0.0, min(1.0, 1 - max(0, current_year - paper.year) / 10))
        citation_score = max(0.0, min(1.0, paper.citations / max_citations))
        novelty_score = recency_score * (1 - min(1.0, paper.citations / max_citations))

        final_score = (
            normalized["relevance"] * relevance_score
            + normalized["recency"] * recency_score
            + normalized["citations"] * citation_score
            + normalized["novelty"] * novelty_score
        )
        paper.relevance = round(final_score * 100)
        ranked.append(paper)

    ranked.sort(key=lambda x: x.relevance, reverse=True)
    return ranked

async def search_all(
    query: str,
    engines: list[str] | None = None,
    limit_per_engine: int = 10,
    category: SearchCategory = "all",
    auto_translate: bool = True,
    rank_weights: dict | None = None,
) -> list[PaperResult]:
    """
    统一搜索接口

    Args:
        query: 搜索关键词
        engines: 搜索引擎列表
        limit_per_engine: 每个引擎返回结果数
        category: 搜索分类 (all/title/author/journal/abstract)
        auto_translate: 是否自动中英文双搜索
    """
    if engines is None:
        engines = ["semantic_scholar", "arxiv", "google_scholar", "baidu_xueshu", "crossref"]

    # 构建搜索任务列表
    tasks = []

    if auto_translate and contains_chinese(query):
        # 中英文双搜索模式
        dual_queries = build_dual_query(query)
        for q, lang in dual_queries:
            # 中文查询 → 优先中文搜索引擎
            # 英文查询 → 优先英文搜索引擎
            for engine_name in engines:
                if engine_name in ENGINE_MAP:
                    tasks.append(ENGINE_MAP[engine_name](q, limit_per_engine, category, lang))
    else:
        # 单语言搜索
        lang = "zh" if contains_chinese(query) else "en"
        for engine_name in engines:
            if engine_name in ENGINE_MAP:
                tasks.append(ENGINE_MAP[engine_name](query, limit_per_engine, category, lang))

    # 并发执行
    all_results = await asyncio.gather(*tasks, return_exceptions=True)

    # 合并结果
    merged: list[PaperResult] = []
    for result_set in all_results:
        if isinstance(result_set, list):
            merged.extend(result_set)

    # 去重
    merged = _deduplicate(merged)

    return apply_weighted_ranking(merged, rank_weights)

def _deduplicate(papers: list[PaperResult]) -> list[PaperResult]:
    """基于标题相似度的去重"""
    seen = set()
    unique = []
    for p in papers:
        key = "".join(c.lower() for c in p.title if c.isalnum())[:50]
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique

def paper_to_dict(p: PaperResult) -> dict:
    return {
        "id": p.id,
        "title": p.title,
        "authors": p.authors,
        "year": p.year,
        "source": p.source,
        "abstract": p.abstract,
        "url": p.url,
        "doi": p.doi,
        "citations": p.citations,
        "relevance": p.relevance,
        "keywords": p.keywords,
        "source_engine": p.source_engine,
        "search_language": p.search_language,
    }
