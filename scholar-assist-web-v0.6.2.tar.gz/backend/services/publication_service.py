"""Publication workflow helpers for manuscript writing and export."""
from __future__ import annotations

import re
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from services.evidence_service import (
    build_answer_with_citations_prompt as build_indexed_answer_with_citations_prompt,
    build_evidence_gap_report,
    build_evidence_index,
    search_evidence_cards as search_indexed_evidence_cards,
)

def default_tool_paths(platform_name: str | None = None) -> list[str]:
    current_platform = platform_name or sys.platform
    paths = [
        str(Path.home() / ".local/bin"),
        str(Path.home() / ".local/quarto-1.9.38/bin"),
    ]
    if current_platform == "darwin":
        paths.extend([
            "/opt/homebrew/bin",
            "/usr/local/bin",
            str(Path("/") / "Applications" / "quarto" / "bin"),
            str(Path("/") / "Applications" / "Quarto" / "bin"),
        ])
    elif current_platform.startswith("win"):
        program_files = Path(os.environ.get("ProgramFiles", "C:\\Program Files"))
        local_app_data = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
        paths.extend([
            str(program_files / "Quarto" / "bin"),
            str(local_app_data / "Programs" / "Quarto" / "bin"),
        ])
    else:
        paths.extend(["/usr/local/bin", "/usr/bin"])
    return paths


DEFAULT_TOOL_PATHS = default_tool_paths()


def resolve_tool_path(binary: str, extra_paths: list[str] | None = None) -> str:
    """Resolve CLI tools even when macOS GUI apps start with a minimal PATH."""
    found = shutil.which(binary)
    if found:
        return found
    for directory in [*(extra_paths or []), *DEFAULT_TOOL_PATHS]:
        candidate = Path(directory) / binary
        if candidate.exists() and candidate.is_file():
            return str(candidate)
    return ""


def _tool_version(binary: str) -> str:
    path = resolve_tool_path(binary)
    if not path:
        return ""
    try:
        result = subprocess.run(
            [path, "--version"],
            check=False,
            capture_output=True,
            text=True,
            timeout=4,
        )
        return (result.stdout or result.stderr).splitlines()[0].strip()
    except Exception:
        return ""


def detect_publication_tools() -> dict:
    """Report optional publishing engines without making them mandatory."""
    tools = {}
    for binary in ["pandoc", "quarto", "pandoc-crossref"]:
        path = resolve_tool_path(binary)
        tools[binary] = {
            "available": bool(path),
            "path": path or "",
            "version": _tool_version(binary) if path else "",
        }
    return tools


def build_pandoc_metadata_block(title: str, bibliography: str, csl: str) -> str:
    """Build a YAML metadata block accepted by Pandoc and Quarto."""
    safe_title = (title or "Scholar Assist Manuscript").replace('"', "'")
    return (
        "---\n"
        f'title: "{safe_title}"\n'
        f"date: {datetime.now().strftime('%Y-%m-%d')}\n"
        f"bibliography: {bibliography}\n"
        f"csl: {csl}\n"
        "link-citations: true\n"
        "number-sections: true\n"
        "---\n\n"
    )


def slugify_label(value: str, fallback: str) -> str:
    text = re.sub(r"图\s*\d+[：:\s]*|表\s*\d+[：:\s]*", "", value or "")
    text = re.sub(r"[^\w\u4e00-\u9fff]+", "-", text.lower()).strip("-")
    mapping = {
        "系统框架": "system-framework",
        "实验结果": "experiment-results",
        "方法对比": "method-comparison",
    }
    return mapping.get(text, text[:48] or fallback)


def enhance_cross_references(markdown: str) -> dict:
    """Add pandoc-crossref compatible figure/table identifiers when missing."""
    figure_index = 0
    table_index = 0
    examples: list[str] = []
    output: list[str] = []

    for line in (markdown or "").splitlines():
      image = re.match(r"^!\[(.+?)\]\((.+?)\)(?:\{#fig:[^}]+\})?$", line.strip())
      if image:
          figure_index += 1
          label = slugify_label(image.group(1), f"figure-{figure_index}")
          final = line if "{#fig:" in line else f"{line}{{#fig:{label}}}"
          output.append(final)
          examples.append(f"正文引用：如 @fig:{label} 所示。")
          continue

      table = re.match(r"^表\s*\d+[：:]\s*(.+)$", line.strip())
      if table:
          table_index += 1
          label = slugify_label(table.group(1), f"table-{table_index}")
          final = line if "{#tbl:" in line else f"{line} {{#tbl:{label}}}"
          output.append(final)
          examples.append(f"正文引用：如 @tbl:{label} 所示。")
          continue

      output.append(line)

    return {
        "markdown": "\n".join(output),
        "figures": figure_index,
        "tables": table_index,
        "reference_examples": examples,
    }


def parse_literature_identifier(query: str) -> dict:
    """Classify DOI, PMID, arXiv id or free title for metadata lookup."""
    value = (query or "").strip()
    doi = re.search(r"(10\.\d{4,9}/[-._;()/:A-Za-z0-9]+)", value)
    if doi:
        return {"kind": "doi", "value": doi.group(1).rstrip(".")}
    pmid = re.search(r"(?:PMID[:\s]*)?(\d{6,9})$", value, re.I)
    if pmid and ("pmid" in value.lower() or value.isdigit()):
        return {"kind": "pmid", "value": pmid.group(1)}
    arxiv = re.search(r"(?:arxiv[:\s]*)?(\d{4}\.\d{4,5}(?:v\d+)?)", value, re.I)
    if arxiv:
        return {"kind": "arxiv", "value": arxiv.group(1)}
    return {"kind": "title", "value": value}


def normalize_zotero_item(item: dict) -> dict:
    """Normalize a Zotero Web API item into the app paper shape."""
    data = item.get("data", item or {})
    creators = []
    for creator in data.get("creators", [])[:8]:
        name = " ".join([
            creator.get("firstName", "").strip(),
            creator.get("lastName", "").strip(),
        ]).strip() or creator.get("name", "")
        if name:
            creators.append(name)
    year = 0
    year_match = re.search(r"\d{4}", str(data.get("date", "")))
    if year_match:
        year = int(year_match.group(0))
    return {
        "id": data.get("key", "") or data.get("DOI", "") or data.get("title", ""),
        "title": data.get("title", ""),
        "authors": ", ".join(creators),
        "year": year,
        "source": data.get("publicationTitle", "") or data.get("conferenceName", "") or data.get("publisher", ""),
        "abstract": data.get("abstractNote", ""),
        "doi": data.get("DOI", ""),
        "url": data.get("url", ""),
        "citations": 0,
        "keywords": [tag.get("tag", "") for tag in data.get("tags", []) if tag.get("tag")],
        "source_engine": "Zotero",
    }


def build_literature_answer_prompt(question: str, papers: list[dict]) -> str:
    paper_blocks = []
    for index, paper in enumerate(papers[:12], 1):
        paper_blocks.append(
            f"{index}. 标题: {paper.get('title', 'Unknown')}\n"
            f"作者: {paper.get('authors', '')}\n"
            f"年份: {paper.get('year', '')}\n"
            f"摘要: {(paper.get('abstract') or paper.get('abstract_text') or '')[:1200]}\n"
            f"笔记/页码证据: {paper.get('notes', '')[:1200]}\n"
        )
    return (
        "你是项目知识库论文问答助手。请只依据下列论文信息回答用户问题。\n"
        "要求：必须引用论文标题；如果 notes 或片段中有页码，必须写出页码；没有证据时明确说信息不足；不要编造实验数据。\n\n"
        f"用户问题：{question}\n\n"
        "论文证据：\n"
        + "\n".join(paper_blocks)
    )


def build_pdf_evidence_cards(paper: dict, question: str = "", limit: int = 6) -> list[dict]:
    """Build page-aware evidence cards from an uploaded PDF paper payload."""
    terms = [t.lower() for t in re.findall(r"[\w\u4e00-\u9fff]+", question or "") if len(t) > 1]
    segments = paper.get("page_segments") or paper.get("page_texts") or []
    cards = []
    for item in segments:
        text = " ".join((item.get("text") or "").split())
        if not text:
            continue
        lowered = text.lower()
        score = sum(1 for term in terms if term in lowered) if terms else 1
        if score <= 0:
            continue
        cards.append({
            "paper_id": paper.get("id", ""),
            "title": paper.get("title", "Unknown PDF"),
            "page": item.get("page", 0),
            "score": score,
            "quote": text[:700],
            "citation_hint": f"{paper.get('title', 'PDF')}，第 {item.get('page', '?')} 页",
        })
    cards.sort(key=lambda item: item["score"], reverse=True)
    return cards[:limit]


def search_evidence_cards(question: str, papers: list[dict], limit: int = 10) -> list[dict]:
    """Search abstracts, notes and PDF snippets for grounded answer evidence."""
    return search_indexed_evidence_cards(question, papers, limit)


def build_answer_with_citations_prompt(question: str, papers: list[dict], limit: int = 10) -> dict:
    """Build a PaperQA-style grounded answer prompt from retrieved evidence cards."""
    return build_indexed_answer_with_citations_prompt(question, papers, limit)


def build_literature_matrix(papers: list[dict]) -> dict:
    """Create a deterministic literature matrix that AI can later refine."""
    columns = ["文献", "研究问题", "方法/模型", "数据/样本", "主要结论", "局限", "可引用证据"]
    rows = []
    for paper in papers[:30]:
        abstract = " ".join((paper.get("abstract") or paper.get("abstract_text") or "").split())
        notes = " ".join((paper.get("notes") or "").split())
        evidence = notes[:180] or abstract[:180] or "未提供摘要或 PDF 证据"
        rows.append([
            f"{paper.get('title', 'Unknown')} ({paper.get('year', 'n.d.')})",
            _extract_hint(abstract, ["aim", "purpose", "研究", "problem", "challenge"]) or "未说明",
            _extract_hint(abstract, ["method", "model", "approach", "algorithm", "方法", "模型"]) or "未说明",
            _extract_hint(abstract, ["dataset", "sample", "cohort", "数据", "样本"]) or "未说明",
            _extract_hint(abstract, ["result", "finding", "show", "发现", "结果"]) or "未说明",
            _extract_hint(abstract + " " + notes, ["limitation", "future", "局限", "不足"]) or "未说明",
            evidence,
        ])
    markdown = "| " + " | ".join(columns) + " |\n|" + "|".join(["---"] * len(columns)) + "|\n"
    markdown += "\n".join("| " + " | ".join(str(cell).replace("|", "/") for cell in row) + " |" for row in rows)
    return {"columns": columns, "rows": rows, "markdown": markdown}


def _extract_hint(text: str, keywords: list[str], window: int = 180) -> str:
    if not text:
        return ""
    lowered = text.lower()
    for keyword in keywords:
        pos = lowered.find(keyword.lower())
        if pos >= 0:
            start = max(0, pos - 60)
            return text[start:start + window].strip()
    return ""


def build_evidence_bound_chapter_prompt(section_title: str, current_text: str, papers: list[dict]) -> str:
    """Build a writing prompt that forces claims to be tied to supplied evidence."""
    query = f"{section_title}\n{current_text or ''}".strip()
    cards = search_indexed_evidence_cards(query, papers, limit=12)
    evidence_lines = []
    if cards:
        for card in cards:
            page = f"，第 {card['page']} 页" if card.get("page") else ""
            key = f" [@{card['citation_key']}]" if card.get("citation_key") else ""
            evidence_lines.append(
                f"[{card['id']}] {card['title']} ({card['year']}){page}{key}\n"
                f"来源：{card['kind']} · score={card['score']} · semantic={card['semantic_score']} · keyword={card['keyword_score']}\n"
                f"证据：{card['text']}"
            )
    else:
        for index, paper in enumerate(papers[:12], 1):
            title = paper.get("title", "Unknown")
            year = paper.get("year", "n.d.")
            abstract = (paper.get("abstract") or paper.get("abstract_text") or "").strip()
            notes = (paper.get("notes") or "").strip()
            key = f" [@{paper.get('citation_key')}]" if paper.get("citation_key") else ""
            evidence_lines.append(
                f"[E{index}] {title} ({year}){key}\n"
                f"摘要证据: {abstract[:900] or '未提供'}\n"
                f"页码/笔记证据: {notes[:900] or '未提供'}"
            )
    stats = build_evidence_index(papers)["stats"]
    evidence_block = "\n\n".join(evidence_lines) if evidence_lines else "没有检索到可用证据。"
    stats_line = f"papers={stats['papers']}, chunks={stats['chunks']}, tokens={stats['tokens']}"
    return (
        f"请为论文当前章节《{section_title}》写作或续写正文。\n"
        "硬性规则：\n"
        "1. 只能使用下方证据，不得编造作者、数据、页码、样本量或结论。\n"
        "2. 每个关键论断后标注证据编号，例如 [E1]；有 citation_key 时同时保留 [@citation]。\n"
        "3. 证据不足的地方写 [需要补充文献]，不要强行下结论。\n"
        "4. 输出适合直接进入论文正文，不要写聊天式解释。\n"
        "5. 文末附“使用证据”小节，只列本次实际使用的证据编号。\n\n"
        f"当前草稿：\n{(current_text or '')[:5000]}\n\n"
        f"Evidence Index Stats: {stats_line}\n\n"
        "Evidence Cards:\n" + evidence_block
    )


def build_evidence_bound_chapter_contract(section_title: str, current_text: str, papers: list[dict]) -> dict:
    """Return a guarded chapter-writing contract with refusal metadata."""
    query = f"{section_title}\n{current_text or ''}".strip()
    cards = search_indexed_evidence_cards(query, papers, limit=12)
    stats = build_evidence_index(papers)["stats"]
    if not cards:
        gap = build_evidence_gap_report(query, papers)
        return {
            "prompt": (
                f"证据不足，禁止为《{section_title}》生成论文段落。\n"
                f"原因：{gap['refusal']}\n"
                "请只返回缺证据清单、建议检索词和下一步导入建议。"
            ),
            "evidence": [],
            "index_stats": stats,
            **gap,
        }
    return {
        "prompt": build_evidence_bound_chapter_prompt(section_title, current_text, papers),
        "evidence": cards,
        "index_stats": stats,
        "status": "ready",
        "refusal": "",
        "missing_evidence": [],
        "suggested_queries": [],
    }


def inspect_export_preflight(markdown: str, papers: list[dict] | None = None) -> list[dict]:
    """Run manuscript checks before final export."""
    text = markdown or ""
    papers = papers or []
    citation_tokens = {
        key for key in re.findall(r"@([A-Za-z0-9:_\-./]+)", text)
        if not key.startswith(("fig:", "tbl:", "eq:"))
    }
    paper_key_list = [str(p.get("citation_key") or "").strip() for p in papers if p.get("citation_key")]
    paper_keys = set(paper_key_list)
    duplicate_paper_keys = sorted({key for key in paper_key_list if paper_key_list.count(key) > 1})
    tools = detect_publication_tools()
    image_targets = re.findall(r"!\[[^\]]*\]\(([^)]+)\)", text)
    external_images = [
        target.split()[0].strip("<>")
        for target in image_targets
        if not target.startswith(("data:", "http://", "https://"))
    ]
    missing_images = [
        target
        for target in external_images
        if not (Path(target).exists() or (Path.cwd() / target).exists())
    ]
    has_base64_images = any(target.startswith("data:image") for target in image_targets)
    display_math_markers = text.count("$$")
    bracket_math_open = len(re.findall(r"\\\[", text))
    bracket_math_close = len(re.findall(r"\\\]", text))
    math_closed = display_math_markers % 2 == 0 and bracket_math_open == bracket_math_close
    crossref_needed = bool(re.search(r"@fig:|@tbl:|#fig:|#tbl:", text))
    latex_available = any(resolve_tool_path(binary) for binary in ["xelatex", "lualatex", "pdflatex"])
    source_data_placeholder_pattern = (
        r"USER_DATA_REQUIRED|TODO_metric|TODO_n|TODO_value|TODO_sd_or_ci|"
        r"replace\s+(?:simulated|this row)|source-data\.xlsx|模拟数据|示例数据"
    )
    checks = [
        {
            "id": "title",
            "label": "标题结构",
            "severity": "error" if not re.search(r"^#\s+", text, re.M) else "ok",
            "ok": bool(re.search(r"^#\s+", text, re.M)),
            "message": "缺少一级标题，导出目录和封面会不完整。",
        },
        {
            "id": "abstract",
            "label": "摘要",
            "severity": "warning" if not re.search(r"摘要|abstract", text, re.I) else "ok",
            "ok": bool(re.search(r"摘要|abstract", text, re.I)),
            "message": "未检测到摘要章节。",
        },
        {
            "id": "citations",
            "label": "正文引用",
            "severity": "warning" if not citation_tokens else "ok",
            "ok": bool(citation_tokens),
            "message": "正文没有 Pandoc 引用占位，如 [@smith2024]。",
        },
        {
            "id": "references",
            "label": "参考文献元数据",
            "severity": "error" if citation_tokens and not papers else "ok",
            "ok": not citation_tokens or bool(papers),
            "message": "正文已有引用，但导出请求没有携带项目库文献。",
        },
        {
            "id": "todo",
            "label": "待补内容",
            "severity": "error" if re.search(r"TODO|待补|AUTHOR_INPUT_NEEDED|\?\?", text, re.I) else "ok",
            "ok": not bool(re.search(r"TODO|待补|AUTHOR_INPUT_NEEDED|\?\?", text, re.I)),
            "message": "正文仍有待补标记，定稿导出前必须处理。",
        },
        {
            "id": "source-data-placeholders",
            "label": "图表源数据",
            "severity": "error" if re.search(source_data_placeholder_pattern, text, re.I) else "ok",
            "ok": not bool(re.search(source_data_placeholder_pattern, text, re.I)),
            "message": "检测到图表源数据占位或示例数据提示，请替换为真实 source_data.csv / 原始测量文件后再定稿导出。"
            if re.search(source_data_placeholder_pattern, text, re.I)
            else "未检测到图表源数据占位。",
        },
        {
            "id": "figures",
            "label": "图表引用",
            "severity": "warning" if ("图 " in text or "表 " in text) and not re.search(r"@fig:|@tbl:|#fig:|#tbl:", text) else "ok",
            "ok": not (("图 " in text or "表 " in text) and not re.search(r"@fig:|@tbl:|#fig:|#tbl:", text)),
            "message": "检测到图表文字，但缺少 pandoc-crossref 标识。",
        },
        {
            "id": "image-paths",
            "label": "图片文件路径",
            "severity": "error" if missing_images else "ok",
            "ok": not missing_images,
            "message": f"这些图片路径不存在：{', '.join(missing_images[:5])}" if missing_images else "外部图片路径可访问，或图片以内联 base64 方式嵌入。",
        },
        {
            "id": "base64-images",
            "label": "内联图片体积",
            "severity": "warning" if has_base64_images else "ok",
            "ok": not has_base64_images,
            "message": "检测到 base64 内联图片：预览最稳，但 DOCX/PDF 可能体积较大；定稿可替换为 figures/ 下的文件路径。" if has_base64_images else "未检测到 base64 内联图片。",
        },
        {
            "id": "math-blocks",
            "label": "公式块闭合",
            "severity": "error" if not math_closed else "ok",
            "ok": math_closed,
            "message": "检测到未闭合的 $$ 或 \\[ \\] 公式块，导出时可能乱码。" if not math_closed else "公式块闭合正常。",
        },
        {
            "id": "publication-engine",
            "label": "出版导出引擎",
            "severity": "warning" if not (tools["pandoc"]["available"] or tools["quarto"]["available"]) else "ok",
            "ok": tools["pandoc"]["available"] or tools["quarto"]["available"],
            "message": "未检测到 Pandoc/Quarto，将使用内置导出兜底；学校/期刊模板能力会受限。" if not (tools["pandoc"]["available"] or tools["quarto"]["available"]) else "已检测到 Pandoc 或 Quarto，可走出版级导出链路。",
        },
        {
            "id": "crossref-engine",
            "label": "交叉引用引擎",
            "severity": "warning" if crossref_needed and not tools["pandoc-crossref"]["available"] else "ok",
            "ok": not crossref_needed or tools["pandoc-crossref"]["available"],
            "message": "正文使用了 @fig/@tbl 或 {#fig}/{#tbl}，但未检测到 pandoc-crossref。" if crossref_needed and not tools["pandoc-crossref"]["available"] else "交叉引用导出条件满足或当前不需要。",
        },
        {
            "id": "pdf-engine",
            "label": "PDF 排版引擎",
            "severity": "warning" if not latex_available else "ok",
            "ok": latex_available,
            "message": "未检测到 xelatex/lualatex/pdflatex；外部 PDF 导出失败时会回退到内置 PDF。" if not latex_available else "已检测到 LaTeX PDF 引擎。",
        },
    ]
    if citation_tokens and paper_keys:
        missing = sorted(token for token in citation_tokens if token not in paper_keys)
        unused = sorted(key for key in paper_keys if key not in citation_tokens)
        checks.append({
            "id": "citation-key-match",
            "label": "引用 key 匹配",
            "severity": "error" if missing else "ok",
            "ok": not missing,
            "message": f"这些引用 key 未在项目库中找到：{', '.join(missing[:8])}" if missing else "正文引用 key 与项目库元数据匹配。",
        })
        checks.append({
            "id": "citation-key-duplicates",
            "label": "重复 citekey",
            "severity": "error" if duplicate_paper_keys else "ok",
            "ok": not duplicate_paper_keys,
            "message": f"项目库存在重复 citekey：{', '.join(duplicate_paper_keys[:8])}。请合并或重命名后再正式导出。"
            if duplicate_paper_keys else "项目库 citekey 没有重复。",
        })
        checks.append({
            "id": "uncited-references",
            "label": "未引用文献",
            "severity": "warning" if unused else "ok",
            "ok": not unused,
            "message": f"这些项目库文献未在正文引用，正式参考文献默认不应包含：{', '.join(unused[:8])}"
            if unused else "项目库文献均已在正文中引用。",
        })
    for check in checks:
        check["blocking"] = check["severity"] == "error"
    return checks


def list_template_packs() -> list[dict]:
    """Return built-in manuscript template packs and their intended use."""
    from services.export_service import list_template_reference_profiles

    best_for = {
        "undergraduate": "课程论文、毕业论文初稿",
        "master": "较长篇幅学位论文",
        "journal": "中文/英文期刊投稿草稿",
        "nature": "高影响力短文逻辑训练",
    }
    structure = {
        "undergraduate": ["封面", "中文摘要", "英文摘要", "目录", "正文", "参考文献", "致谢"],
        "master": ["封面", "原创性声明", "中英文摘要", "目录", "正文", "参考文献", "附录", "致谢"],
        "journal": ["题名", "作者", "摘要", "关键词", "Introduction", "Methods", "Results", "Discussion", "References"],
        "nature": ["Title", "Abstract", "Main text", "Methods", "Figure legends", "References", "Source data"],
    }
    format_checks = {
        "undergraduate": ["摘要字数", "章节编号", "图表编号", "GB/T 7714", "参考文献闭环"],
        "master": ["中英文摘要", "目录", "三级标题", "图表公式编号", "GB/T 7714", "页眉页脚"],
        "journal": ["IMRaD 结构", "图表引用", "参考文献样式", "利益冲突/数据可用性"],
        "nature": ["Figure-driven narrative", "Source data", "Methods 可复现性", "图注独立完整"],
    }
    return [
        {
            **profile,
            "name": profile["label"],
            "best_for": best_for.get(profile["id"], ""),
            "csl": profile["citation_style"],
            "structure": structure.get(profile["id"], []),
            "format_checks": format_checks.get(profile["id"], []),
            "export_style": "、".join(profile.get("delivery", [])),
        }
        for profile in list_template_reference_profiles()
    ]


def build_chapter_writing_prompt(section_title: str, current_text: str, knowledge_context: str = "") -> str:
    return (
        f"请只写当前章节《{section_title}》，不要生成整篇论文。\n"
        "写作要求：保持学术论文语气；围绕本章节目标展开；先给论点，再给证据；必要处保留 [@citation] 引用占位；"
        "如果文献证据不足，标注 [需要补充文献]。\n\n"
        f"当前章节草稿：\n{(current_text or '')[:5000]}\n\n"
        f"可用项目知识库证据：\n{(knowledge_context or '')[:5000]}"
    )


def inspect_manuscript_quality(markdown: str) -> list[dict]:
    text = markdown or ""
    checks = [
        ("研究空白", r"研究空白|不足|局限|gap|however|仍然|尚未", "引言需要明确现有研究缺什么。"),
        ("可复现方法", r"数据集|评价指标|实验环境|参数|复现|dataset|metric|implementation", "方法章节需要包含数据、指标、参数和实现细节。"),
        ("证据链", r"图\s*\d+|表\s*\d+|@fig:|@tbl:|消融|对比实验|结果", "结果章节需要图表、对照或消融支撑。"),
        ("引用闭环", r"\[@[^\]]+\]|@doi|@fig:|@tbl:", "正文需要有可追踪引用或交叉引用。"),
        ("局限性", r"局限|不足|限制|未来工作|展望|limitation", "讨论/结论需要说明边界和未来工作。"),
    ]
    return [
        {"label": label, "ok": bool(re.search(pattern, text, re.I)), "hint": hint}
        for label, pattern, hint in checks
    ]
