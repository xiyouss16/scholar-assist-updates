"""Citation verification and export helpers."""
from __future__ import annotations

import re
from difflib import SequenceMatcher
import requests
from services.publication_service import parse_literature_identifier


def normalize_doi(doi: str) -> str:
    return (doi or "").lower().replace("https://doi.org/", "").replace("http://doi.org/", "").strip()


def normalize_title(title: str) -> str:
    title = re.sub(r"[^\w\s\u4e00-\u9fff]", " ", title or "").lower()
    return " ".join(title.split())


def title_similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, normalize_title(a), normalize_title(b)).ratio()


def compare_reference_metadata(reference: dict, candidate: dict | None) -> dict:
    if not candidate:
        return {
            "status": "unverified",
            "confidence": 0,
            "issues": ["未在 Crossref/OpenAlex 中找到可靠匹配"],
            "matched": None,
        }

    issues = []
    confidence = 100
    ref_doi = normalize_doi(reference.get("doi", ""))
    candidate_doi = normalize_doi(candidate.get("doi", ""))
    if ref_doi and candidate_doi and ref_doi != candidate_doi:
        issues.append(f"DOI 不一致：引用 {ref_doi}，数据库 {candidate_doi}")
        confidence -= 35

    similarity = title_similarity(reference.get("title", ""), candidate.get("title", ""))
    if similarity < 0.82:
        issues.append(f"标题不一致：数据库标题为「{candidate.get('title', 'Unknown')}」")
        confidence -= 30

    ref_year = int(reference.get("year") or 0)
    candidate_year = int(candidate.get("year") or 0)
    if ref_year and candidate_year and ref_year != candidate_year:
        issues.append(f"年份不一致：引用 {ref_year}，数据库 {candidate_year}")
        confidence -= 15

    status = "verified" if not issues else ("warning" if confidence >= 50 else "mismatch")
    return {
        "status": status,
        "confidence": max(0, confidence),
        "issues": issues,
        "matched": candidate,
    }


def _parse_crossref_item(item: dict) -> dict:
    title = (item.get("title") or ["Unknown Title"])[0]
    authors = []
    for author in item.get("author", [])[:6]:
        name = f"{author.get('given', '')} {author.get('family', '')}".strip()
        if name:
            authors.append(name)
    year = 0
    date_parts = item.get("issued", {}).get("date-parts") or item.get("created", {}).get("date-parts") or []
    if date_parts and date_parts[0]:
        year = int(date_parts[0][0])
    source = (item.get("container-title") or [""])[0] if item.get("container-title") else ""
    doi = item.get("DOI", "")
    return {
        "title": title,
        "authors": ", ".join(authors),
        "year": year,
        "source": source,
        "doi": doi,
        "url": f"https://doi.org/{doi}" if doi else item.get("URL", ""),
        "source_engine": "Crossref",
    }


def lookup_crossref(reference: dict) -> dict | None:
    try:
        if reference.get("doi"):
            resp = requests.get(f"https://api.crossref.org/works/{normalize_doi(reference['doi'])}", timeout=12)
            if resp.ok:
                return _parse_crossref_item(resp.json().get("message", {}))

        resp = requests.get(
            "https://api.crossref.org/works",
            params={"query.title": reference.get("title", ""), "rows": 1},
            timeout=12,
        )
        resp.raise_for_status()
        items = resp.json().get("message", {}).get("items", [])
        if items:
            return _parse_crossref_item(items[0])
    except Exception:
        return None
    return None


def lookup_openalex(reference: dict) -> dict | None:
    try:
        params = {"search": reference.get("title", ""), "per-page": 1}
        if reference.get("doi"):
            params = {"filter": f"doi:{normalize_doi(reference['doi'])}", "per-page": 1}
        resp = requests.get("https://api.openalex.org/works", params=params, timeout=12)
        resp.raise_for_status()
        results = resp.json().get("results", [])
        if not results:
            return None
        item = results[0]
        authors = []
        for authorship in item.get("authorships", [])[:6]:
            name = authorship.get("author", {}).get("display_name", "")
            if name:
                authors.append(name)
        doi = normalize_doi(item.get("doi", ""))
        location = item.get("primary_location") or {}
        return {
            "title": item.get("display_name", "Unknown Title"),
            "authors": ", ".join(authors),
            "year": item.get("publication_year", 0) or 0,
            "source": (location.get("source") or {}).get("display_name", "") or "OpenAlex",
            "doi": doi,
            "url": location.get("landing_page_url") or item.get("id", ""),
            "source_engine": "OpenAlex",
        }
    except Exception:
        return None


async def verify_reference(reference: dict) -> dict:
    candidate = lookup_crossref(reference) or lookup_openalex(reference)
    result = compare_reference_metadata(reference, candidate)
    return {
        "reference": reference,
        **result,
    }


async def verify_references(references: list[dict]) -> list[dict]:
    return [await verify_reference(reference) for reference in references]


def _first_author_key(authors: str) -> str:
    first = (authors or "unknown").split(",")[0].strip().split(" ")[-1]
    return re.sub(r"[^a-zA-Z0-9]+", "", first).lower() or "ref"


def build_citation_key(paper: dict, index: int = 1, used_keys: set[str] | None = None) -> str:
    """Build a stable Pandoc/Zotero-style citation key for one paper."""
    year = int(paper.get("year") or 0)
    title_token = normalize_title(paper.get("title", "")).split(" ")[0][:8] if paper.get("title") else ""
    base_key = f"{_first_author_key(paper.get('authors', ''))}{year or 'nd'}{title_token or index}"
    key = base_key
    if used_keys is not None:
        suffix = 2
        while key in used_keys:
            key = f"{base_key}{suffix}"
            suffix += 1
        used_keys.add(key)
    return key


def normalize_papers_with_citation_keys(papers: list[dict]) -> list[dict]:
    """Return copies of papers with a stable citation_key field."""
    used_keys: set[str] = set()
    normalized = []
    for index, paper in enumerate(papers, 1):
        item = dict(paper)
        item["citation_key"] = item.get("citation_key") or build_citation_key(item, index, used_keys)
        normalized.append(item)
    return normalized


def extract_citation_keys(markdown: str) -> list[str]:
    """Extract Pandoc citation keys while ignoring figure/table cross references."""
    text = markdown or ""
    keys: list[str] = []
    seen: set[str] = set()
    for match in re.finditer(r"@([A-Za-z0-9:_\-./]+)", text):
        key = match.group(1).strip()
        if key.startswith(("fig:", "tbl:", "eq:")):
            continue
        if key not in seen:
            keys.append(key)
            seen.add(key)
    return keys


def inspect_citation_closure(markdown: str, papers: list[dict]) -> dict:
    """Compare manuscript citations with project-library citation keys."""
    cited_keys = extract_citation_keys(markdown)
    normalized = normalize_papers_with_citation_keys(papers)
    library_keys = [paper.get("citation_key", "") for paper in normalized if paper.get("citation_key")]
    duplicates = sorted({key for key in library_keys if library_keys.count(key) > 1})
    cited_set = set(cited_keys)
    library_set = set(library_keys)
    missing = sorted(cited_set - library_set)
    unused = sorted(library_set - cited_set)
    used = sorted(cited_set & library_set)
    fix_suggestions = []
    for key in missing:
        fix_suggestions.append({
            "kind": "missing_in_library",
            "key": key,
            "message": f"正文引用 [@{key}] 不在项目库中；请从项目库插入真实 citekey，或把该文献补入项目库。",
        })
    for key in duplicates:
        titles = [paper.get("title", "Untitled") for paper in normalized if paper.get("citation_key") == key]
        fix_suggestions.append({
            "kind": "duplicate_library_key",
            "key": key,
            "message": f"项目库 citekey {key} 重复；请保留一条或重命名其中一条，避免导出时引用错文献。",
            "titles": titles,
        })
    for key in unused[:12]:
        fix_suggestions.append({
            "kind": "unused_library_key",
            "key": key,
            "message": f"项目库文献 {key} 没有被正文引用；正式导出默认不应进入文末参考文献。",
        })
    ok = not missing and not duplicates
    return {
        "ok": ok,
        "cited_keys": cited_keys,
        "library_keys": sorted(library_set),
        "used_library_keys": used,
        "missing_in_library": missing,
        "unused_library_keys": unused,
        "duplicate_library_keys": duplicates,
        "blocking_errors": [*missing, *duplicates],
        "warning_keys": unused,
        "fix_suggestions": fix_suggestions,
        "reference_policy": "only-cited-by-default",
        "summary": (
            f"正文引用 {len(cited_keys)} 个 key，项目库 {len(library_set)} 个 key；"
            f"缺失 {len(missing)} 个，未使用 {len(unused)} 个，重复 {len(duplicates)} 个。"
        ),
    }


def filter_used_reference_papers(markdown: str, papers: list[dict], include_uncited: bool = False) -> list[dict]:
    """Return papers that should appear in final references under the closure policy."""
    normalized = normalize_papers_with_citation_keys(papers)
    if include_uncited:
        return normalized
    cited = set(extract_citation_keys(markdown))
    return [paper for paper in normalized if paper.get("citation_key") in cited]


def _bibtex_escape(value: str) -> str:
    return str(value or "").replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")


def _split_author_name(name: str) -> dict:
    cleaned = " ".join((name or "").strip().split())
    if not cleaned:
        return {"literal": "Unknown"}
    if " " not in cleaned:
        return {"family": cleaned}
    parts = cleaned.split(" ")
    return {"given": " ".join(parts[:-1]), "family": parts[-1]}


def format_bibtex(papers: list[dict]) -> str:
    entries = []
    for index, paper in enumerate(normalize_papers_with_citation_keys(papers), 1):
        year = int(paper.get("year") or 0)
        key = paper.get("citation_key") or build_citation_key(paper, index)
        fields = [
            ("title", paper.get("title", "")),
            ("author", " and ".join([a.strip() for a in (paper.get("authors", "") or "").split(",") if a.strip()])),
            ("year", str(year) if year else ""),
            ("journal", paper.get("source", "")),
            ("doi", normalize_doi(paper.get("doi", ""))),
            ("url", paper.get("url", "")),
        ]
        body = "\n".join([f"  {name} = {{{_bibtex_escape(value)}}}," for name, value in fields if value])
        entries.append(f"@article{{{key},\n{body}\n}}")
    return "\n\n".join(entries)


def format_csl_json(papers: list[dict]) -> list[dict]:
    """Export papers as CSL-JSON for Pandoc, Quarto and citeproc."""
    entries = []
    for index, paper in enumerate(normalize_papers_with_citation_keys(papers), 1):
        year = int(paper.get("year") or 0)
        citation_id = paper.get("citation_key") or build_citation_key(paper, index)
        authors = [
            _split_author_name(author)
            for author in (paper.get("authors", "") or "").split(",")
            if author.strip()
        ]
        entry = {
            "id": citation_id,
            "type": "article-journal",
            "title": paper.get("title", ""),
            "author": authors,
            "issued": {"date-parts": [[year]]} if year else {"date-parts": []},
            "container-title": paper.get("source", ""),
            "DOI": normalize_doi(paper.get("doi", "")),
            "URL": paper.get("url", ""),
        }
        entries.append({key: value for key, value in entry.items() if value not in ("", [], {})})
    return entries


def format_ris(papers: list[dict]) -> str:
    entries = []
    for paper in papers:
        lines = ["TY  - JOUR"]
        lines.append(f"TI  - {paper.get('title', '')}")
        for author in [a.strip() for a in (paper.get("authors", "") or "").split(",") if a.strip()]:
            lines.append(f"AU  - {author}")
        if paper.get("year"):
            lines.append(f"PY  - {paper.get('year')}")
        if paper.get("source"):
            lines.append(f"JO  - {paper.get('source')}")
        if paper.get("doi"):
            lines.append(f"DO  - {normalize_doi(paper.get('doi', ''))}")
        if paper.get("url"):
            lines.append(f"UR  - {paper.get('url')}")
        lines.append("ER  -")
        entries.append("\n".join(lines))
    return "\n\n".join(entries)


def lookup_arxiv(identifier: str) -> dict | None:
    try:
        resp = requests.get(
            "https://export.arxiv.org/api/query",
            params={"id_list": identifier, "max_results": 1},
            timeout=12,
        )
        resp.raise_for_status()
        text = resp.text
        title = re.search(r"<title>(.*?)</title>", text, re.S)
        year = re.search(r"<published>(\d{4})", text)
        authors = re.findall(r"<author>\s*<name>(.*?)</name>\s*</author>", text, re.S)
        if not title:
            return None
        cleaned_title = re.sub(r"\s+", " ", title.group(1)).strip()
        if cleaned_title.lower() == "arxiv query":
            return None
        return {
            "title": cleaned_title,
            "authors": ", ".join([re.sub(r"\s+", " ", a).strip() for a in authors[:8]]),
            "year": int(year.group(1)) if year else 0,
            "source": "arXiv",
            "doi": "",
            "url": f"https://arxiv.org/abs/{identifier}",
            "source_engine": "arXiv",
        }
    except Exception:
        return None


def lookup_pubmed(identifier: str) -> dict | None:
    try:
        resp = requests.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi",
            params={"db": "pubmed", "id": identifier, "retmode": "json"},
            timeout=12,
        )
        resp.raise_for_status()
        item = resp.json().get("result", {}).get(identifier, {})
        if not item.get("title"):
            return None
        authors = [author.get("name", "") for author in item.get("authors", [])[:8] if author.get("name")]
        pubdate = item.get("pubdate", "")
        year = int(pubdate[:4]) if pubdate[:4].isdigit() else 0
        return {
            "title": item.get("title", ""),
            "authors": ", ".join(authors),
            "year": year,
            "source": item.get("fulljournalname", "") or "PubMed",
            "doi": "",
            "url": f"https://pubmed.ncbi.nlm.nih.gov/{identifier}/",
            "source_engine": "PubMed",
        }
    except Exception:
        return None


def lookup_literature_identifier(query: str) -> dict | None:
    parsed = parse_literature_identifier(query)
    if parsed["kind"] == "doi":
        return lookup_crossref({"doi": parsed["value"]}) or lookup_openalex({"doi": parsed["value"]})
    if parsed["kind"] == "arxiv":
        return lookup_arxiv(parsed["value"])
    if parsed["kind"] == "pmid":
        return lookup_pubmed(parsed["value"])
    return lookup_crossref({"title": parsed["value"]}) or lookup_openalex({"title": parsed["value"]})
