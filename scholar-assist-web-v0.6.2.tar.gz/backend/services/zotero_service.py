"""Zotero Web API integration helpers."""
from __future__ import annotations

import re
from html import unescape
from typing import Literal

import requests

from services.publication_service import normalize_zotero_item

ZoteroLibraryKind = Literal["user", "group"]


def extract_better_bibtex_key(data: dict) -> str:
    """Extract a Better BibTeX citekey from Zotero item data when available."""
    candidates = [
        data.get("citationKey", ""),
        data.get("citekey", ""),
    ]
    extra = data.get("extra", "") or ""
    patterns = [
        r"(?:Citation Key|citation key|tex\.ids|bibtex)\s*[:=]\s*([A-Za-z0-9:_\-./]+)",
        r"^([A-Za-z][A-Za-z0-9:_\-./]+)$",
    ]
    for pattern in patterns:
        match = re.search(pattern, extra, re.M)
        if match:
            candidates.append(match.group(1))
    for value in candidates:
        cleaned = re.sub(r"[^A-Za-z0-9:_\-./]+", "", str(value or "").strip())
        if cleaned:
            return cleaned
    return ""


def normalize_zotero_items(items: list[dict]) -> list[dict]:
    child_notes: dict[str, list[str]] = {}
    child_attachments: dict[str, list[str]] = {}
    child_annotations: dict[str, list[str]] = {}
    for item in items:
        data = item.get("data", item or {})
        parent_key = data.get("parentItem", "")
        item_type = data.get("itemType", "")
        if not parent_key:
            continue
        if item_type == "note":
            note_text = re.sub(r"<[^>]+>", " ", str(data.get("note", "")))
            note_text = re.sub(r"\s+", " ", unescape(note_text)).strip()
            if note_text:
                child_notes.setdefault(parent_key, []).append(f"Zotero Note: {note_text}")
        elif item_type == "attachment":
            content_type = str(data.get("contentType", ""))
            if "pdf" not in content_type.lower() and not str(data.get("filename", "")).lower().endswith(".pdf"):
                continue
            filename = data.get("filename") or data.get("title") or "PDF"
            target = data.get("path") or data.get("url") or ""
            attachment = f"Zotero PDF: {filename}"
            if target:
                attachment += f" | {target}"
            child_attachments.setdefault(parent_key, []).append(attachment)
        elif item_type == "annotation":
            quote = re.sub(r"\s+", " ", unescape(str(data.get("annotationText", "")))).strip()
            comment = re.sub(r"\s+", " ", unescape(str(data.get("annotationComment", "")))).strip()
            page = str(data.get("annotationPageLabel") or data.get("pageLabel") or "").strip()
            parts = []
            if quote:
                parts.append(quote)
            if comment:
                parts.append(f"Comment: {comment}")
            if parts:
                page_hint = f" p.{page}" if page else ""
                child_annotations.setdefault(parent_key, []).append(f"Zotero Annotation{page_hint}: " + " | ".join(parts))

    papers = []
    for item in items:
        data = item.get("data", item or {})
        if data.get("itemType") in {"attachment", "note", "annotation"}:
            continue
        paper = normalize_zotero_item(item)
        paper["citation_key"] = extract_better_bibtex_key(data)
        paper["zotero_key"] = data.get("key", item.get("key", ""))
        paper["zotero_version"] = item.get("version", data.get("version", 0))
        paper["source_engine"] = "Zotero"
        parent_key = paper["zotero_key"]
        notes = [
            *(child_attachments.get(parent_key, [])),
            *(child_notes.get(parent_key, [])),
            *(child_annotations.get(parent_key, [])),
        ]
        if paper["citation_key"]:
            notes.insert(0, f"Citation Key: {paper['citation_key']}")
        paper["notes"] = "\n".join(notes)
        papers.append(paper)
    return papers


def detect_zotero_citekey_conflicts(papers: list[dict]) -> dict:
    """Report duplicate or missing Zotero/Better BibTeX citation keys."""
    key_to_titles: dict[str, list[str]] = {}
    missing_titles: list[str] = []
    for paper in papers:
        title = str(paper.get("title") or "Untitled")
        key = str(paper.get("citation_key") or "").strip()
        if not key:
            missing_titles.append(title)
            continue
        key_to_titles.setdefault(key, []).append(title)

    conflicts = [
        {"citation_key": key, "titles": titles}
        for key, titles in key_to_titles.items()
        if len(titles) > 1
    ]
    duplicate_citekeys = [item["citation_key"] for item in conflicts]
    return {
        "ok": not conflicts and not missing_titles,
        "duplicate_citekeys": duplicate_citekeys,
        "conflicts": conflicts,
        "missing_citekey_count": len(missing_titles),
        "missing_citekey_titles": missing_titles[:20],
        "summary": (
            "Zotero citekey 检查通过"
            if not conflicts and not missing_titles
            else f"发现 {len(conflicts)} 组重复 citekey，{len(missing_titles)} 篇缺少 citekey"
        ),
    }


def fetch_zotero_items(
    library_id: str,
    api_key: str = "",
    library_type: ZoteroLibraryKind = "user",
    collection_key: str = "",
    limit: int = 50,
    include_children: bool = True,
    since_version: int = 0,
) -> dict:
    """Fetch Zotero items and normalize them to Scholar Assist papers.

    By default this fetches all items rather than only top-level items so child
    notes and PDF attachments can be merged into their parent papers.
    """
    if not library_id.strip():
        raise ValueError("library_id 不能为空")
    safe_limit = max(1, min(int(limit or 50), 100))
    base = f"https://api.zotero.org/{'users' if library_type == 'user' else 'groups'}/{library_id.strip()}"
    item_path = "items" if include_children else "items/top"
    path = f"/collections/{collection_key.strip()}/{item_path}" if collection_key.strip() else f"/{item_path}"
    headers = {"Zotero-API-Version": "3"}
    if api_key.strip():
        headers["Zotero-API-Key"] = api_key.strip()
    params = {"limit": safe_limit, "format": "json", "include": "data"}
    if since_version and since_version > 0:
        params["since"] = int(since_version)
    resp = requests.get(
        base + path,
        headers=headers,
        params=params,
        timeout=18,
    )
    resp.raise_for_status()
    items = resp.json()
    if not isinstance(items, list):
        items = []
    try:
        library_version = int(resp.headers.get("Last-Modified-Version", 0) or 0)
    except Exception:
        library_version = 0
    papers = normalize_zotero_items(items)
    return {
        "source": "Zotero",
        "count": len(items),
        "library_version": library_version,
        "papers": papers,
        "citekey_report": detect_zotero_citekey_conflicts(papers),
    }
