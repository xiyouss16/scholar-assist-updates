"""
Feature 5: 图表/表格生成
使用 Matplotlib 生成学术图表，Swizz 风格表格
"""
from __future__ import annotations
import io
import base64
import os
import re
from datetime import datetime
from pathlib import Path
import matplotlib
matplotlib.use("Agg")  # 无头模式
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[2]

# ═══════════════════════════════════════════
# Matplotlib 样式设置 (学术风格)
# ═══════════════════════════════════════════

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": [
        "PingFang SC",
        "Hiragino Sans GB",
        "Heiti SC",
        "Songti SC",
        "Noto Sans CJK SC",
        "Microsoft YaHei",
        "SimHei",
        "Arial Unicode MS",
        "Arial",
        "DejaVu Sans",
        "Helvetica",
    ],
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 9,
    "figure.dpi": 150,
    "savefig.dpi": 150,
    "savefig.bbox": "tight",
    "axes.grid": True,
    "axes.unicode_minus": False,
    "grid.alpha": 0.3,
    "axes.spines.top": False,
    "axes.spines.right": False,
})

# 学术配色方案
COLOR_PALETTES = {
    "default": ["#3b82f6", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6", "#06b6d4"],
    "muted": ["#64748b", "#94a3b8", "#cbd5e1", "#e2e8f0", "#f1f5f9", "#f8fafc"],
    "nature": ["#2d6a4f", "#40916c", "#52b788", "#74c69d", "#95d5b2", "#b7e4c7"],
    "contrast": ["#1e293b", "#dc2626", "#2563eb", "#ca8a04", "#16a34a", "#7c3aed"],
    "nature_journal": ["#2F5D62", "#D9822B", "#7A9E7E", "#8A5A83", "#4B78A8", "#C44536"],
}

# ═══════════════════════════════════════════
# 图表示例生成函数
# ═══════════════════════════════════════════

def generate_bar_chart(
    categories: list[str],
    values: list[float],
    title: str = "",
    xlabel: str = "",
    ylabel: str = "",
    color_palette: str = "default",
    error_bars: list[float] | None = None,
) -> str:
    """生成柱状图，返回 base64 PNG"""
    colors = COLOR_PALETTES.get(color_palette, COLOR_PALETTES["default"])
    fig, ax = plt.subplots(figsize=(8, 5))

    x = np.arange(len(categories))
    bars = ax.bar(x, values, color=colors[:len(categories)], edgecolor="white", linewidth=0.5)

    if error_bars:
        ax.errorbar(x, values, yerr=error_bars, fmt="none", ecolor="gray", capsize=4, linewidth=1)

    ax.set_xticks(x)
    ax.set_xticklabels(categories, rotation=25, ha="right")
    ax.set_ylabel(ylabel)
    ax.set_xlabel(xlabel)
    ax.set_title(title, fontweight="bold", pad=12)

    # 数值标签
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + max(values) * 0.01,
                f"{val:.2g}", ha="center", va="bottom", fontsize=9)

    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()

def generate_line_chart(
    x_data: list,
    y_series: dict[str, list[float]],  # {series_name: [values]}
    title: str = "",
    xlabel: str = "",
    ylabel: str = "",
    color_palette: str = "default",
) -> str:
    """生成折线图，返回 base64 PNG"""
    colors = COLOR_PALETTES.get(color_palette, COLOR_PALETTES["default"])
    fig, ax = plt.subplots(figsize=(8, 5))

    for i, (name, values) in enumerate(y_series.items()):
        color = colors[i % len(colors)]
        ax.plot(x_data, values, marker="o", label=name, color=color, linewidth=2, markersize=5)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight="bold", pad=12)
    ax.legend(frameon=True, fancybox=False, edgecolor="lightgray")

    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()

def generate_scatter_chart(
    x_values: list[float],
    y_values: list[float],
    title: str = "",
    xlabel: str = "",
    ylabel: str = "",
    labels: list[str] | None = None,
) -> str:
    """生成散点图"""
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.scatter(x_values, y_values, c="#3b82f6", s=60, alpha=0.7, edgecolors="white", linewidth=0.5)

    if labels:
        for i, label in enumerate(labels):
            ax.annotate(label, (x_values[i], y_values[i]),
                       textcoords="offset points", xytext=(5, 5), fontsize=7, alpha=0.8)

    # 趋势线
    if len(x_values) > 1:
        z = np.polyfit(x_values, y_values, 1)
        p = np.poly1d(z)
        x_sorted = np.sort(x_values)
        ax.plot(x_sorted, p(x_sorted), "--", color="red", alpha=0.5, linewidth=1, label="Trend")

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight="bold", pad=12)
    ax.legend()

    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()

def generate_pie_chart(
    labels: list[str],
    values: list[float],
    title: str = "",
    color_palette: str = "default",
) -> str:
    """生成饼图"""
    colors = COLOR_PALETTES.get(color_palette, COLOR_PALETTES["default"])
    fig, ax = plt.subplots(figsize=(7, 7))

    wedges, texts, autotexts = ax.pie(
        values, labels=labels, autopct="%1.1f%%",
        colors=colors[:len(labels)],
        startangle=90, pctdistance=0.8,
        wedgeprops={"edgecolor": "white", "linewidth": 1.5},
    )

    for autotext in autotexts:
        autotext.set_fontsize(9)
        autotext.set_fontweight("bold")

    ax.set_title(title, fontweight="bold", pad=15)

    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()

# ═══════════════════════════════════════════
# 从上传数据生成图表
# ═══════════════════════════════════════════

async def generate_chart_from_data(
    data: dict,
    chart_type: str,
    title: str = "",
    xlabel: str = "",
    ylabel: str = "",
    color_palette: str = "default",
) -> str:
    """
    根据上传的数据和图表类型生成图表
    data: { "categories": [...], "values": [...], "series": {...} }
    chart_type: "bar" | "line" | "scatter" | "pie"
    """
    try:
        if chart_type == "bar":
            return generate_bar_chart(
                data.get("categories", []),
                data.get("values", []),
                title=title, xlabel=xlabel, ylabel=ylabel,
                color_palette=color_palette,
            )
        elif chart_type == "line":
            x_data = data.get("x_data", list(range(len(next(iter(data.get("series", {}).values()), [])))))
            return generate_line_chart(
                x_data,
                data.get("series", {}),
                title=title, xlabel=xlabel, ylabel=ylabel,
                color_palette=color_palette,
            )
        elif chart_type == "scatter":
            return generate_scatter_chart(
                data.get("x", []),
                data.get("y", []),
                title=title, xlabel=xlabel, ylabel=ylabel,
            )
        elif chart_type == "pie":
            return generate_pie_chart(
                data.get("categories", []),
                data.get("values", []),
                title=title, color_palette=color_palette,
            )
        else:
            return ""
    except Exception as e:
        print(f"[Chart] 生成图表出错: {e}")
        return ""


def _safe_chart_filename(title: str, chart_type: str) -> str:
    """Build a filesystem-safe chart filename."""
    raw = (title or chart_type or "figure").strip().lower()
    slug = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "-", raw).strip("-")
    slug = slug[:48] or "figure"
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return f"{stamp}-{slug}.png"


def save_chart_artifact(
    chart_base64: str,
    title: str = "",
    chart_type: str = "chart",
    output_dir: str | Path | None = None,
) -> dict:
    """Persist a generated chart and return file metadata.

    The app still uses the base64 data URL for immediate preview, while this
    file artifact gives exports and users a concrete image to reuse later.
    """
    if not chart_base64:
        return {}
    target_dir = Path(
        output_dir
        or os.getenv("SCHOLAR_ASSIST_FIGURE_DIR")
        or REPO_ROOT / "outputs" / "figures"
    )
    target_dir.mkdir(parents=True, exist_ok=True)
    filename = _safe_chart_filename(title, chart_type)
    file_path = target_dir / filename
    file_path.write_bytes(base64.b64decode(chart_base64))
    try:
        relative_path = file_path.relative_to(REPO_ROOT).as_posix()
    except ValueError:
        relative_path = file_path.as_posix()
    return {
        "filename": filename,
        "file_path": file_path.as_posix(),
        "relative_path": relative_path,
    }

# ═══════════════════════════════════════════
# LaTeX 表格生成
# ═══════════════════════════════════════════

def generate_latex_table(
    headers: list[str],
    rows: list[list[str]],
    caption: str = "",
    label: str = "",
    table_type: str = "three-line",  # "three-line" (三线表) or "full-grid"
) -> str:
    """生成 LaTeX 学术表格"""
    def escape_latex(s: str) -> str:
        return str(s).replace("&", "\\&").replace("%", "\\%").replace("$", "\\$").replace("#", "\\#").replace("_", "\\_")

    ncols = len(headers)
    col_spec = "c" * ncols if table_type != "three-line" else "|" + "|".join(["c"] * ncols) + "|"

    latex = ""
    if table_type == "three-line":
        # 三线表 (学术论文标准)
        latex += "\\begin{table}[htbp]\n"
        latex += "  \\centering\n"
        latex += f"  \\caption{{{escape_latex(caption)}}}\n"
        if label:
            latex += f"  \\label{{{label}}}\n"
        latex += "  \\begin{tabular}{" + col_spec + "}\n"
        latex += "    \\toprule\n"
        latex += "    " + " & ".join(f"\\textbf{{{escape_latex(h)}}}" for h in headers) + " \\\\\n"
        latex += "    \\midrule\n"
        for row in rows:
            latex += "    " + " & ".join(escape_latex(c) for c in row) + " \\\\\n"
        latex += "    \\bottomrule\n"
        latex += "  \\end{tabular}\n"
        latex += "\\end{table}\n"
    else:
        # 全网格表
        latex += "\\begin{table}[htbp]\n"
        latex += "  \\centering\n"
        latex += f"  \\caption{{{escape_latex(caption)}}}\n"
        if label:
            latex += f"  \\label{{{label}}}\n"
        latex += "  \\begin{tabular}{" + col_spec + "}\n"
        latex += "    \\hline\n"
        latex += "    " + " & ".join(f"\\textbf{{{escape_latex(h)}}}" for h in headers) + " \\\\\n"
        latex += "    \\hline\n"
        for row in rows:
            latex += "    " + " & ".join(escape_latex(c) for c in row) + " \\\\\n"
            latex += "    \\hline\n"
        latex += "  \\end{tabular}\n"
        latex += "\\end{table}\n"

    return latex

def generate_markdown_table(
    headers: list[str],
    rows: list[list[str]],
    caption: str = "",
) -> str:
    """生成 Markdown 表格"""
    md = ""
    if caption:
        md += f"**{caption}**\n\n"
    md += "| " + " | ".join(headers) + " |\n"
    md += "| " + " | ".join(["---"] * len(headers)) + " |\n"
    for row in rows:
        md += "| " + " | ".join(row) + " |\n"
    return md


# ═══════════════════════════════════════════
# Nature Figure 工作流
# ═══════════════════════════════════════════

NATURE_FIGURE_ARCHETYPES = {
    "benchmark": {
        "label": "Benchmark / model comparison",
        "panels": ["task schema", "main metric", "ablation", "failure analysis"],
    },
    "mechanism": {
        "label": "Mechanism-led composite",
        "panels": ["conceptual mechanism", "representative evidence", "quantification", "validation"],
    },
    "spatial": {
        "label": "Spatial / imaging systems",
        "panels": ["overview map", "zoomed examples", "profile or distribution", "correlation"],
    },
    "single_cell": {
        "label": "Single-cell systems figure",
        "panels": ["embedding", "composition", "marker heatmap", "trajectory or enrichment"],
    },
}


def _select_nature_archetype(topic: str, evidence_items: list[str]) -> str:
    text = f"{topic} {' '.join(evidence_items)}".lower()
    if any(token in text for token in ["single-cell", "single cell", "单细胞", "umap", "marker"]):
        return "single_cell"
    if any(token in text for token in ["空间", "spatial", "显微", "microscopy", "image", "图像"]):
        return "spatial"
    if any(token in text for token in ["机制", "mechanism", "pathway", "材料", "material"]):
        return "mechanism"
    return "benchmark"


def _default_evidence_items(topic: str) -> list[str]:
    return [
        f"{topic or '研究主题'}的核心流程或任务定义",
        "主要性能指标与强基线对比",
        "消融实验或敏感性分析",
        "失败案例、适用边界或可解释性证据",
    ]


def _panel_letter(index: int) -> str:
    return chr(ord("a") + index)


def _trim_sentence_end(text: str) -> str:
    return (text or "").rstrip("。.!！ ")


def build_nature_source_data_template(panel_map: list[dict]) -> str:
    """Create a CSV skeleton that makes every panel traceable to source data."""
    rows = ["panel,role,evidence,metric,n,value,uncertainty,source_file,notes"]
    for panel in panel_map:
        rows.append(
            ",".join([
                panel["panel"],
                f'"{panel["role"]}"',
                f'"{panel["evidence"]}"',
                "USER_DATA_REQUIRED",
                "USER_DATA_REQUIRED",
                "USER_DATA_REQUIRED",
                "USER_DATA_REQUIRED",
                "source_data.csv",
                "replace this row with traced measurements before export",
            ])
        )
    return "\n".join(rows)


def build_nature_panel_map(topic: str, conclusion: str, evidence_items: list[str], archetype: str) -> list[dict]:
    """Create a reviewable Nature-style panel map from the figure contract."""
    evidence = [item.strip() for item in evidence_items if item.strip()] or _default_evidence_items(topic)
    archetype_info = NATURE_FIGURE_ARCHETYPES.get(archetype, NATURE_FIGURE_ARCHETYPES["benchmark"])
    chart_hints = ["schematic", "bar_with_points", "line_or_heatmap", "scatter_or_examples", "forest_or_distribution"]
    panel_map = []
    for index, panel_role in enumerate(archetype_info["panels"]):
        item = evidence[index % len(evidence)]
        panel_map.append({
            "panel": _panel_letter(index),
            "role": panel_role,
            "question": "What evidence directly supports the conclusion?" if index == 1 else "What must the reader learn here?",
            "evidence": item,
            "chart_type": chart_hints[index % len(chart_hints)],
            "review_risk": "Missing source data or statistics will weaken this panel." if index > 0 else "Over-complex schematic can obscure the main claim.",
        })
    return panel_map


def _python_nature_script(title: str, panel_map: list[dict]) -> str:
    panel_comments = "\n".join(
        f"# Panel {panel['panel']}: {panel['role']} | {panel['chart_type']} | {panel['evidence']}"
        for panel in panel_map
    )
    safe_title = title.replace('"', "'")[:64]
    return f'''"""
Nature-style multi-panel figure scaffold.
This script refuses to plot until source_data.csv contains real traced measurements.
"""
import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams.update({{
    "font.family": "Arial",
    "font.size": 7,
    "axes.linewidth": 0.7,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "savefig.bbox": "tight",
}})

palette = ["#2F5D62", "#D9822B", "#7A9E7E", "#8A5A83", "#4B78A8"]
source = pd.read_csv("source_data.csv")
required = {{"panel", "metric", "n", "value", "uncertainty"}}
missing = required - set(source.columns)
if missing:
    raise ValueError(f"source_data.csv is missing columns: {{sorted(missing)}}")
if source.astype(str).apply(lambda col: col.str.contains("USER_DATA_REQUIRED", na=False)).any().any():
    raise ValueError("source_data.csv still contains USER_DATA_REQUIRED placeholders.")
source["value"] = pd.to_numeric(source["value"], errors="raise")
source["uncertainty"] = pd.to_numeric(source["uncertainty"], errors="coerce").fillna(0)

{panel_comments}

mosaic = """
AB
CD
"""
fig, axd = plt.subplot_mosaic(mosaic, figsize=(7.2, 5.6), constrained_layout=True)
for label, ax in axd.items():
    ax.text(-0.12, 1.08, label.lower(), transform=ax.transAxes, fontsize=9, fontweight="bold", va="top")
    ax.grid(alpha=0.18, linewidth=0.5)
    panel = source[source["panel"].astype(str).str.lower() == label.lower()]
    if panel.empty:
        ax.text(0.5, 0.5, "No source data", ha="center", va="center", transform=ax.transAxes)
        ax.set_axis_off()
        continue
    labels = panel["metric"].astype(str).tolist()
    x = range(len(panel))
    panel_colors = [palette[i % len(palette)] for i in range(len(panel))]
    ax.bar(x, panel["value"], yerr=panel["uncertainty"], color=panel_colors, width=0.68, capsize=2)
    ax.set_xticks(list(x), labels, rotation=25, ha="right")
    ax.set_ylabel("Value")

axd["A"].set_title("{safe_title}")

fig.savefig("nature_figure.svg")
fig.savefig("nature_figure.pdf")
fig.savefig("nature_figure.png", dpi=600)
'''


def _r_nature_script(title: str, panel_map: list[dict]) -> str:
    panel_comments = "\n".join(
        f"# Panel {panel['panel']}: {panel['role']} | {panel['chart_type']} | {panel['evidence']}"
        for panel in panel_map
    )
    safe_title = title.replace('"', "'")[:64]
    return f'''# Nature-style multi-panel figure scaffold.
# This script refuses to plot until source_data.csv contains real traced measurements.
library(ggplot2)
library(patchwork)

theme_nature <- function(base_size = 7) {{
  theme_classic(base_size = base_size) +
    theme(
      text = element_text(family = "Arial"),
      axis.line = element_line(linewidth = 0.3),
      legend.position = "top",
      plot.title = element_text(face = "bold", size = base_size + 1)
    )
}}

palette <- c("#2F5D62", "#D9822B", "#7A9E7E", "#8A5A83", "#4B78A8")
source <- read.csv("source_data.csv", stringsAsFactors = FALSE)
required <- c("panel", "metric", "n", "value", "uncertainty")
missing <- setdiff(required, names(source))
if (length(missing) > 0) stop(paste("source_data.csv is missing columns:", paste(missing, collapse = ", ")))
if (any(grepl("USER_DATA_REQUIRED", as.matrix(source)))) stop("source_data.csv still contains USER_DATA_REQUIRED placeholders.")
source$value <- as.numeric(source$value)
source$uncertainty <- as.numeric(source$uncertainty)

{panel_comments}

panel_a <- subset(source, panel == "a")
p_a <- ggplot(panel_a, aes(metric, value, fill = metric)) +
  geom_col(width = .68) +
  geom_errorbar(aes(ymin = value - uncertainty, ymax = value + uncertainty), width = .16) +
  scale_fill_manual(values = palette) +
  labs(title = "{safe_title}", y = "Value", x = NULL) +
  theme_nature() +
  theme(axis.text.x = element_text(angle = 25, hjust = 1), legend.position = "none")

panel_b <- subset(source, panel == "b")
p_b <- ggplot(panel_b, aes(metric, value, fill = metric)) +
  geom_col(width = .68) +
  geom_errorbar(aes(ymin = value - uncertainty, ymax = value + uncertainty), width = .16) +
  scale_fill_manual(values = palette) +
  labs(x = NULL, y = "Value") +
  theme_nature() +
  theme(axis.text.x = element_text(angle = 25, hjust = 1), legend.position = "none")

figure <- (p_a | p_b) + plot_annotation(tag_levels = "a")
ggsave("nature_figure.svg", figure, width = 7.2, height = 3.6, device = "svg")
ggsave("nature_figure.pdf", figure, width = 7.2, height = 3.6, device = cairo_pdf)
ggsave("nature_figure.png", figure, width = 7.2, height = 3.6, dpi = 600)
'''


def build_nature_figure_workflow(
    topic: str,
    conclusion: str,
    evidence_items: list[str] | None = None,
    backend: str = "python",
    journal: str = "Nature / high-impact journal",
) -> dict:
    """Build a Nature Figure skill-inspired contract, panel map and plotting scaffold."""
    clean_topic = (topic or "未命名研究主题").strip()
    has_conclusion = bool((conclusion or "").strip())
    clean_conclusion = (conclusion or f"{clean_topic} 的核心科学结论待作者补充").strip()
    clean_backend = backend if backend in {"python", "r"} else "python"
    evidence = [str(item).strip() for item in (evidence_items or []) if str(item).strip()]
    archetype = _select_nature_archetype(clean_topic, evidence)
    panel_map = build_nature_panel_map(clean_topic, clean_conclusion, evidence, archetype)
    contract = {
        "core_conclusion": clean_conclusion,
        "topic": clean_topic,
        "archetype": NATURE_FIGURE_ARCHETYPES[archetype]["label"],
        "backend": clean_backend,
        "journal": journal or "Nature / high-impact journal",
        "export_targets": ["SVG editable source", "PDF vector", "PNG/TIFF 600 dpi preview"],
        "source_data_rule": "Every plotted value must be traceable to a source table, notebook, or raw-image measurement.",
        "statistics_rule": "Show replicate-level points, uncertainty, sample size and test where applicable.",
    }
    script = _python_nature_script(clean_topic, panel_map) if clean_backend == "python" else _r_nature_script(clean_topic, panel_map)
    source_data_template = build_nature_source_data_template(panel_map)
    caption_conclusion = _trim_sentence_end(clean_conclusion)
    caption = (
        f"Figure 1 | {caption_conclusion}. "
        f"Panels summarize {clean_topic}: "
        + "; ".join(f"({panel['panel']}) {panel['role']} using {panel['evidence']}" for panel in panel_map)
        + ". Source data and statistical tests should be reported for all quantitative panels."
    )
    qa_checks = [
        {"label": "核心结论", "ok": has_conclusion, "hint": "每张主图必须只服务一个由作者确认的核心结论。"},
        {"label": "证据链", "ok": bool(evidence), "hint": "请提供可回到真实数据或实验记录的证据，再组织 panel。"},
        {"label": "源数据追踪", "ok": False, "hint": "先把 source_data.csv 中的 USER_DATA_REQUIRED 替换为真实测量数据，再定稿导出。"},
        {"label": "矢量导出", "ok": True, "hint": "优先 SVG/PDF，位图预览不作为最终源文件。"},
    ]
    export_checklist = "\n".join([
        "- Export SVG/PDF first; keep text editable.",
        "- Export PNG/TIFF at 600 dpi only for preview or submission portals.",
        "- Use lowercase panel labels and keep them outside the data area.",
        "- Replace simulated arrays with source-data tables before submission.",
        "- Add n, uncertainty definition, and statistical test to caption or Methods.",
    ])
    markdown = "\n".join([
        "## Nature Figure 工作流",
        "",
        f"**核心结论**：{contract['core_conclusion']}",
        f"**图型原型**：{contract['archetype']}",
        f"**绘图后端**：{clean_backend}",
        "",
        "### Panel map",
        "| Panel | 作用 | 证据 | 图型建议 | 审稿风险 |",
        "|---|---|---|---|---|",
        *[
            f"| {panel['panel']} | {panel['role']} | {panel['evidence']} | {panel['chart_type']} | {panel['review_risk']} |"
            for panel in panel_map
        ],
        "",
        "### Figure legend",
        caption,
        "",
        "### Export QA",
        export_checklist,
        "",
        "### Source data template",
        "```csv",
        source_data_template,
        "```",
        "",
        f"```{clean_backend if clean_backend == 'r' else 'python'}",
        script.strip(),
        "```",
    ])
    return {
        "backend": clean_backend,
        "contract": contract,
        "panel_map": panel_map,
        "caption": caption,
        "script": script,
        "qa_checks": qa_checks,
        "export_checklist": export_checklist,
        "source_data_template": source_data_template,
        "markdown": markdown,
    }


def render_nature_figure_assets(
    topic: str,
    conclusion: str,
    evidence_items: list[str] | None = None,
    backend: str = "python",
    journal: str = "Nature / high-impact journal",
    output_dir: str | Path | None = None,
    source_data_csv: str | None = None,
    source_data_file_base64: str | None = None,
    source_data_filename: str = "",
) -> dict:
    """Render a multi-panel figure only from user-provided, traceable source data."""
    workflow = build_nature_figure_workflow(topic, conclusion, evidence_items, backend, journal)
    panel_map = workflow["panel_map"]
    contract = workflow["contract"]
    target_dir = Path(
        output_dir
        or os.getenv("SCHOLAR_ASSIST_FIGURE_DIR")
        or REPO_ROOT / "outputs" / "figures"
    )
    target_dir.mkdir(parents=True, exist_ok=True)
    filename = _safe_chart_filename(contract["topic"], "nature-figure")
    stem = Path(filename).stem
    png_path = target_dir / f"{stem}.png"
    svg_path = target_dir / f"{stem}.svg"
    pdf_path = target_dir / f"{stem}.pdf"
    source_data_path = target_dir / f"{stem}-source_data.csv"
    source_data_input_path: Path | None = None
    source_data_format = ""
    if source_data_file_base64:
        source_data, source_data_csv_text, source_data_format, original_bytes, safe_input_name = _parse_nature_source_data_file(
            source_data_file_base64,
            source_data_filename,
        )
        source_data_csv = source_data_csv_text
        source_data_input_path = target_dir / f"{stem}-{safe_input_name}"
        source_data_input_path.write_bytes(original_bytes)
    else:
        source_data = _parse_nature_source_data_csv(source_data_csv) if source_data_csv else None
        source_data_format = "csv" if source_data is not None else ""
    if source_data is None:
        raise ValueError("生成主图需要真实 CSV 或 Excel 源数据；工作流规划不会代替实验数据。")

    source_data_csv = source_data_csv or ""
    source_data_path.write_text(source_data_csv.strip() + "\n", encoding="utf-8")
    workflow["qa_checks"][2] = {
        "label": "源数据追踪",
        "ok": True,
        "hint": "已使用用户提供的 source_data.csv 生成图表；请在方法或补充材料中保留原始测量文件。",
    }

    plt.rcParams.update({
        "font.size": 8,
        "axes.titlesize": 9,
        "axes.labelsize": 8,
        "xtick.labelsize": 7,
        "ytick.labelsize": 7,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })
    colors = COLOR_PALETTES["nature_journal"]
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.6), constrained_layout=True)
    flat_axes = axes.flatten()
    fig.suptitle(contract["topic"], x=0.02, y=1.02, ha="left", fontsize=11, fontweight="bold")

    for index, ax in enumerate(flat_axes):
        panel = panel_map[index % len(panel_map)]
        ax.text(-0.12, 1.08, panel["panel"], transform=ax.transAxes, fontsize=11, fontweight="bold", va="top")
        ax.set_title(panel["role"], loc="left", fontweight="bold")
        ax.grid(alpha=0.18, linewidth=0.5)
        panel_rows = source_data[source_data["panel"].astype(str).str.lower() == panel["panel"]]
        if panel_rows.empty:
            ax.text(0.5, 0.5, "No traced source data", ha="center", va="center", transform=ax.transAxes)
            ax.set_axis_off()
            continue
        x = np.arange(len(panel_rows))
        values = panel_rows["value"].to_numpy(dtype=float)
        uncertainty = panel_rows["uncertainty"].to_numpy(dtype=float)
        labels = panel_rows["metric"].astype(str).tolist()
        bar_colors = [colors[i % len(colors)] for i in range(len(panel_rows))]
        ax.bar(x, values, yerr=uncertainty, color=bar_colors, width=0.64, capsize=2, alpha=0.92)
        ax.set_xticks(x, labels, rotation=25, ha="right")
        ax.set_ylabel("Value")
        ax.text(
            0.02,
            0.02,
            f"n={', '.join(panel_rows['n'].astype(str).unique())}",
            transform=ax.transAxes,
            fontsize=7,
            color="#475569",
        )

    fig.text(0.02, -0.02, _trim_sentence_end(contract["core_conclusion"]), ha="left", fontsize=8, color="#334155")
    fig.savefig(png_path, dpi=300, bbox_inches="tight")
    fig.savefig(svg_path, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)

    png_base64 = base64.b64encode(png_path.read_bytes()).decode("ascii")

    def rel(path: Path) -> str:
        try:
            return path.relative_to(REPO_ROOT).as_posix()
        except ValueError:
            return path.as_posix()

    assets = {
        "png": {"file_path": png_path.as_posix(), "relative_path": rel(png_path)},
        "svg": {"file_path": svg_path.as_posix(), "relative_path": rel(svg_path)},
        "pdf": {"file_path": pdf_path.as_posix(), "relative_path": rel(pdf_path)},
    }
    assets["source_data"] = {"file_path": source_data_path.as_posix(), "relative_path": rel(source_data_path)}
    if source_data_input_path is not None:
        assets["source_data_input"] = {"file_path": source_data_input_path.as_posix(), "relative_path": rel(source_data_input_path)}
    source_note = f"\n\nSource data: `{rel(source_data_path)}`"
    return {
        "workflow": workflow,
        "assets": assets,
        "chart_base64": png_base64,
        "mime_type": "image/png",
        "used_source_data": True,
        "source_data_format": source_data_format,
        "source_data_path": source_data_path.as_posix(),
        "markdown": f"![Figure 1：{contract['topic']}](data:image/png;base64,{png_base64})\n\n{workflow['caption']}{source_note}",
    }


def _parse_nature_source_data_csv(source_data_csv: str) -> pd.DataFrame:
    """Validate user-provided source data before rendering a figure."""
    source = pd.read_csv(io.StringIO(source_data_csv))
    return _validate_nature_source_data_frame(source, "source_data_csv")


def _safe_uploaded_source_filename(filename: str) -> str:
    raw = Path(filename or "source_data.csv").name
    stem = re.sub(r"[^a-zA-Z0-9_\-\u4e00-\u9fff]+", "-", Path(raw).stem).strip("-") or "source-data"
    suffix = Path(raw).suffix.lower() or ".csv"
    if suffix not in {".csv", ".xls", ".xlsx"}:
        suffix = ".csv"
    return f"{stem[:40]}{suffix}"


def _parse_nature_source_data_file(source_data_file_base64: str, filename: str) -> tuple[pd.DataFrame, str, str, bytes, str]:
    """Decode CSV/XLS/XLSX source data and normalize it into source_data.csv."""
    try:
        raw_bytes = base64.b64decode(source_data_file_base64)
    except Exception as exc:
        raise ValueError("source_data_file_base64 is not valid base64.") from exc
    safe_name = _safe_uploaded_source_filename(filename)
    suffix = Path(safe_name).suffix.lower()
    if suffix == ".csv":
        csv_text = raw_bytes.decode("utf-8-sig")
        source = _parse_nature_source_data_csv(csv_text)
        return source, csv_text, "csv", raw_bytes, safe_name
    if suffix in {".xls", ".xlsx"}:
        try:
            source = pd.read_excel(io.BytesIO(raw_bytes))
        except Exception as exc:
            raise ValueError("Excel source data could not be read; please upload .xlsx/.xls with a flat first sheet.") from exc
        source = _validate_nature_source_data_frame(source, "source_data_excel")
        csv_text = source.to_csv(index=False)
        return source, csv_text, suffix.lstrip("."), raw_bytes, safe_name
    raise ValueError("Only CSV, XLS and XLSX source data files are supported.")


def _validate_nature_source_data_frame(source: pd.DataFrame, label: str) -> pd.DataFrame:
    required = {"panel", "metric", "n", "value", "uncertainty"}
    missing = required - set(source.columns)
    if missing:
        raise ValueError(f"{label} is missing columns: {sorted(missing)}")
    if source.astype(str).apply(lambda col: col.str.contains("USER_DATA_REQUIRED", na=False)).any().any():
        raise ValueError(f"{label} still contains USER_DATA_REQUIRED placeholders.")
    if source.empty:
        raise ValueError(f"{label} is empty.")
    source["panel"] = source["panel"].astype(str).str.strip().str.lower()
    source["metric"] = source["metric"].astype(str).str.strip()
    source["value"] = pd.to_numeric(source["value"], errors="raise")
    source["uncertainty"] = pd.to_numeric(source["uncertainty"], errors="coerce").fillna(0)
    return source
