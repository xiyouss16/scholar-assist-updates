"""SQLite-backed project library service for the web runtime."""
from __future__ import annotations

import os
import sqlite3
import hashlib
import json
import uuid
import re
from difflib import SequenceMatcher
from pathlib import Path


class ClosingConnection(sqlite3.Connection):
    def __exit__(self, exc_type, exc_value, traceback):
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


def get_library_db_path() -> Path:
    configured = os.getenv("SCHOLAR_ASSIST_LIBRARY_DB", "").strip()
    if configured:
        path = Path(configured).expanduser()
    else:
        path = Path.home() / ".scholar-assist" / "scholar_assist_web.db"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def connect_library_db() -> sqlite3.Connection:
    conn = sqlite3.connect(get_library_db_path(), factory=ClosingConnection)
    conn.row_factory = sqlite3.Row
    init_library_db(conn)
    return conn


def init_library_db(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        PRAGMA journal_mode=WAL;
        PRAGMA foreign_keys=ON;

        CREATE TABLE IF NOT EXISTS workspaces (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        INSERT OR IGNORE INTO workspaces (id, name, description)
        VALUES ('default', '默认工作区', '本机和早期版本兼容工作区');

        CREATE TABLE IF NOT EXISTS libraries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            workspace_id TEXT NOT NULL DEFAULT 'default',
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS papers (
            id TEXT PRIMARY KEY,
            workspace_id TEXT NOT NULL DEFAULT 'default',
            title TEXT NOT NULL,
            authors TEXT DEFAULT '',
            year INTEGER DEFAULT 0,
            source TEXT DEFAULT '',
            abstract_text TEXT DEFAULT '',
            url TEXT DEFAULT '',
            doi TEXT DEFAULT '',
            citations INTEGER DEFAULT 0,
            keywords TEXT DEFAULT '',
            source_engine TEXT DEFAULT '',
            citation_key TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            document_id TEXT DEFAULT '',
            pdf_filename TEXT DEFAULT '',
            full_text TEXT DEFAULT '',
            total_pages INTEGER DEFAULT 0,
            page_segments_json TEXT DEFAULT '[]',
            page_layouts_json TEXT DEFAULT '[]',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS library_papers (
            library_id INTEGER NOT NULL,
            paper_id TEXT NOT NULL,
            added_at TEXT DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (library_id, paper_id),
            FOREIGN KEY (library_id) REFERENCES libraries(id) ON DELETE CASCADE,
            FOREIGN KEY (paper_id) REFERENCES papers(id) ON DELETE CASCADE
        );
        """
    )
    _ensure_column(conn, "libraries", "workspace_id", "TEXT NOT NULL DEFAULT 'default'")
    _ensure_column(conn, "papers", "workspace_id", "TEXT NOT NULL DEFAULT 'default'")
    _ensure_column(conn, "papers", "citation_key", "TEXT DEFAULT ''")
    _ensure_column(conn, "papers", "document_id", "TEXT DEFAULT ''")
    _ensure_column(conn, "papers", "pdf_filename", "TEXT DEFAULT ''")
    _ensure_column(conn, "papers", "full_text", "TEXT DEFAULT ''")
    _ensure_column(conn, "papers", "total_pages", "INTEGER DEFAULT 0")
    _ensure_column(conn, "papers", "page_segments_json", "TEXT DEFAULT '[]'")
    _ensure_column(conn, "papers", "page_layouts_json", "TEXT DEFAULT '[]'")
    conn.execute("UPDATE libraries SET workspace_id = 'default' WHERE workspace_id IS NULL OR workspace_id = ''")
    conn.execute("UPDATE papers SET workspace_id = 'default' WHERE workspace_id IS NULL OR workspace_id = ''")
    conn.commit()


def _ensure_column(conn: sqlite3.Connection, table: str, column: str, definition: str) -> None:
    columns = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in columns:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def _workspace_id(workspace_id: str | None = None) -> str:
    value = (workspace_id or "default").strip()
    return value or "default"


def _storage_paper_id(workspace_id: str, paper_id: str) -> str:
    if workspace_id == "default" or paper_id.startswith(f"{workspace_id}::"):
        return paper_id
    return f"{workspace_id}::{paper_id}"


def _public_paper_id(row_id: str, workspace_id: str | None = None) -> str:
    prefix = f"{workspace_id}::" if workspace_id else ""
    if prefix and row_id.startswith(prefix):
        return row_id[len(prefix):]
    if "::" in row_id and row_id.startswith("ws_"):
        return row_id.split("::", 1)[1]
    return row_id


def _workspace_from_row(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "name": row["name"],
        "description": row["description"] or "",
        "created_at": row["created_at"] or "",
        "updated_at": row["updated_at"] or row["created_at"] or "",
        "library_count": row["library_count"],
        "paper_count": row["paper_count"],
    }


def _library_from_row(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "name": row["name"],
        "description": row["description"] or "",
        "created_at": row["created_at"] or "",
        "paper_count": row["paper_count"],
    }


def _paper_from_row(row: sqlite3.Row) -> dict:
    def json_list(column: str) -> list:
        if column not in row.keys() or not row[column]:
            return []
        try:
            value = json.loads(row[column])
            return value if isinstance(value, list) else []
        except (TypeError, json.JSONDecodeError):
            return []

    return {
        "id": _public_paper_id(row["id"], row["workspace_id"] if "workspace_id" in row.keys() else None),
        "title": row["title"],
        "authors": row["authors"] or "",
        "year": row["year"] or 0,
        "source": row["source"] or "",
        "abstract_text": row["abstract_text"] or "",
        "url": row["url"] or "",
        "doi": row["doi"] or "",
        "citations": row["citations"] or 0,
        "keywords": row["keywords"] or "",
        "source_engine": row["source_engine"] or "",
        "citation_key": (row["citation_key"] or "") if "citation_key" in row.keys() else "",
        "notes": row["notes"] or "",
        "document_id": (row["document_id"] or "") if "document_id" in row.keys() else "",
        "pdf_filename": (row["pdf_filename"] or "") if "pdf_filename" in row.keys() else "",
        "full_text": (row["full_text"] or "") if "full_text" in row.keys() else "",
        "total_pages": int(row["total_pages"] or 0) if "total_pages" in row.keys() else 0,
        "page_segments": json_list("page_segments_json"),
        "page_layouts": json_list("page_layouts_json"),
    }


def create_workspace(name: str, description: str = "") -> dict:
    workspace_id = f"ws_{uuid.uuid4().hex[:12]}"
    with connect_library_db() as conn:
        conn.execute(
            "INSERT INTO workspaces (id, name, description) VALUES (?, ?, ?)",
            (workspace_id, name.strip() or "未命名工作区", description.strip()),
        )
        conn.commit()
        return get_workspace(workspace_id)


def get_workspace(workspace_id: str) -> dict:
    with connect_library_db() as conn:
        row = conn.execute(
            """
            SELECT w.id, w.name, w.description, w.created_at, w.updated_at,
                   COUNT(DISTINCT l.id) AS library_count,
                   COUNT(DISTINCT p.id) AS paper_count
            FROM workspaces w
            LEFT JOIN libraries l ON l.workspace_id = w.id
            LEFT JOIN papers p ON p.workspace_id = w.id
            WHERE w.id = ?
            GROUP BY w.id
            """,
            (_workspace_id(workspace_id),),
        ).fetchone()
        if row:
            return _workspace_from_row(row)
        raise ValueError("workspace not found")


def ensure_workspace(workspace_id: str | None = None) -> str:
    workspace_id = _workspace_id(workspace_id)
    with connect_library_db() as conn:
        conn.execute(
            """
            INSERT OR IGNORE INTO workspaces (id, name, description)
            VALUES (?, ?, ?)
            """,
            (
                workspace_id,
                "默认工作区" if workspace_id == "default" else f"工作区 {workspace_id[-6:]}",
                "自动创建的浏览器工作区",
            ),
        )
        conn.commit()
    return workspace_id


def list_workspaces() -> list[dict]:
    with connect_library_db() as conn:
        rows = conn.execute(
            """
            SELECT w.id, w.name, w.description, w.created_at, w.updated_at,
                   COUNT(DISTINCT l.id) AS library_count,
                   COUNT(DISTINCT p.id) AS paper_count
            FROM workspaces w
            LEFT JOIN libraries l ON l.workspace_id = w.id
            LEFT JOIN papers p ON p.workspace_id = w.id
            GROUP BY w.id
            ORDER BY w.created_at DESC, w.id DESC
            """
        ).fetchall()
        return [_workspace_from_row(row) for row in rows]


def delete_workspace(workspace_id: str) -> None:
    workspace_id = _workspace_id(workspace_id)
    with connect_library_db() as conn:
        remaining = conn.execute("SELECT COUNT(*) AS count FROM workspaces WHERE id != ?", (workspace_id,)).fetchone()["count"]
        if remaining == 0:
            raise ValueError("cannot delete the last workspace")
        conn.execute("DELETE FROM workspaces WHERE id = ?", (workspace_id,))
        conn.commit()


def export_workspace(workspace_id: str) -> dict:
    workspace_id = ensure_workspace(workspace_id)
    from services.manuscript_service import list_manuscripts, list_workspace_versions

    return {
        "workspace": get_workspace(workspace_id),
        "libraries": list_libraries(workspace_id),
        "papers": get_all_papers(workspace_id),
        "manuscripts": list_manuscripts(workspace_id, include_archived=True),
        "manuscript_versions": list_workspace_versions(workspace_id),
    }


def build_workspace_backup(workspace_id: str) -> dict:
    """Build a portable backup manifest for Web/Windows migration."""
    exported = export_workspace(workspace_id)
    workspace = exported["workspace"]
    libraries = exported["libraries"]
    papers = exported["papers"]
    manuscripts = exported["manuscripts"]
    manuscript_versions = exported["manuscript_versions"]
    return {
        "format": "scholar-assist-workspace-backup",
        "version": 1,
        "workspace": workspace,
        "counts": {
            "libraries": len(libraries),
            "papers": len(papers),
            "manuscripts": len(manuscripts),
            "manuscript_versions": len(manuscript_versions),
        },
        "libraries": libraries,
        "papers": papers,
        "manuscripts": manuscripts,
        "manuscript_versions": manuscript_versions,
        "assets": {
            "database": str(get_library_db_path()),
            "pdf_uploads": "backend/uploads 或 SCHOLAR_ASSIST_UPLOAD_DIR",
            "figure_assets": "backend/uploads/charts 或图表导出目录",
        },
        "restore_notes": [
            "在目标机器启动 Scholar Assist Web 后，先备份原 scholar_assist_web.db。",
            "同版本迁移可直接复制 SQLite 数据库；跨版本迁移建议先导入 JSON manifest。",
            "PDF、图表和 source data 资产需要与数据库一起复制到相同相对路径。",
        ],
    }


def create_library(name: str, description: str = "", workspace_id: str | None = None) -> dict:
    workspace_id = ensure_workspace(workspace_id)
    with connect_library_db() as conn:
        cursor = conn.execute(
            "INSERT INTO libraries (workspace_id, name, description) VALUES (?, ?, ?)",
            (workspace_id, name.strip() or "未命名项目库", description.strip()),
        )
        library_id = cursor.lastrowid
        row = conn.execute(
            """
            SELECT l.id, l.name, l.description, l.created_at, COUNT(lp.paper_id) AS paper_count
            FROM libraries l
            LEFT JOIN library_papers lp ON lp.library_id = l.id
            WHERE l.id = ? AND l.workspace_id = ?
            GROUP BY l.id
            """,
            (library_id, workspace_id),
        ).fetchone()
        return _library_from_row(row)


def list_libraries(workspace_id: str | None = None) -> list[dict]:
    workspace_id = ensure_workspace(workspace_id)
    with connect_library_db() as conn:
        rows = conn.execute(
            """
            SELECT l.id, l.name, l.description, l.created_at, COUNT(lp.paper_id) AS paper_count
            FROM libraries l
            LEFT JOIN library_papers lp ON lp.library_id = l.id
            WHERE l.workspace_id = ?
            GROUP BY l.id
            ORDER BY l.created_at DESC, l.id DESC
            """,
            (workspace_id,),
        ).fetchall()
        return [_library_from_row(row) for row in rows]


def delete_library(library_id: int, workspace_id: str | None = None) -> None:
    workspace_id = ensure_workspace(workspace_id)
    with connect_library_db() as conn:
        conn.execute("DELETE FROM libraries WHERE id = ? AND workspace_id = ?", (library_id, workspace_id))
        conn.commit()


def save_paper(paper: dict, workspace_id: str | None = None) -> str:
    workspace_id = ensure_workspace(workspace_id)
    public_paper_id = str(paper.get("id") or paper.get("title") or "").strip()
    if not public_paper_id:
        seed = "|".join(
            [
                str(paper.get("title") or ""),
                str(paper.get("authors") or ""),
                str(paper.get("doi") or ""),
                str(paper.get("url") or ""),
            ]
        )
        public_paper_id = hashlib.sha1(seed.encode("utf-8")).hexdigest()
    storage_paper_id = _storage_paper_id(workspace_id, public_paper_id)
    with connect_library_db() as conn:
        conn.execute(
            """
            INSERT INTO papers (
                id, workspace_id, title, authors, year, source, abstract_text, url, doi,
                citations, keywords, source_engine, citation_key, notes, document_id,
                pdf_filename, full_text, total_pages, page_segments_json, page_layouts_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                title = excluded.title,
                authors = CASE WHEN excluded.authors != '' THEN excluded.authors ELSE papers.authors END,
                year = CASE WHEN excluded.year > 0 THEN excluded.year ELSE papers.year END,
                source = CASE WHEN excluded.source != '' THEN excluded.source ELSE papers.source END,
                abstract_text = CASE WHEN excluded.abstract_text != '' THEN excluded.abstract_text ELSE papers.abstract_text END,
                url = CASE WHEN excluded.url != '' THEN excluded.url ELSE papers.url END,
                doi = CASE WHEN excluded.doi != '' THEN excluded.doi ELSE papers.doi END,
                citations = CASE WHEN excluded.citations > 0 THEN excluded.citations ELSE papers.citations END,
                keywords = CASE WHEN excluded.keywords != '' THEN excluded.keywords ELSE papers.keywords END,
                source_engine = CASE WHEN excluded.source_engine != '' THEN excluded.source_engine ELSE papers.source_engine END,
                citation_key = CASE WHEN excluded.citation_key != '' THEN excluded.citation_key ELSE papers.citation_key END,
                notes = CASE WHEN excluded.notes != '' THEN excluded.notes ELSE papers.notes END,
                document_id = CASE WHEN excluded.document_id != '' THEN excluded.document_id ELSE papers.document_id END,
                pdf_filename = CASE WHEN excluded.pdf_filename != '' THEN excluded.pdf_filename ELSE papers.pdf_filename END,
                full_text = CASE WHEN excluded.full_text != '' THEN excluded.full_text ELSE papers.full_text END,
                total_pages = CASE WHEN excluded.total_pages > 0 THEN excluded.total_pages ELSE papers.total_pages END,
                page_segments_json = CASE WHEN excluded.page_segments_json != '[]' THEN excluded.page_segments_json ELSE papers.page_segments_json END,
                page_layouts_json = CASE WHEN excluded.page_layouts_json != '[]' THEN excluded.page_layouts_json ELSE papers.page_layouts_json END
            """,
            (
                storage_paper_id,
                workspace_id,
                paper.get("title") or "Untitled",
                paper.get("authors") or "",
                int(paper.get("year") or 0),
                paper.get("source") or "",
                paper.get("abstract_text") or paper.get("abstract") or "",
                paper.get("url") or "",
                paper.get("doi") or "",
                int(paper.get("citations") or 0),
                paper.get("keywords") or "",
                paper.get("source_engine") or "",
                paper.get("citation_key") or "",
                paper.get("notes") or "",
                paper.get("document_id") or "",
                paper.get("pdf_filename") or "",
                paper.get("full_text") or "",
                int(paper.get("total_pages") or 0),
                json.dumps(paper.get("page_segments") or [], ensure_ascii=False),
                json.dumps(paper.get("page_layouts") or [], ensure_ascii=False),
            ),
        )
        conn.commit()
    return public_paper_id


def save_papers_batch(papers: list[dict], workspace_id: str | None = None) -> int:
    for paper in papers:
        save_paper(paper, workspace_id)
    return len(papers)


def add_papers_to_library(library_id: int, paper_ids: list[str], workspace_id: str | None = None) -> int:
    workspace_id = ensure_workspace(workspace_id)
    with connect_library_db() as conn:
        library = conn.execute(
            "SELECT id FROM libraries WHERE id = ? AND workspace_id = ?",
            (library_id, workspace_id),
        ).fetchone()
        if not library:
            return 0
        count = 0
        for paper_id in paper_ids:
            storage_paper_id = _storage_paper_id(workspace_id, paper_id)
            paper = conn.execute(
                "SELECT id FROM papers WHERE id = ? AND workspace_id = ?",
                (storage_paper_id, workspace_id),
            ).fetchone()
            if not paper:
                continue
            cursor = conn.execute(
                "INSERT OR IGNORE INTO library_papers (library_id, paper_id) VALUES (?, ?)",
                (library_id, storage_paper_id),
            )
            count += cursor.rowcount
        conn.commit()
        return count


def get_papers_in_library(library_id: int, workspace_id: str | None = None) -> list[dict]:
    workspace_id = ensure_workspace(workspace_id)
    with connect_library_db() as conn:
        rows = conn.execute(
            """
            SELECT p.*
            FROM papers p
            INNER JOIN library_papers lp ON lp.paper_id = p.id
            INNER JOIN libraries l ON l.id = lp.library_id
            WHERE lp.library_id = ? AND l.workspace_id = ? AND p.workspace_id = ?
            ORDER BY p.year DESC, p.citations DESC, p.created_at DESC
            """,
            (library_id, workspace_id, workspace_id),
        ).fetchall()
        return [_paper_from_row(row) for row in rows]


def remove_paper_from_library(library_id: int, paper_id: str, workspace_id: str | None = None) -> None:
    workspace_id = ensure_workspace(workspace_id)
    storage_paper_id = _storage_paper_id(workspace_id, paper_id)
    with connect_library_db() as conn:
        conn.execute(
            """
            DELETE FROM library_papers
            WHERE library_id = ? AND paper_id = ?
              AND library_id IN (SELECT id FROM libraries WHERE workspace_id = ?)
            """,
            (library_id, storage_paper_id, workspace_id),
        )
        conn.commit()


def get_all_papers(workspace_id: str | None = None) -> list[dict]:
    workspace_id = ensure_workspace(workspace_id)
    with connect_library_db() as conn:
        rows = conn.execute("SELECT * FROM papers WHERE workspace_id = ? ORDER BY created_at DESC", (workspace_id,)).fetchall()
        return [_paper_from_row(row) for row in rows]


def document_belongs_to_workspace(document_id: str, workspace_id: str | None = None) -> bool:
    """Check document ownership before serving an original PDF asset."""
    workspace_id = _workspace_id(workspace_id)
    with connect_library_db() as conn:
        row = conn.execute(
            "SELECT 1 FROM papers WHERE document_id = ? AND workspace_id = ? LIMIT 1",
            (document_id, workspace_id),
        ).fetchone()
        return row is not None


def paper_belongs_to_workspace(paper_id: str, workspace_id: str | None = None) -> bool:
    """Check paper ownership before reading or mutating paper-scoped assets."""
    workspace_id = _workspace_id(workspace_id)
    storage_paper_id = _storage_paper_id(workspace_id, paper_id)
    with connect_library_db() as conn:
        row = conn.execute(
            "SELECT 1 FROM papers WHERE id = ? AND workspace_id = ? LIMIT 1",
            (storage_paper_id, workspace_id),
        ).fetchone()
        return row is not None


def search_papers_fulltext(query: str, workspace_id: str | None = None) -> list[dict]:
    workspace_id = ensure_workspace(workspace_id)
    terms = [term.strip().lower() for term in query.split() if term.strip()]
    if not terms:
        return get_all_papers(workspace_id)
    where = " OR ".join(
        ["lower(title || ' ' || authors || ' ' || abstract_text || ' ' || full_text || ' ' || keywords || ' ' || notes) LIKE ?"] * len(terms)
    )
    with connect_library_db() as conn:
        rows = conn.execute(
            f"""
            SELECT *
            FROM papers
            WHERE workspace_id = ? AND ({where})
            ORDER BY year DESC, citations DESC
            LIMIT 50
            """,
            (workspace_id, *tuple(f"%{term}%" for term in terms)),
        ).fetchall()
        return [_paper_from_row(row) for row in rows]


def _normalize_doi(value: str) -> str:
    doi = str(value or "").strip().lower()
    doi = re.sub(r"^https?://(dx\.)?doi\.org/", "", doi)
    doi = re.sub(r"^doi:\s*", "", doi)
    return doi.rstrip(".,; ")


def _normalize_title(value: str) -> str:
    title = str(value or "").lower()
    title = re.sub(r"[\W_]+", " ", title, flags=re.UNICODE)
    return re.sub(r"\s+", " ", title).strip()


def _best_keeper(papers: list[dict]) -> dict:
    return sorted(
        papers,
        key=lambda item: (
            int(item.get("citations") or 0),
            int(item.get("year") or 0),
            len(item.get("abstract_text") or item.get("abstract") or ""),
            bool(item.get("doi")),
        ),
        reverse=True,
    )[0]


def _paper_summary(paper: dict) -> dict:
    return {
        "paper_id": paper.get("id", ""),
        "title": paper.get("title") or "Untitled",
        "doi": paper.get("doi") or "",
        "citation_key": paper.get("citation_key") or "",
        "year": paper.get("year") or 0,
    }


def build_library_cleaning_report(workspace_id: str | None = None) -> dict:
    """Build a non-destructive deduplication and metadata cleanup report."""
    papers = get_all_papers(workspace_id)
    doi_groups: dict[str, list[dict]] = {}
    citekey_groups: dict[str, list[dict]] = {}
    title_items: list[tuple[str, dict]] = []
    metadata_gaps = []

    for paper in papers:
        doi = _normalize_doi(paper.get("doi", ""))
        if doi:
            doi_groups.setdefault(doi, []).append(paper)
        citekey = str(paper.get("citation_key") or "").strip()
        if citekey:
            citekey_groups.setdefault(citekey, []).append(paper)
        normalized_title = _normalize_title(paper.get("title", ""))
        if normalized_title:
            title_items.append((normalized_title, paper))

        missing = []
        if not str(paper.get("title") or "").strip():
            missing.append("title")
        if not str(paper.get("authors") or "").strip():
            missing.append("authors")
        if not int(paper.get("year") or 0):
            missing.append("year")
        if not str(paper.get("doi") or paper.get("url") or "").strip():
            missing.append("doi_or_url")
        if not str(paper.get("abstract_text") or paper.get("abstract") or "").strip():
            missing.append("abstract")
        if missing:
            metadata_gaps.append({
                "paper_id": paper.get("id", ""),
                "title": paper.get("title") or "Untitled",
                "missing": missing,
                "suggestion": "补齐缺失字段后再进入写作引用，避免导出参考文献不完整。",
            })

    duplicate_doi_groups = [
        {
            "doi": doi,
            "papers": [_paper_summary(item) for item in group],
            "paper_ids": [item.get("id", "") for item in group],
        }
        for doi, group in doi_groups.items()
        if len(group) > 1
    ]
    duplicate_citekey_groups = [
        {
            "citation_key": key,
            "papers": [_paper_summary(item) for item in group],
            "paper_ids": [item.get("id", "") for item in group],
        }
        for key, group in citekey_groups.items()
        if len(group) > 1
    ]

    similar_title_groups = []
    seen_pairs: set[tuple[str, str]] = set()
    for idx, (title_a, paper_a) in enumerate(title_items):
        for title_b, paper_b in title_items[idx + 1:]:
            if paper_a.get("id") == paper_b.get("id"):
                continue
            pair_key = tuple(sorted([paper_a.get("id", ""), paper_b.get("id", "")]))
            if pair_key in seen_pairs:
                continue
            score = SequenceMatcher(None, title_a, title_b).ratio()
            if score >= 0.88:
                seen_pairs.add(pair_key)
                similar_title_groups.append({
                    "score": round(score, 3),
                    "paper_ids": list(pair_key),
                    "papers": [_paper_summary(paper_a), _paper_summary(paper_b)],
                    "reason": "标题高度相似，建议人工确认是否为同一论文或预印本/正式版。",
                })

    merge_suggestions = []
    for group in duplicate_doi_groups:
        group_papers = [paper for paper in papers if paper.get("id") in set(group["paper_ids"])]
        keeper = _best_keeper(group_papers)
        merge_suggestions.append({
            "kind": "duplicate_doi",
            "keep_paper_id": keeper.get("id", ""),
            "merge_paper_ids": [paper.get("id", "") for paper in group_papers if paper.get("id") != keeper.get("id")],
            "reason": f"DOI {group['doi']} 完全相同，优先保留引用量/年份/摘要更完整的一条。",
            "fields_to_preserve": ["notes", "keywords", "pdf_attachment", "citation_key"],
        })
    for group in duplicate_citekey_groups:
        merge_suggestions.append({
            "kind": "duplicate_citekey",
            "keep_paper_id": group["paper_ids"][0],
            "merge_paper_ids": group["paper_ids"][1:],
            "reason": f"citation key {group['citation_key']} 重复，导出 BibTeX/CSL 前需要改名或合并。",
            "fields_to_preserve": ["notes", "doi", "zotero_key"],
        })

    issue_count = len(duplicate_doi_groups) + len(duplicate_citekey_groups) + len(similar_title_groups) + len(metadata_gaps)
    return {
        "paper_count": len(papers),
        "duplicate_doi_groups": duplicate_doi_groups,
        "duplicate_citekey_groups": duplicate_citekey_groups,
        "similar_title_groups": similar_title_groups,
        "metadata_gaps": metadata_gaps,
        "merge_suggestions": merge_suggestions,
        "summary": (
            "项目库清洗通过；未发现明显重复或关键字段缺失。"
            if issue_count == 0
            else f"发现 {issue_count} 类清洗问题；为避免误删，系统不自动删除，只提供合并和补全建议。"
        ),
    }


def export_workspace_json(workspace_id: str) -> str:
    return json.dumps(export_workspace(workspace_id), ensure_ascii=False, indent=2)
