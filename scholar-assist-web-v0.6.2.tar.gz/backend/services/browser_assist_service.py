"""Browser-assisted scholarly search.

This module opens a visible browser and lets the user solve any CAPTCHA manually.
It never attempts to bypass or automate verification challenges.
"""
from __future__ import annotations

import asyncio
import os
import re
import shutil
import sys
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, quote_plus, urlencode, urljoin, urlparse, urlunparse

from services.search_service import (
    PaperResult,
    _engine_id,
    _safe_int,
    _parse_cnki_html,
    build_categorized_query,
    build_dual_query,
)


BrowserEngine = str


@dataclass
class AssistedBrowserSession:
    id: str
    engine: BrowserEngine
    query: str
    queries: list[tuple[str, str]]
    query_index: int
    url: str
    status: str
    message: str
    created_at: float
    user_data_dir: Path | None = None
    playwright: Any = None
    context: Any = None
    page: Any = None
    seen_keys: set[str] = field(default_factory=set)
    seen_rank_count: int = 0
    pages_read: int = 0
    imported_count: int = 0
    target_limit: int = 0
    max_pages: int = 0
    min_relevance: int = 70
    logs: list[str] = field(default_factory=list)


BROWSER_SESSIONS: dict[str, AssistedBrowserSession] = {}
MAX_BROWSER_ASSIST_RESULTS = 500
DEFAULT_BROWSER_ASSIST_RESULTS = 120
DEFAULT_BROWSER_ASSIST_PAGES = 30
MAX_BROWSER_ASSIST_PAGES = 80

COMMON_ACADEMIC_TRANSLATIONS = {
    "细胞计数": "cell counting",
    "细胞检测": "cell detection",
    "细胞分割": "cell segmentation",
    "图像分割": "image segmentation",
    "目标检测": "object detection",
    "深度学习": "deep learning",
    "机器学习": "machine learning",
    "文献综述": "literature review",
    "神经网络": "neural network",
}


def default_browser_profile_root(
    platform_name: str | None = None,
    home: Path | None = None,
    env: dict[str, str] | None = None,
) -> Path:
    """Return a browser profile root that follows each OS convention."""
    environment = env if env is not None else os.environ
    current_platform = platform_name or sys.platform
    home_dir = home or Path.home()
    if current_platform.startswith("win"):
        local_app_data = environment.get("LOCALAPPDATA")
        base = Path(local_app_data) if local_app_data else home_dir / "AppData" / "Local"
        return base / "Scholar Assist" / "browser-profile"
    if current_platform == "darwin":
        return home_dir / "Library" / "Application Support" / "Scholar Assist" / "browser-profile"
    data_home = environment.get("XDG_DATA_HOME")
    base = Path(data_home) if data_home else home_dir / ".local" / "share"
    return base / "scholar-assist" / "browser-profile"


def browser_platform_label(platform_name: str | None = None) -> str:
    current_platform = platform_name or sys.platform
    if current_platform.startswith("win"):
        return "Windows"
    if current_platform == "darwin":
        return "macOS"
    if current_platform.startswith("linux"):
        return "Linux"
    return current_platform


def build_assisted_search_url(engine: BrowserEngine, query: str) -> str:
    encoded = quote_plus(query.strip())
    if engine == "google_scholar":
        return f"https://scholar.google.com/scholar?hl=zh-CN&as_sdt=0,5&q={encoded}"
    if engine == "gufen":
        return f"https://soso.soxm.top/so.php?q={encoded}"
    if engine == "cnki":
        return f"https://kns.cnki.net/kns8s/defaultresult/index?kw={encoded}"
    raise ValueError(f"Unsupported browser-assisted engine: {engine}")


def build_assisted_query_variants(
    query: str,
    category: str = "all",
    auto_translate: bool = True,
) -> list[tuple[str, str]]:
    raw_variants = build_dual_query(query) if auto_translate else [(query, "zh" if _contains_chinese(query) else "en")]
    variants: list[tuple[str, str]] = []
    seen: set[str] = set()

    for raw_query, lang in raw_variants:
        categorized = build_categorized_query(raw_query, category)
        key = categorized.strip().lower()
        if key and key not in seen:
            seen.add(key)
            variants.append((categorized, lang))

    if auto_translate and _contains_chinese(query):
        translated = _translate_common_academic_terms(query)
        if translated:
            categorized = build_categorized_query(translated, category)
            key = categorized.strip().lower()
            if key not in seen:
                variants.append((categorized, "en"))

    return variants or [(query, "zh" if _contains_chinese(query) else "en")]


def detect_assisted_page_state(html: str, url: str = "") -> str:
    lowered = f"{html}\n{url}".lower()
    if any(marker in lowered for marker in [
        "captcha",
        "recaptcha",
        "g-recaptcha",
        "请验证",
        "验证码",
        "安全验证",
        "blockpuzzle",
        "/verify/",
    ]):
        return "awaiting_verification"
    if "gs_ri" in html or "gs_rt" in html or "result-table-list" in html:
        return "ready"
    return "opened"


def append_session_log(session: AssistedBrowserSession, message: str) -> None:
    timestamp = time.strftime("%H:%M:%S")
    session.logs.append(f"{timestamp} {message}")
    if len(session.logs) > 120:
        session.logs = session.logs[-120:]


def browser_assist_progress(session: AssistedBrowserSession) -> dict[str, Any]:
    return {
        "pages_read": session.pages_read,
        "imported_count": session.imported_count,
        "query_index": session.query_index + 1 if session.queries else 1,
        "total_queries": len(session.queries) if session.queries else 1,
        "target_limit": session.target_limit,
        "max_pages": session.max_pages,
        "min_relevance": session.min_relevance,
        "logs": session.logs[-30:],
    }


def export_browser_assist_logs(session_id: str) -> dict[str, Any]:
    session = BROWSER_SESSIONS.get(session_id)
    if not session:
        raise KeyError("浏览器辅助搜索会话不存在或已关闭")
    markdown = "\n".join([
        "# Browser Assist Incident Log",
        "",
        f"- session_id: {session.id}",
        f"- engine: {session.engine}",
        f"- query: {session.query}",
        f"- status: {session.status}",
        f"- url: {session.url}",
        f"- imported: {session.imported_count}/{session.target_limit}",
        f"- pages: {session.pages_read}/{session.max_pages}",
        f"- min_relevance: {session.min_relevance}",
        "",
        "## Logs",
        *[f"- {line}" for line in session.logs],
    ])
    return {
        "session_id": session.id,
        "status": session.status,
        "profile": str(session.user_data_dir) if session.user_data_dir else "",
        "logs": list(session.logs),
        "markdown": markdown,
    }


def browser_assist_diagnostics(session: AssistedBrowserSession | None = None, status: str = "", message: str = "") -> dict[str, Any]:
    """Return user-facing diagnostics for common browser-assist failures."""
    try:
        __import__("playwright.async_api")
        playwright_available = True
    except ImportError:
        playwright_available = False

    profile_root = Path(os.getenv("SCHOLAR_ASSIST_BROWSER_PROFILE_ROOT", str(default_browser_profile_root())))
    effective_status = status or (session.status if session else "")
    effective_message = message or (session.message if session else "")
    advice: list[str] = []
    lowered = effective_message.lower()

    if not playwright_available:
        advice.append("安装 Playwright 后再试：python3 -m pip install playwright && python3 -m playwright install chromium")
    if effective_status == "load_failed" or "load failed" in lowered:
        advice.append("关闭当前辅助浏览器窗口，回到 App 点击“关闭会话”，再重新打开浏览器辅助。")
        advice.append("如果一直空白页，检查代理/VPN 是否允许访问目标学术站点。")
    if "target page" in lowered or "context or browser has been closed" in lowered:
        advice.append("浏览器窗口或上下文已被关闭，请重新开始一次浏览器辅助搜索。")
    if "profile" in lowered or "user data" in lowered:
        advice.append(f"如疑似浏览器 profile 卡住，可退出 App 后删除目录：{profile_root}")
    if effective_status == "awaiting_verification":
        advice.append("请在弹出的浏览器里手动完成验证码；完成后回到 App 点“继续采集”。")
    if not advice:
        advice.append("如果浏览器没有弹出，请确认后端 8765 端口正在运行，并重启 App 再试。")

    return {
        "playwright_available": playwright_available,
        "platform": browser_platform_label(),
        "browser_hint": "Windows 可安装 Chrome 或运行 python -m playwright install chromium；macOS 可用 Chrome/Chromium；Linux 建议用 Playwright Chromium。",
        "profile_root": str(profile_root),
        "session_profile": str(session.user_data_dir) if session and session.user_data_dir else "",
        "active_sessions": len(BROWSER_SESSIONS),
        "status": effective_status,
        "advice": advice,
    }


def parse_google_scholar_browser_html(
    html: str,
    limit: int = 10,
    start_index: int = 0,
    min_relevance: int = 0,
) -> list[PaperResult]:
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        return []

    soup = BeautifulSoup(html, "html.parser")
    results: list[PaperResult] = []
    items = soup.select(".gs_r.gs_or, .gs_r")
    for index, item in enumerate(items):
        if len(results) >= limit:
            break
        title_el = item.select_one(".gs_rt a") or item.select_one("h3 a")
        if not title_el:
            continue
        title = title_el.get_text(" ", strip=True)
        if not title:
            continue
        url = title_el.get("href", "") or ""
        meta = item.select_one(".gs_a")
        meta_text = meta.get_text(" ", strip=True) if meta else ""
        authors = meta_text.split(" - ", 1)[0] if meta_text else ""
        year_match = re.search(r"\b(19|20)\d{2}\b", meta_text)
        year = int(year_match.group(0)) if year_match else 0
        snippet = item.select_one(".gs_rs")
        abstract = snippet.get_text(" ", strip=True) if snippet else ""
        citations = 0
        link_text = " ".join([a.get_text(" ", strip=True) for a in item.select(".gs_fl a")])
        citation_match = re.search(r"(\d+)", link_text)
        if citation_match and ("引用" in link_text or "cited" in link_text.lower()):
            citations = _safe_int(citation_match.group(1), 0)

        relevance = estimate_browser_relevance(start_index + index)
        if relevance < min_relevance:
            continue

        results.append(PaperResult(
            id=_engine_id("gs_browser", url or title or index),
            title=title,
            authors=authors,
            year=year,
            source="Google Scholar",
            abstract=abstract[:1000],
            url=url,
            citations=citations,
            relevance=relevance,
            keywords=["浏览器导入"],
            source_engine="Google Scholar 浏览器导入",
            search_language="en",
        ))
    return results


def parse_assisted_browser_html(
    engine: BrowserEngine,
    html: str,
    limit: int = 10,
    start_index: int = 0,
    min_relevance: int = 0,
) -> list[PaperResult]:
    if engine in {"google_scholar", "gufen"}:
        return parse_google_scholar_browser_html(html, limit, start_index, min_relevance)
    if engine == "cnki":
        return [paper for paper in _parse_cnki_html(html, "zh", limit) if paper.relevance >= min_relevance]
    return []


def result_budget_for_relevance(min_relevance: int, query_count: int = 1) -> int:
    min_relevance = max(0, min(min_relevance, 100))
    query_count = max(1, query_count)
    per_query = sum(
        1
        for index in range(MAX_BROWSER_ASSIST_RESULTS)
        if estimate_browser_relevance(index) >= min_relevance
    )
    return min(MAX_BROWSER_ASSIST_RESULTS, per_query * query_count)


def estimate_browser_relevance(global_index: int) -> int:
    global_index = max(0, global_index)
    page_index = global_index // 10
    index_in_page = global_index % 10
    return max(0, 94 - page_index * 4 - index_in_page // 3)


def max_pages_for_relevance(min_relevance: int, query_count: int = 1, results_per_page: int = 10) -> int:
    budget = result_budget_for_relevance(min_relevance, query_count)
    return max(1, (budget + results_per_page - 1) // results_per_page + query_count)


def normalize_browser_assist_limits(
    requested_limit: int = 0,
    min_relevance: int = 70,
    requested_max_pages: int = 0,
    query_count: int = 1,
) -> dict[str, int]:
    """Convert user settings into a relevance-driven crawl plan.

    The browser assistant should not stop at the first result page when the
    relevance threshold still admits more papers.
    """
    min_relevance = max(0, min(min_relevance, 100))
    query_count = max(1, query_count)
    threshold_budget = result_budget_for_relevance(min_relevance, query_count)
    threshold_pages = max_pages_for_relevance(min_relevance, query_count)
    baseline_limit = DEFAULT_BROWSER_ASSIST_RESULTS if requested_limit <= 0 else requested_limit
    limit = min(max(baseline_limit, threshold_budget), MAX_BROWSER_ASSIST_RESULTS)
    max_pages = DEFAULT_BROWSER_ASSIST_PAGES if requested_max_pages <= 0 else requested_max_pages
    max_pages = max(1, min(max(max_pages, min(threshold_pages, DEFAULT_BROWSER_ASSIST_PAGES)), MAX_BROWSER_ASSIST_PAGES))
    return {
        "limit": limit,
        "max_pages": max_pages,
        "min_relevance": min_relevance,
        "threshold_budget": threshold_budget,
        "threshold_pages": threshold_pages,
    }


def extract_google_scholar_next_url(html: str, current_url: str = "") -> str:
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        return ""

    soup = BeautifulSoup(html, "html.parser")
    anchors = soup.select("#gs_n a[href], a[aria-label][href], a[href*='start=']")
    for anchor in anchors:
        text = anchor.get_text(" ", strip=True).lower()
        aria = (anchor.get("aria-label", "") or "").strip().lower()
        href = anchor.get("href", "") or ""
        if (
            "next" in aria
            or "下一页" in aria
            or "next" in text
            or "下一页" in text
            or text in {"›", ">"}
        ):
            return urljoin(current_url or "https://scholar.google.com", href)

    for anchor in soup.select("#gs_n a[href*='start=']"):
        href = anchor.get("href", "") or ""
        if href:
            return urljoin(current_url or "https://scholar.google.com", href)
    return _build_google_scholar_next_start_url(current_url, html)


def _build_google_scholar_next_start_url(current_url: str, html: str = "") -> str:
    if not current_url:
        return ""
    parsed = urlparse(current_url)
    if "scholar.google." not in parsed.netloc or not parsed.path.startswith("/scholar"):
        return ""
    if html and _count_google_scholar_items(html) == 0:
        return ""

    params = dict(parse_qsl(parsed.query, keep_blank_values=True))
    try:
        current_start = int(params.get("start", "0") or 0)
    except ValueError:
        current_start = 0
    params["start"] = str(current_start + 10)
    next_query = urlencode(params)
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, next_query, parsed.fragment))


async def start_assisted_browser_search(
    engine: BrowserEngine,
    query: str,
    category: str = "all",
    auto_translate: bool = True,
) -> AssistedBrowserSession:
    try:
        from playwright.async_api import async_playwright
    except ImportError as exc:
        raise RuntimeError(
            "浏览器辅助搜索需要安装 Playwright：pip install playwright && python -m playwright install chromium"
        ) from exc

    queries = build_assisted_query_variants(query, category, auto_translate)
    url = build_assisted_search_url(engine, queries[0][0])
    session_id = uuid.uuid4().hex
    profile_root = Path(os.getenv("SCHOLAR_ASSIST_BROWSER_PROFILE_ROOT", str(default_browser_profile_root())))
    user_data_dir = profile_root / session_id
    user_data_dir.mkdir(parents=True, exist_ok=True)

    playwright = await async_playwright().start()
    launch_options = {
        "headless": False,
        "viewport": {"width": 1280, "height": 860},
    }
    context = None
    try:
        try:
            context = await playwright.chromium.launch_persistent_context(
                str(user_data_dir),
                channel="chrome",
                **launch_options,
            )
        except Exception:
            context = await playwright.chromium.launch_persistent_context(
                str(user_data_dir),
                **launch_options,
            )
    except Exception:
        await playwright.stop()
        _cleanup_profile_dir(user_data_dir)
        raise
    page = context.pages[0] if context.pages else await context.new_page()
    try:
        await _navigate_assisted_page(page, url)
        html = await page.content()
        state = detect_assisted_page_state(html, page.url)
        message = _state_message(state)
    except Exception as exc:
        state = "load_failed"
        message = f"浏览器已打开，但页面加载失败：{exc}"
    session = AssistedBrowserSession(
        id=session_id,
        engine=engine,
        query=query,
        queries=queries,
        query_index=0,
        url=page.url,
        status=state,
        message=message,
        created_at=time.time(),
        user_data_dir=user_data_dir,
        playwright=playwright,
        context=context,
        page=page,
    )
    append_session_log(session, f"打开 {engine}：{queries[0][0]}")
    append_session_log(session, message)
    BROWSER_SESSIONS[session_id] = session
    return session


async def get_assisted_browser_status(session_id: str) -> AssistedBrowserSession:
    session = BROWSER_SESSIONS.get(session_id)
    if not session:
        raise KeyError("浏览器辅助搜索会话不存在或已关闭")
    try:
        html = await _get_stable_page_content(session.page, attempts=2)
        session.url = session.page.url
        state = detect_assisted_page_state(html, session.url)
        if state != session.status:
            append_session_log(session, _state_message(state))
        session.status = state
        session.message = _state_message(state)
    except Exception as exc:
        session.status = "load_failed"
        session.message = f"浏览器状态检查失败：{exc}"
        append_session_log(session, session.message)
    return session


async def read_assisted_browser_results(
    session_id: str,
    limit: int = 0,
    min_relevance: int = 70,
    max_pages: int = 0,
) -> tuple[AssistedBrowserSession, list[PaperResult]]:
    session = BROWSER_SESSIONS.get(session_id)
    if not session:
        raise KeyError("浏览器辅助搜索会话不存在或已关闭")

    query_count = len(session.queries) if session.queries else 1
    crawl_plan = normalize_browser_assist_limits(limit, min_relevance, max_pages, query_count)
    limit = crawl_plan["limit"]
    max_pages = crawl_plan["max_pages"]
    min_relevance = crawl_plan["min_relevance"]
    session.target_limit = limit
    session.max_pages = max_pages
    session.min_relevance = min_relevance

    if limit <= 0:
        session.status = "opened"
        session.message = f"相关度阈值 {min_relevance} 高于浏览器导入最高估算相关度 94，请降低相关性设置后再读取"
        append_session_log(session, session.message)
        return session, []

    papers: list[PaperResult] = []
    stopped_by_verification = False
    append_session_log(session, f"开始读取：最低相关度 {min_relevance}，目标 {limit} 条，最多 {max_pages} 页")

    while session.imported_count < limit and session.pages_read < max_pages:
        html = await _get_stable_page_content(session.page)
        session.url = session.page.url
        state = detect_assisted_page_state(html, session.url)
        session.status = state
        session.message = _state_message(state)
        if state == "awaiting_verification":
            stopped_by_verification = True
            append_session_log(session, "检测到验证页，暂停采集，等待人工验证")
            break

        if session.engine in {"google_scholar", "gufen"}:
            page_rank_count = _count_google_scholar_items(html)
            if page_rank_count == 0:
                append_session_log(session, "当前页没有可解析的结果，停止读取")
                break
            page_papers = parse_assisted_browser_html(
                session.engine,
                html,
                limit - session.imported_count,
                start_index=session.seen_rank_count,
                min_relevance=min_relevance,
            )
            current_lang = session.queries[session.query_index][1] if session.queries else "en"
            for paper in page_papers:
                paper.search_language = current_lang
                if current_lang == "zh":
                    paper.keywords = list(dict.fromkeys([*paper.keywords, "中文检索"]))
                else:
                    paper.keywords = list(dict.fromkeys([*paper.keywords, "英文检索"]))
            session.seen_rank_count += page_rank_count
        else:
            page_papers = parse_assisted_browser_html(
                session.engine,
                html,
                limit - session.imported_count,
                start_index=session.seen_rank_count,
                min_relevance=min_relevance,
            )

        before_count = len(papers)
        _append_unique_papers(papers, page_papers, session.seen_keys, limit - session.imported_count)
        imported_this_page = len(papers) - before_count
        session.imported_count += imported_this_page
        session.pages_read += 1
        append_session_log(
            session,
            f"第 {session.pages_read} 页读取 {page_rank_count if session.engine in {'google_scholar', 'gufen'} else len(page_papers)} 条，新增 {imported_this_page} 条，累计 {session.imported_count} 条",
        )

        if session.imported_count >= limit or session.engine not in {"google_scholar", "gufen"}:
            break
        if estimate_browser_relevance(session.seen_rank_count) < min_relevance:
            append_session_log(session, "当前查询后续页估算相关度低于阈值，切换下一个中英文查询")
            moved_to_next_query = await _go_to_next_query(session)
            if not moved_to_next_query:
                append_session_log(session, "没有更多中英文查询，停止读取")
                break
            session.seen_rank_count = 0
            continue
        clicked_next = await _go_to_next_assisted_page(session.page)
        if not clicked_next:
            append_session_log(session, "没有找到下一页，尝试切换下一个中英文查询")
            moved_to_next_query = await _go_to_next_query(session)
            if not moved_to_next_query:
                append_session_log(session, "没有更多中英文查询，停止读取")
                break
            session.seen_rank_count = 0
            continue
        await _polite_browser_delay()

    if papers:
        session.status = "imported"
        suffix = "；后续页面又出现验证，请验证后可再次继续读取" if stopped_by_verification else ""
        total_queries = len(session.queries) if session.queries else 1
        session.message = f"本次新增 {len(papers)} 条，累计 {session.imported_count}/{limit} 条，读取 {session.pages_read}/{max_pages} 页，已处理 {session.query_index + 1}/{total_queries} 个中英文查询{suffix}"
        append_session_log(session, session.message)
    elif stopped_by_verification:
        session.status = "awaiting_verification"
        session.message = _state_message("awaiting_verification")
        append_session_log(session, session.message)
    else:
        session.status = "opened"
        session.message = f"当前没有新增结果；累计 {session.imported_count}/{limit} 条，读取 {session.pages_read}/{max_pages} 页"
        append_session_log(session, session.message)
    return session, papers


def _count_google_scholar_items(html: str) -> int:
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        return 0
    soup = BeautifulSoup(html, "html.parser")
    return len(soup.select(".gs_r.gs_or, .gs_r"))


def _append_unique_papers(
    target: list[PaperResult],
    incoming: list[PaperResult],
    seen_keys: set[str],
    limit: int,
) -> None:
    for paper in incoming:
        key = paper.url or paper.id or paper.title
        if key in seen_keys:
            continue
        seen_keys.add(key)
        target.append(paper)
        if len(target) >= limit:
            break


async def _go_to_next_assisted_page(page: Any) -> bool:
    html = await _get_stable_page_content(page)
    clicked = await _click_google_scholar_next_link(page)
    if clicked:
        return True

    next_url = extract_google_scholar_next_url(html, page.url)
    if not next_url:
        next_url = await page.evaluate(
        """
        () => {
          const anchors = Array.from(document.querySelectorAll('a'));
          const next = anchors.find((anchor) => {
            const text = (anchor.textContent || '').trim().toLowerCase();
            const aria = (anchor.getAttribute('aria-label') || '').trim().toLowerCase();
            const href = anchor.href || '';
            const inPagination = Boolean(anchor.closest('#gs_n'));
            return aria.includes('next') ||
              aria.includes('下一页') ||
              text.includes('next') ||
              text.includes('下一页') ||
              text === '›' ||
              (inPagination && href.includes('start='));
          });
          return next ? next.href : '';
        }
        """
        )
    if not next_url:
        return False
    try:
        await _navigate_assisted_page(page, next_url)
        return True
    except Exception:
        return False


async def _click_google_scholar_next_link(page: Any) -> bool:
    try:
        clicked = await page.evaluate(
            """
            () => {
              const anchors = Array.from(document.querySelectorAll('#gs_n a[href], a[aria-label][href]'));
              const next = anchors.find((anchor) => {
                const text = (anchor.textContent || '').trim().toLowerCase();
                const aria = (anchor.getAttribute('aria-label') || '').trim().toLowerCase();
                const href = anchor.href || '';
                const inPagination = Boolean(anchor.closest('#gs_n'));
                return aria.includes('next') ||
                  aria.includes('下一页') ||
                  text.includes('next') ||
                  text.includes('下一页') ||
                  text === '›' ||
                  (inPagination && href.includes('start='));
              });
              if (!next) return false;
              next.click();
              return true;
            }
            """
        )
        if not clicked:
            return False
        try:
            await page.wait_for_load_state("domcontentloaded", timeout=30000)
        except Exception:
            pass
        try:
            await page.wait_for_load_state("networkidle", timeout=5000)
        except Exception:
            pass
        return True
    except Exception:
        return False


async def _get_stable_page_content(page: Any, attempts: int = 5) -> str:
    last_error: Exception | None = None
    for attempt in range(max(1, attempts)):
        try:
            return await page.content()
        except Exception as exc:
            last_error = exc
            try:
                await page.wait_for_load_state("domcontentloaded", timeout=3000)
            except Exception:
                pass
            await asyncio.sleep(0.25 * (attempt + 1))
    if last_error:
        raise last_error
    return await page.content()


async def _polite_browser_delay() -> None:
    await asyncio.sleep(1.5)


async def _go_to_next_query(session: AssistedBrowserSession) -> bool:
    if session.query_index + 1 >= len(session.queries):
        return False
    session.query_index += 1
    next_query = session.queries[session.query_index][0]
    try:
        await _navigate_assisted_page(session.page, build_assisted_search_url(session.engine, next_query))
        append_session_log(session, f"切换查询：{next_query}")
        return True
    except Exception as exc:
        session.status = "load_failed"
        session.message = f"切换到下一个中英文查询时加载失败：{exc}"
        return False


async def _navigate_assisted_page(page: Any, url: str) -> None:
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
    except Exception:
        await page.goto(url, wait_until="commit", timeout=30000)
    try:
        await page.wait_for_load_state("networkidle", timeout=5000)
    except Exception:
        pass


def _contains_chinese(text: str) -> bool:
    return bool(re.search(r"[一-鿿]", text))


def _translate_common_academic_terms(query: str) -> str:
    translated = query
    changed = False
    for zh, en in COMMON_ACADEMIC_TRANSLATIONS.items():
        if zh in translated:
            translated = translated.replace(zh, en)
            changed = True
    return translated if changed and not _contains_chinese(translated) else ""


async def close_assisted_browser_session(session_id: str) -> None:
    session = BROWSER_SESSIONS.pop(session_id, None)
    if not session:
        return
    try:
        if session.context:
            await session.context.close()
    finally:
        if session.playwright:
            await session.playwright.stop()
        if session.user_data_dir:
            _cleanup_profile_dir(session.user_data_dir)


async def reset_assisted_browser_profile(session_id: str = "") -> dict[str, Any]:
    profile_root = Path(os.getenv("SCHOLAR_ASSIST_BROWSER_PROFILE_ROOT", str(default_browser_profile_root())))
    removed: list[str] = []
    if session_id:
        session = BROWSER_SESSIONS.get(session_id)
        if session and session.user_data_dir:
            removed.append(str(session.user_data_dir))
        await close_assisted_browser_session(session_id)
    else:
        for active_session_id in list(BROWSER_SESSIONS.keys()):
            session = BROWSER_SESSIONS.get(active_session_id)
            if session and session.user_data_dir:
                removed.append(str(session.user_data_dir))
            await close_assisted_browser_session(active_session_id)
        if profile_root.exists():
            for child in profile_root.iterdir():
                if child.is_dir():
                    removed.append(str(child))
                    shutil.rmtree(child, ignore_errors=True)
    profile_root.mkdir(parents=True, exist_ok=True)
    return {
        "status": "profile_reset",
        "profile_root": str(profile_root),
        "removed": removed,
        "active_sessions": len(BROWSER_SESSIONS),
    }


def _cleanup_profile_dir(path: Path) -> None:
    try:
        profile_root = Path(os.getenv("SCHOLAR_ASSIST_BROWSER_PROFILE_ROOT", str(default_browser_profile_root())))
        if path.exists() and profile_root in path.parents:
            shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass


def _state_message(state: str) -> str:
    if state == "awaiting_verification":
        return "检测到验证码或安全验证，请在打开的浏览器窗口中手动完成，然后回到应用点击继续读取"
    if state == "ready":
        return "页面已有可读取结果，可以点击继续读取"
    if state == "load_failed":
        return "浏览器页面加载失败，请检查网络或代理后重新打开浏览器辅助"
    return "浏览器已打开；如页面仍在加载或要求验证，请处理后点击继续读取"
