"""Manuscript export helpers for Markdown, HTML, DOCX and PDF."""
from __future__ import annotations

import html
import io
import json
import os
import base64
import re
import subprocess
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote
import requests

from services.publication_service import resolve_tool_path

CSL_STYLE_URLS = {
    "gbt7714": "https://raw.githubusercontent.com/citation-style-language/styles/master/china-national-standard-gb-t-7714-2015-numeric.csl",
    "apa": "https://raw.githubusercontent.com/citation-style-language/styles/master/apa.csl",
    "ieee": "https://raw.githubusercontent.com/citation-style-language/styles/master/ieee.csl",
}

TEMPLATE_ASSET_ROOT = Path(__file__).resolve().parents[2] / "templates"


def custom_template_asset_root() -> Path:
    root = Path(os.getenv("SCHOLAR_ASSIST_TEMPLATE_PACK_DIR", Path.home() / ".scholar-assist" / "template-packages")).expanduser()
    root.mkdir(parents=True, exist_ok=True)
    return root

TEMPLATE_REFERENCE_PROFILES = {
    "undergraduate": {
        "id": "undergraduate",
        "label": "本科毕业论文",
        "citation_style": "gbt7714",
        "reference_docx": "undergraduate-reference.docx",
        "delivery": ["封面", "中文摘要", "英文摘要", "目录", "页眉页脚", "页码", "参考文献"],
        "required_sections": ["封面", "中文摘要", "英文摘要", "第一章 绪论", "参考文献"],
        "style_notes": ["宋体小四正文", "黑体章节标题", "1.5 倍行距", "A4 常规页边距"],
    },
    "master": {
        "id": "master",
        "label": "硕士论文",
        "citation_style": "gbt7714",
        "reference_docx": "master-reference.docx",
        "delivery": ["封面", "原创性声明", "中文摘要", "英文摘要", "目录", "页眉页脚", "页码", "参考文献"],
        "required_sections": ["封面", "中文摘要", "英文摘要", "目录", "第一章 绪论", "参考文献"],
        "style_notes": ["宋体小四正文", "黑体一级标题居中", "二级标题左对齐", "页眉页脚保留给 Word 定稿"],
    },
    "journal": {
        "id": "journal",
        "label": "期刊论文",
        "citation_style": "apa",
        "reference_docx": "journal-reference.docx",
        "delivery": ["题名", "作者信息", "摘要", "关键词", "正文", "图表", "参考文献"],
        "required_sections": ["摘要", "Introduction", "Methods", "Results", "Discussion", "References"],
        "style_notes": ["紧凑正文", "英文 Times New Roman", "图表标题保留交叉引用"],
    },
    "nature": {
        "id": "nature",
        "label": "Nature 风格短文",
        "citation_style": "nature",
        "reference_docx": "nature-reference.docx",
        "delivery": ["Title", "Abstract", "Main", "Methods", "Figure legends", "References"],
        "required_sections": ["Abstract", "Main", "Methods", "References"],
        "style_notes": ["短摘要", "结果围绕 Figure 组织", "图注独立成段", "表达克制、证据优先"],
    },
}


def get_template_reference_profile(template_id: str = "journal") -> dict:
    """Return a manuscript template package profile used by export manifests."""
    clean_id = re.sub(r"[^a-zA-Z0-9_-]+", "-", template_id or "journal")
    custom = get_template_asset_package(clean_id)
    if custom and custom.get("source") == "custom":
        return {
            "id": custom["id"],
            "label": custom.get("name") or custom["id"],
            "citation_style": custom.get("csl") or "",
            "reference_docx": custom.get("reference_docx") or "",
            "delivery": custom.get("delivery", ["用户自定义模板"]),
            "required_sections": custom.get("required_sections", []),
            "style_notes": custom.get("format_rules", []),
            "warnings": custom.get("warnings", []),
            "asset_root": custom.get("asset_root", ""),
            "source": "custom",
        }
    profile = dict(TEMPLATE_REFERENCE_PROFILES.get(clean_id, TEMPLATE_REFERENCE_PROFILES["journal"]))
    profile["reference_docx"] = ensure_reference_docx(profile["id"])
    profile["source"] = "built-in"
    return profile


def list_template_reference_profiles() -> list[dict]:
    """List built-in template packages with resolved reference.docx paths."""
    return [get_template_reference_profile(template_id) for template_id in TEMPLATE_REFERENCE_PROFILES]


def list_template_asset_packages() -> list[dict]:
    """List precision template asset packages committed with the app and user-created packages."""
    packages: list[dict] = []
    for source_root, source in [(TEMPLATE_ASSET_ROOT, "built-in"), (custom_template_asset_root(), "custom")]:
        if not source_root.exists():
            continue
        for manifest_path in sorted(source_root.glob("*/manifest.json")):
            package = _read_template_manifest(manifest_path, source)
            if package:
                packages.append(package)
    return packages


def _read_template_manifest(manifest_path: Path, source: str) -> dict | None:
    root = manifest_path.parent
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return None
    package = dict(manifest)
    for key in ["reference_docx", "csl", "cover", "statement", "sample_markdown", "visual_checklist"]:
        if package.get(key):
            package[key] = str((root / package[key]).resolve())
    package["asset_root"] = str(root.resolve())
    package["source"] = source
    package.setdefault("warnings", validate_template_asset_package(package))
    return package


def get_template_asset_package(package_id: str) -> dict | None:
    clean_id = re.sub(r"[^a-zA-Z0-9_-]+", "-", package_id or "").strip("-")
    if not clean_id:
        return None
    for root, source in [(custom_template_asset_root(), "custom"), (TEMPLATE_ASSET_ROOT, "built-in")]:
        manifest_path = root / clean_id / "manifest.json"
        if manifest_path.exists():
            return _read_template_manifest(manifest_path, source)
    return None


def validate_template_asset_package(package: dict) -> list[str]:
    warnings = []
    if not package.get("reference_docx") or not Path(str(package.get("reference_docx"))).exists():
        warnings.append("缺少 reference.docx，DOCX 导出会回退到通用模板。")
    if not package.get("csl") or not Path(str(package.get("csl"))).exists():
        warnings.append("缺少 CSL，参考文献会使用当前选择的默认样式。")
    if not package.get("visual_checklist"):
        warnings.append("缺少视觉检查清单，定稿前需要人工核对学校/期刊要求。")
    return warnings


def _safe_template_id(name: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9_\-\u4e00-\u9fff]+", "-", name or "custom-template").strip("-")
    return slug or "custom-template"


def create_template_asset_package(payload: dict) -> dict:
    """Create a custom template asset package from uploaded/base64/text assets."""
    name = (payload.get("name") or "自定义模板").strip()
    package_id = payload.get("id") or f"custom-{_safe_template_id(name)[:32]}-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
    package_id = re.sub(r"[^a-zA-Z0-9_-]+", "-", package_id).strip("-")
    root = custom_template_asset_root() / package_id
    root.mkdir(parents=True, exist_ok=True)

    reference_docx = ""
    encoded_docx = (payload.get("reference_docx_base64") or "").strip()
    if encoded_docx:
        reference_docx = "reference.docx"
        (root / reference_docx).write_bytes(base64.b64decode(encoded_docx))

    csl = ""
    csl_text = (payload.get("csl_text") or "").strip()
    if csl_text:
        csl = "style.csl"
        (root / csl).write_text(csl_text, encoding="utf-8")

    cover = "cover.md"
    (root / cover).write_text(payload.get("cover_markdown") or "# 封面说明\n\n请在这里记录学校/期刊封面要求。\n", encoding="utf-8")
    statement = "statement.md"
    (root / statement).write_text(payload.get("statement_markdown") or "请补充原创声明、伦理声明或投稿声明。\n", encoding="utf-8")
    sample_markdown = "sample.md"
    (root / sample_markdown).write_text(payload.get("sample_markdown") or "# 样例稿\n\n正文示例。\n", encoding="utf-8")
    visual_checklist = "visual-checklist.md"
    rules = payload.get("format_rules") or []
    if isinstance(rules, str):
        rules = [item.strip() for item in rules.splitlines() if item.strip()]
    checklist = "\n".join(f"- [ ] {rule}" for rule in rules) or "- [ ] 核对标题、摘要、目录、页眉页脚、参考文献格式。"
    (root / visual_checklist).write_text(f"# {name} 视觉检查清单\n\n{checklist}\n", encoding="utf-8")

    manifest = {
        "id": package_id,
        "kind": "precision",
        "name": name,
        "description": payload.get("description") or "用户导入的学校/期刊模板资产包",
        "scope_note": "自定义精确模板资产包，区别于通用模板预设；用于 reference.docx、CSL 和定稿检查。",
        "reference_docx": reference_docx,
        "csl": csl,
        "cover": cover,
        "statement": statement,
        "sample_markdown": sample_markdown,
        "visual_checklist": visual_checklist,
        "delivery": payload.get("delivery") or ["DOCX", "PDF", "参考文献"],
        "required_sections": payload.get("required_sections") or [],
        "format_rules": rules,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    manifest["warnings"] = validate_template_asset_package({
        **manifest,
        "reference_docx": str(root / reference_docx) if reference_docx else "",
        "csl": str(root / csl) if csl else "",
        "visual_checklist": str(root / visual_checklist),
    })
    (root / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return get_template_asset_package(package_id) or manifest


def delete_template_asset_package(package_id: str) -> None:
    package = get_template_asset_package(package_id)
    if not package:
        return
    if package.get("source") != "custom":
        raise ValueError("内置模板不能删除")
    root = Path(package["asset_root"])
    for child in sorted(root.rglob("*"), reverse=True):
        if child.is_file():
            child.unlink()
        elif child.is_dir():
            child.rmdir()
    root.rmdir()

def _safe_title(title: str) -> str:
    cleaned = re.sub(r"[^\w\u4e00-\u9fff\-]+", "-", title or "manuscript").strip("-")
    return cleaned or "manuscript"


def normalize_math_markdown(markdown: str) -> str:
    """Normalize common AI-emitted TeX delimiters for Pandoc/Quarto and preview."""
    lines: list[str] = []
    in_display_math = False
    for line in (markdown or "").splitlines():
        stripped = line.strip()
        if re.fullmatch(r"\\+\[", stripped):
            lines.append("$$")
            in_display_math = True
            continue
        if re.fullmatch(r"\\+\]", stripped):
            lines.append("$$")
            in_display_math = False
            continue
        if in_display_math:
            lines.append(line.replace("\\\\", "\\"))
            continue
        normalized = re.sub(r"\\\\?\((.*?)\\\\?\)", r"$\1$", line)
        lines.append(normalized)
    return "\n".join(lines)


def markdown_to_html(markdown: str, title: str = "Scholar Assist Manuscript") -> str:
    """Convert a practical subset of Markdown into standalone manuscript HTML."""
    lines = normalize_math_markdown(markdown or "").splitlines()
    body: list[str] = []
    in_list = False
    in_code = False
    in_math = False
    code_lines: list[str] = []
    math_lines: list[str] = []

    def close_list() -> None:
        nonlocal in_list
        if in_list:
            body.append("</ul>")
            in_list = False

    def close_math() -> None:
        nonlocal in_math, math_lines
        if in_math:
            body.append(f"<div class=\"math-block\">\\[{html.escape(chr(10).join(math_lines))}\\]</div>")
            math_lines = []
            in_math = False

    for line in lines:
        raw = line.rstrip()
        if raw.strip() == "$$":
            close_list()
            if in_math:
                close_math()
            else:
                in_math = True
            continue
        if in_math:
            math_lines.append(raw)
            continue
        if raw.startswith("```"):
            if in_code:
                body.append(f"<pre><code>{html.escape(chr(10).join(code_lines))}</code></pre>")
                code_lines = []
                in_code = False
            else:
                close_list()
                in_code = True
            continue
        if in_code:
            code_lines.append(raw)
            continue
        if not raw.strip():
            close_list()
            continue

        heading = re.match(r"^(#{1,6})\s+(.*)$", raw)
        if heading:
            close_list()
            level = len(heading.group(1))
            body.append(f"<h{level}>{html.escape(heading.group(2).strip())}</h{level}>")
            continue

        item = re.match(r"^\s*(?:[-*+]|\d+\.)\s+(.*)$", raw)
        if item:
            if not in_list:
                body.append("<ul>")
                in_list = True
            body.append(f"<li>{html.escape(item.group(1).strip())}</li>")
            continue

        close_list()
        text = html.escape(raw)
        text = re.sub(r"\*\*(.*?)\*\*", r"<strong>\1</strong>", text)
        text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
        body.append(f"<p>{text}</p>")

    close_list()
    close_math()
    if in_code:
        body.append(f"<pre><code>{html.escape(chr(10).join(code_lines))}</code></pre>")

    escaped_title = html.escape(title or "Scholar Assist Manuscript")
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <title>{escaped_title}</title>
  <style>
    @page {{ size: A4; margin: 25mm 28mm 25mm 28mm; }}
    body {{
      margin: 0;
      background: #eef2f7;
      color: #111827;
      font-family: "Noto Serif SC", "Songti SC", "SimSun", "Times New Roman", serif;
      line-height: 1.9;
    }}
    .manuscript-page {{
      box-sizing: border-box;
      width: 210mm;
      min-height: 297mm;
      margin: 24px auto;
      padding: 25mm 28mm;
      background: #fff;
      box-shadow: 0 20px 55px rgba(15, 23, 42, .14);
    }}
    h1, h2, h3 {{ color: #0f172a; font-weight: 700; line-height: 1.45; page-break-after: avoid; }}
    h1 {{ margin: 0 0 28px; text-align: center; font-size: 22pt; }}
    h2 {{ margin: 28px 0 12px; font-size: 15pt; border-bottom: 1px solid #dbe3ef; padding-bottom: 6px; }}
    h3 {{ margin: 20px 0 8px; font-size: 13pt; }}
    p {{ margin: 0 0 10px; text-align: justify; text-indent: 2em; font-size: 12pt; }}
    li {{ margin: 4px 0; font-size: 12pt; }}
    ul {{ margin: 8px 0 12px 2em; padding: 0; }}
    pre {{ background: #f8fafc; border: 1px solid #dbe3ef; border-radius: 4px; padding: 12px; overflow: auto; }}
    code {{ font-family: "SF Mono", Menlo, Consolas, monospace; font-size: 10.5pt; }}
    .math-block {{ margin: 14px 0; overflow-x: auto; text-align: center; text-indent: 0; }}
    @media print {{
      body {{ background: #fff; }}
      .manuscript-page {{ width: auto; min-height: auto; margin: 0; padding: 0; box-shadow: none; }}
    }}
  </style>
  <script>
    window.MathJax = {{ tex: {{ inlineMath: [['$', '$'], ['\\\\(', '\\\\)']], displayMath: [['$$', '$$'], ['\\\\[', '\\\\]']] }}, svg: {{ fontCache: 'global' }} }};
  </script>
  <script async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script>
</head>
<body>
<main class="manuscript-page">
{chr(10).join(body)}
</main>
</body>
</html>"""


def _docx_escape(text: str) -> str:
    return html.escape(text or "", quote=False)


def _docx_paragraph(text: str, style: str = "") -> str:
    style_xml = f'<w:pPr><w:pStyle w:val="{style}"/></w:pPr>' if style else ""
    return f"<w:p>{style_xml}<w:r><w:t xml:space=\"preserve\">{_docx_escape(text)}</w:t></w:r></w:p>"


def _docx_page_break() -> str:
    return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>'


def _docx_field(instruction: str) -> str:
    escaped_instruction = _docx_escape(instruction)
    return (
        '<w:r><w:fldChar w:fldCharType="begin"/></w:r>'
        f'<w:r><w:instrText xml:space="preserve">{escaped_instruction}</w:instrText></w:r>'
        '<w:r><w:fldChar w:fldCharType="separate"/></w:r>'
        '<w:r><w:t xml:space="preserve">右键更新域以刷新</w:t></w:r>'
        '<w:r><w:fldChar w:fldCharType="end"/></w:r>'
    )


def _docx_field_paragraph(instruction: str, style: str = "") -> str:
    style_xml = f'<w:pPr><w:pStyle w:val="{style}"/></w:pPr>' if style else ""
    return f"<w:p>{style_xml}{_docx_field(instruction)}</w:p>"


def _docx_bookmark_paragraph(text: str, style: str, bookmark: str) -> str:
    style_xml = f'<w:pPr><w:pStyle w:val="{style}"/></w:pPr>' if style else ""
    return (
        f"<w:p>{style_xml}"
        f'<w:bookmarkStart w:id="1" w:name="{bookmark}"/>'
        f'<w:r><w:t xml:space="preserve">{_docx_escape(text)}</w:t></w:r>'
        '<w:bookmarkEnd w:id="1"/>'
        "</w:p>"
    )


def markdown_to_docx_bytes(markdown: str, title: str = "Scholar Assist Manuscript") -> bytes:
    """Create a valid DOCX with manuscript-oriented styles using stdlib zipfile."""
    paragraphs: list[str] = []
    first_heading_bookmarked = False
    for line in normalize_math_markdown(markdown or "").splitlines():
        raw = line.rstrip()
        if not raw:
            paragraphs.append("<w:p/>")
            continue
        heading = re.match(r"^(#{1,3})\s+(.*)$", raw)
        if heading:
            style = f"Heading{len(heading.group(1))}"
            heading_text = heading.group(2).strip()
            if not first_heading_bookmarked:
                paragraphs.append(_docx_bookmark_paragraph(heading_text, style, "_RefHeading1"))
                first_heading_bookmarked = True
            else:
                paragraphs.append(_docx_paragraph(heading_text, style))
        else:
            cleaned = re.sub(r"^\s*(?:[-*+]|\d+\.)\s+", "• ", raw)
            cleaned = cleaned.replace("**", "").replace("`", "")
            paragraphs.append(_docx_paragraph(cleaned, "ManuscriptBody"))

    cover_xml = (
        _docx_paragraph(title, "Title")
        + _docx_paragraph("Scholar Assist 论文定稿导出", "ManuscriptBody")
        + _docx_paragraph(f"导出时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}", "ManuscriptBody")
        + _docx_page_break()
    )
    toc_xml = (
        _docx_paragraph("目录", "Heading1")
        + _docx_field_paragraph(' TOC \\o "1-3" \\h \\z \\u ')
        + _docx_paragraph("跳转到正文：", "ManuscriptBody")
        + _docx_field_paragraph(" PAGEREF _RefHeading1 \\h ", "ManuscriptBody")
        + _docx_page_break()
    )

    document_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <w:body>
    {cover_xml}
    {toc_xml}
    {''.join(paragraphs)}
    <w:sectPr>
      <w:headerReference w:type="default" r:id="rIdHeader1"/>
      <w:footerReference w:type="default" r:id="rIdFooter1"/>
      <w:pgSz w:w="11906" w:h="16838"/>
      <w:pgMar w:top="1417" w:right="1587" w:bottom="1417" w:left="1587"/>
    </w:sectPr>
  </w:body>
</w:document>"""
    styles_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault>
      <w:rPr>
        <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="宋体"/>
        <w:sz w:val="24"/>
      </w:rPr>
    </w:rPrDefault>
    <w:pPrDefault>
      <w:pPr><w:spacing w:line="360" w:lineRule="auto"/></w:pPr>
    </w:pPrDefault>
  </w:docDefaults>
  <w:style w:type="paragraph" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:qFormat/>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Title">
    <w:name w:val="Title"/>
    <w:basedOn w:val="Normal"/>
    <w:qFormat/>
    <w:pPr>
      <w:spacing w:before="240" w:after="360"/>
      <w:jc w:val="center"/>
    </w:pPr>
    <w:rPr>
      <w:b/>
      <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="黑体"/>
      <w:sz w:val="40"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="ManuscriptBody">
    <w:name w:val="论文正文"/>
    <w:basedOn w:val="Normal"/>
    <w:qFormat/>
    <w:pPr>
      <w:spacing w:before="0" w:after="120" w:line="360" w:lineRule="auto"/>
      <w:ind w:firstLineChars="200"/>
      <w:jc w:val="both"/>
    </w:pPr>
    <w:rPr>
      <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="宋体"/>
      <w:sz w:val="24"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1">
    <w:name w:val="heading 1"/>
    <w:basedOn w:val="Normal"/>
    <w:next w:val="ManuscriptBody"/>
    <w:qFormat/>
    <w:pPr><w:spacing w:before="240" w:after="240"/><w:jc w:val="center"/></w:pPr>
    <w:rPr><w:b/><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="黑体"/><w:sz w:val="36"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading2">
    <w:name w:val="heading 2"/>
    <w:basedOn w:val="Normal"/>
    <w:next w:val="ManuscriptBody"/>
    <w:qFormat/>
    <w:pPr><w:spacing w:before="240" w:after="120"/></w:pPr>
    <w:rPr><w:b/><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="黑体"/><w:sz w:val="30"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading3">
    <w:name w:val="heading 3"/>
    <w:basedOn w:val="Normal"/>
    <w:next w:val="ManuscriptBody"/>
    <w:qFormat/>
    <w:pPr><w:spacing w:before="180" w:after="100"/></w:pPr>
    <w:rPr><w:b/><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="黑体"/><w:sz w:val="26"/></w:rPr>
  </w:style>
</w:styles>"""
    core_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>{_docx_escape(title)}</dc:title>
  <dc:creator>Scholar Assist</dc:creator>
  <dcterms:created xsi:type="dcterms:W3CDTF">{datetime.now(timezone.utc).isoformat()}</dcterms:created>
</cp:coreProperties>"""
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
  <Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>
  <Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
</Types>"""
    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
</Relationships>"""
    document_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rIdHeader1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>
  <Relationship Id="rIdFooter1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>
</Relationships>"""
    header_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:p>
    <w:pPr><w:jc w:val="center"/></w:pPr>
    <w:r><w:rPr><w:sz w:val="18"/></w:rPr><w:t>Scholar Assist</w:t></w:r>
  </w:p>
</w:hdr>"""
    footer_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:p>
    <w:pPr><w:jc w:val="center"/></w:pPr>
    <w:r><w:t>第 </w:t></w:r>
    <w:r><w:fldChar w:fldCharType="begin"/></w:r>
    <w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>
    <w:r><w:fldChar w:fldCharType="separate"/></w:r>
    <w:r><w:t>1</w:t></w:r>
    <w:r><w:fldChar w:fldCharType="end"/></w:r>
    <w:r><w:t> 页</w:t></w:r>
  </w:p>
</w:ftr>"""

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", rels)
        zf.writestr("word/document.xml", document_xml)
        zf.writestr("word/_rels/document.xml.rels", document_rels)
        zf.writestr("word/styles.xml", styles_xml)
        zf.writestr("word/header1.xml", header_xml)
        zf.writestr("word/footer1.xml", footer_xml)
        zf.writestr("docProps/core.xml", core_xml)
    return buf.getvalue()


def scholar_assist_cache_dir(*parts: str) -> Path:
    path = Path.home() / ".scholar-assist" / Path(*parts)
    path.mkdir(parents=True, exist_ok=True)
    return path


def resolve_csl_style(style: str) -> str:
    """Resolve a CSL style id/path/URL into a local file path for Pandoc/Quarto."""
    value = (style or "").strip()
    if not value:
        return ""
    if Path(value).exists():
        return value
    url = CSL_STYLE_URLS.get(value.lower())
    if not url:
        return ""
    target = scholar_assist_cache_dir("styles") / f"{value.lower()}.csl"
    if target.exists() and target.stat().st_size > 1000:
        return str(target)
    try:
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        if "<style" in resp.text[:500]:
            target.write_text(resp.text, encoding="utf-8")
            return str(target)
    except Exception:
        return ""
    return ""


def ensure_reference_docx(template_id: str = "journal") -> str:
    """Create a local DOCX reference template that Pandoc can reuse for styles."""
    clean_id = re.sub(r"[^a-zA-Z0-9_-]+", "-", template_id or "journal")
    custom = get_template_asset_package(clean_id)
    if custom and custom.get("reference_docx") and Path(str(custom["reference_docx"])).exists():
        return str(custom["reference_docx"])
    target = scholar_assist_cache_dir("templates") / f"{clean_id}-reference.docx"
    if not target.exists() or target.stat().st_size < 1000:
        target.write_bytes(markdown_to_docx_bytes(f"# {clean_id} reference\n\n正文样式。", f"{clean_id} reference"))
    return str(target)


def prepare_publication_source(
    tmp: str,
    filename: str,
    markdown: str,
    title: str,
    references_bib: str = "",
    citation_style: str = "",
) -> str:
    """Create a self-contained temporary Markdown/QMD source for external renderers."""
    tmp_path = Path(tmp)
    tmp_path.mkdir(parents=True, exist_ok=True)
    references = tmp_path / "references.bib"
    references.write_text(references_bib or "", encoding="utf-8")
    safe_title = (title or "Scholar Assist Manuscript").replace('"', "'")
    resolved_csl = resolve_csl_style(citation_style)
    csl_line = f"csl: {Path(resolved_csl).name}\n" if resolved_csl else ""
    if resolved_csl:
        csl_target = tmp_path / Path(resolved_csl).name
        if not csl_target.exists():
            csl_target.write_text(Path(resolved_csl).read_text(encoding="utf-8"), encoding="utf-8")
    metadata = (
        "---\n"
        f'title: "{safe_title}"\n'
        f"date: {datetime.now().strftime('%Y-%m-%d')}\n"
        "bibliography: references.bib\n"
        f"{csl_line}"
        "link-citations: true\n"
        "number-sections: true\n"
        "---\n\n"
    )
    source = tmp_path / filename
    source.write_text(metadata + normalize_math_markdown(markdown or ""), encoding="utf-8")
    return str(source)


def build_pandoc_command(pandoc: str, source: str, target: str, crossref: str = "", reference_docx: str = "") -> list[str]:
    command = [pandoc, source, "--standalone", "--toc", "--number-sections", "-o", target]
    if crossref:
        command.extend(["--filter", crossref])
    if reference_docx and target.endswith(".docx"):
        command.extend(["--reference-doc", reference_docx])
    return command


def build_quarto_command(quarto: str, source_name: str, fmt: str, output_name: str) -> list[str]:
    return [quarto, "render", source_name, "--to", fmt, "--output", output_name]


def try_pandoc_export(
    markdown: str,
    title: str,
    fmt: str,
    references_bib: str = "",
    citation_style: str = "",
    template_id: str = "journal",
) -> bytes | None:
    """Use Pandoc when installed, otherwise let callers fall back gracefully."""
    pandoc = resolve_tool_path("pandoc")
    if not pandoc:
        return None
    clean_fmt = "markdown" if fmt == "md" else fmt
    if clean_fmt not in {"html", "docx", "pdf"}:
        return None
    suffix = {"html": ".html", "docx": ".docx", "pdf": ".pdf"}[clean_fmt]
    with tempfile.TemporaryDirectory(prefix="scholar-assist-pandoc-") as tmp:
        source = prepare_publication_source(tmp, "manuscript.md", markdown, title, references_bib, citation_style)
        target = f"{tmp}/manuscript{suffix}"
        reference_docx = ensure_reference_docx(template_id) if clean_fmt == "docx" else ""
        command = build_pandoc_command(pandoc, source, target, resolve_tool_path("pandoc-crossref"), reference_docx)
        result = subprocess.run(command, capture_output=True, text=True, timeout=45, check=False)
        if result.returncode != 0:
            return None
        with open(target, "rb") as handle:
            return handle.read()


def try_quarto_export(markdown: str, title: str, fmt: str, references_bib: str = "", citation_style: str = "") -> bytes | None:
    """Use Quarto when installed; return None when unavailable or render fails."""
    quarto = resolve_tool_path("quarto")
    if not quarto:
        return None
    clean_fmt = "markdown" if fmt == "md" else fmt
    if clean_fmt not in {"html", "docx", "pdf"}:
        return None
    suffix = {"html": ".html", "docx": ".docx", "pdf": ".pdf"}[clean_fmt]
    with tempfile.TemporaryDirectory(prefix="scholar-assist-quarto-") as tmp:
        prepare_publication_source(tmp, "manuscript.qmd", markdown, title, references_bib, citation_style)
        output_name = f"manuscript{suffix}"
        target = f"{tmp}/{output_name}"
        result = subprocess.run(
            build_quarto_command(quarto, "manuscript.qmd", clean_fmt, output_name),
            cwd=tmp,
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
        if result.returncode != 0:
            return None
        with open(target, "rb") as handle:
            return handle.read()


def markdown_to_pdf_bytes(markdown: str, title: str = "Scholar Assist Manuscript") -> bytes:
    """Create a simple PDF using PyMuPDF when available."""
    import fitz

    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    margin_x = 54
    y = 56
    line_height = 18
    max_width = 487
    font_size = 11

    def add_line(text: str, size: int = font_size, bold: bool = False) -> None:
        nonlocal page, y
        if y > 790:
            page = doc.new_page(width=595, height=842)
            y = 56
        font = "helv" if not bold else "hebo"
        page.insert_textbox(
            fitz.Rect(margin_x, y, margin_x + max_width, y + line_height * 2.4),
            text,
            fontsize=size,
            fontname=font,
            color=(0.08, 0.10, 0.16),
            align=fitz.TEXT_ALIGN_LEFT,
        )
        y += line_height * (2 if len(text) > 70 else 1.2)

    for line in normalize_math_markdown(markdown or title).splitlines():
        raw = line.strip()
        if not raw:
            y += line_height * 0.5
            continue
        heading = re.match(r"^(#{1,3})\s+(.*)$", raw)
        if heading:
            level = len(heading.group(1))
            y += 8
            add_line(heading.group(2), size={1: 18, 2: 15, 3: 13}[level], bold=True)
        else:
            cleaned = re.sub(r"^\s*(?:[-*+]|\d+\.)\s+", "• ", raw)
            cleaned = cleaned.replace("**", "").replace("`", "")
            for chunk in re.findall(r".{1,64}(?:\s+|$)|.{1,64}", cleaned):
                add_line(chunk.strip())

    data = doc.tobytes()
    doc.close()
    return data


def build_export_manifest(
    markdown: str,
    title: str,
    fmt: str,
    papers: list[dict] | None = None,
    citation_style: str = "",
    template_id: str = "journal",
) -> dict:
    """Describe the export plan so users can diagnose DOCX/PDF output quality."""
    text = normalize_math_markdown(markdown or "")
    clean_fmt = (fmt or "markdown").lower().strip()
    papers = papers or []
    tools = {
        "quarto": resolve_tool_path("quarto"),
        "pandoc": resolve_tool_path("pandoc"),
        "pandoc-crossref": resolve_tool_path("pandoc-crossref"),
    }
    math_blocks = text.count("$$") // 2
    content = {
        "headings": len(re.findall(r"^#{1,6}\s+", text, re.M)),
        "citations": len(re.findall(r"@([A-Za-z0-9:_\-./]+)", text)),
        "figures": len(re.findall(r"!\[[^\]]*\]\([^)]+\)", text)),
        "tables": len(re.findall(r"^\|.+\|$", text, re.M)),
        "math_blocks": math_blocks,
        "references": len(papers),
    }
    risks = []
    if clean_fmt == "pdf" and not (tools["quarto"] or tools["pandoc"]):
        risks.append("PDF 需要 Quarto/Pandoc 与 LaTeX/PDF 引擎；当前将建议前端打印兜底。")
    if content["citations"] and not papers:
        risks.append("正文有引用 key，但导出请求未携带项目库文献。")
    if text.count("$$") % 2:
        risks.append("检测到未闭合公式块，可能导致导出乱码。")
    if clean_fmt == "docx" and not (tools["quarto"] or tools["pandoc"]):
        risks.append("DOCX 将使用内置兜底模板；复杂交叉引用建议安装 Pandoc/Quarto。")

    manifest = {
        "title": title or "Scholar Assist Manuscript",
        "format": clean_fmt,
        "template_id": template_id or "journal",
        "template_profile": get_template_reference_profile(template_id),
        "citation_style": citation_style or "",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "engines": {name: {"available": bool(path), "path": path} for name, path in tools.items()},
        "content": content,
        "risks": risks,
        "recommended_route": "quarto" if tools["quarto"] else "pandoc" if tools["pandoc"] else "builtin-fallback",
    }
    if clean_fmt == "docx":
        manifest["reference_docx"] = ensure_reference_docx(template_id)
    return manifest


def export_filename(title: str, ext: str) -> str:
    return f"{_safe_title(title)}.{ext.lstrip('.')}"


def content_disposition_header(title: str, ext: str) -> str:
    """Build a browser-safe attachment header for Chinese manuscript names."""
    clean_ext = ext.lstrip(".")
    filename = export_filename(title, clean_ext)
    stem = filename[: -(len(clean_ext) + 1)] if filename.endswith(f".{clean_ext}") else filename
    ascii_stem = re.sub(r"[^A-Za-z0-9_-]+", "-", stem).strip("-") or "manuscript"
    ascii_fallback = f"{ascii_stem}.{clean_ext}"
    return f'attachment; filename="{ascii_fallback}"; filename*=UTF-8\'\'{quote(filename)}'
