"""Manuscript export API routes."""
from __future__ import annotations

from typing import Union

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel
from services.export_service import (
    build_export_manifest,
    content_disposition_header,
    create_template_asset_package,
    delete_template_asset_package,
    get_template_asset_package,
    list_template_asset_packages,
    markdown_to_docx_bytes,
    markdown_to_html,
    try_pandoc_export,
    try_quarto_export,
)
from services.citation_service import format_bibtex

router = APIRouter(prefix="/api/export", tags=["文稿导出"])


class ManuscriptExportRequest(BaseModel):
    markdown: str
    title: str = "Scholar Assist Manuscript"
    format: str = "markdown"
    papers: list[dict] = []
    citation_style: str = ""
    template_id: str = "journal"


class TemplateAssetPackageRequest(BaseModel):
    name: str
    description: str = ""
    reference_docx_base64: str = ""
    csl_text: str = ""
    cover_markdown: str = ""
    statement_markdown: str = ""
    sample_markdown: str = ""
    format_rules: Union[list[str], str] = []
    required_sections: list[str] = []
    delivery: list[str] = []


@router.get("/template-packages")
async def export_template_packages():
    return {"templates": list_template_asset_packages()}


@router.post("/template-packages")
async def create_export_template_package(req: TemplateAssetPackageRequest):
    return {"template": create_template_asset_package(req.model_dump())}


@router.get("/template-packages/{package_id}")
async def get_export_template_package(package_id: str):
    package = get_template_asset_package(package_id)
    if not package:
        raise HTTPException(status_code=404, detail="模板包不存在")
    return {"template": package}


@router.delete("/template-packages/{package_id}")
async def delete_export_template_package(package_id: str):
    try:
        delete_template_asset_package(package_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"status": "ok"}


@router.post("/manuscript")
async def export_manuscript(req: ManuscriptExportRequest):
    """Export the current manuscript as Markdown, HTML, DOCX or PDF."""
    fmt = req.format.lower().strip()
    references_bib = format_bibtex(req.papers) if req.papers else ""
    try:
        if fmt in {"markdown", "md"}:
            content = req.markdown.encode("utf-8")
            return Response(
                content,
                media_type="text/markdown; charset=utf-8",
                headers={"Content-Disposition": content_disposition_header(req.title, "md")},
            )
        if fmt == "html":
            rendered_content = (
                try_quarto_export(req.markdown, req.title, "html", references_bib, req.citation_style)
                or try_pandoc_export(req.markdown, req.title, "html", references_bib, req.citation_style, req.template_id)
            )
            content = markdown_to_html(req.markdown, req.title).encode("utf-8")
            return Response(
                rendered_content or content,
                media_type="text/html; charset=utf-8",
                headers={"Content-Disposition": content_disposition_header(req.title, "html")},
            )
        if fmt == "docx":
            return Response(
                try_quarto_export(req.markdown, req.title, "docx", references_bib, req.citation_style)
                or try_pandoc_export(req.markdown, req.title, "docx", references_bib, req.citation_style, req.template_id)
                or markdown_to_docx_bytes(req.markdown, req.title),
                media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                headers={"Content-Disposition": content_disposition_header(req.title, "docx")},
            )
        if fmt == "pdf":
            rendered_pdf = (
                try_quarto_export(req.markdown, req.title, "pdf", references_bib, req.citation_style)
                or try_pandoc_export(req.markdown, req.title, "pdf", references_bib, req.citation_style, req.template_id)
            )
            if not rendered_pdf:
                raise HTTPException(
                    status_code=503,
                    detail="PDF 导出需要可用的 Quarto/Pandoc PDF 引擎；请使用前端打印 PDF 兜底。",
                )
            return Response(
                rendered_pdf,
                media_type="application/pdf",
                headers={"Content-Disposition": content_disposition_header(req.title, "pdf")},
            )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"导出失败: {exc}") from exc

    raise HTTPException(status_code=400, detail="format 仅支持 markdown/html/docx/pdf")


@router.post("/manifest")
async def export_manifest(req: ManuscriptExportRequest):
    """Return an export plan for debugging engine/template/citation quality."""
    fmt = req.format.lower().strip()
    if fmt not in {"markdown", "md", "html", "docx", "pdf"}:
        raise HTTPException(status_code=400, detail="format 仅支持 markdown/html/docx/pdf")
    return {
        "manifest": build_export_manifest(
            req.markdown,
            req.title,
            fmt,
            req.papers,
            req.citation_style,
            req.template_id,
        )
    }
