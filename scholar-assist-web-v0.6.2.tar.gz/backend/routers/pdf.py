"""PDF 解析 API 路由"""
import os
import logging
import uuid
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, Header, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from services.pdf_service import (
    delete_pdf_annotation,
    extract_pdf_metadata_only,
    extract_pdf_text,
    list_pdf_annotations,
    save_pdf_annotation,
)
from services.library_service import document_belongs_to_workspace, paper_belongs_to_workspace, save_paper

router = APIRouter(prefix="/api/pdf", tags=["PDF 解析"])
logger = logging.getLogger(__name__)

DEFAULT_UPLOAD_DIR = Path(__file__).resolve().parents[1] / "uploads"
DEFAULT_MAX_PDF_BYTES = 50 * 1024 * 1024


def upload_root() -> Path:
    root = Path(os.getenv("SCHOLAR_ASSIST_PDF_UPLOAD_DIR", str(DEFAULT_UPLOAD_DIR))).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def max_pdf_bytes() -> int:
    try:
        return max(1, int(os.getenv("SCHOLAR_ASSIST_MAX_PDF_BYTES", str(DEFAULT_MAX_PDF_BYTES))))
    except ValueError:
        return DEFAULT_MAX_PDF_BYTES


def resolve_uploaded_pdf(reference: str) -> Path:
    root = upload_root()
    raw = Path(reference or "")
    candidate = raw.resolve() if raw.is_absolute() else (root / raw.name).resolve()
    if candidate != root and root not in candidate.parents:
        raise ValueError("只能读取 Scholar Assist 上传目录中的 PDF")
    if candidate.suffix.lower() != ".pdf" or not candidate.is_file():
        raise ValueError("PDF 文件不存在或不在上传目录中")
    return candidate


def ensure_pdf_workspace_access(file_path: Path, workspace_id: str) -> None:
    document_id = file_path.stem
    if not document_belongs_to_workspace(document_id, workspace_id):
        raise HTTPException(status_code=404, detail="当前工作区不存在该 PDF")


class FilePathRequest(BaseModel):
    file_path: str


class PDFAnnotationRequest(BaseModel):
    id: Optional[str] = None
    page: int
    text: str
    note: str = ""
    tags: list[str] = Field(default_factory=list)
    rect: Optional[dict] = None
    createdAt: Optional[str] = None


def scoped_paper_id(paper_id: str, workspace_id: str) -> str:
    return f"{workspace_id or 'default'}::{paper_id}"


def ensure_paper_workspace_access(paper_id: str, workspace_id: str) -> None:
    if not paper_belongs_to_workspace(paper_id, workspace_id):
        raise HTTPException(status_code=404, detail="当前工作区不存在该论文")


@router.post("/upload")
async def upload_pdf(
    file: UploadFile = File(..., description="PDF 文件"),
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    """上传 PDF 文件并提取全文和元数据"""
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="仅支持 PDF 文件")

    file_path: Path | None = None
    try:
        limit = max_pdf_bytes()
        chunks = []
        total = 0
        while True:
            chunk = await file.read(min(1024 * 1024, limit + 1))
            if not chunk:
                break
            total += len(chunk)
            if total > limit:
                raise HTTPException(status_code=413, detail=f"PDF 文件超过 {limit // (1024 * 1024) or 1} MB 限制")
            chunks.append(chunk)
        content = b"".join(chunks)
        if not content.startswith(b"%PDF-"):
            raise HTTPException(status_code=400, detail="文件不是有效的 PDF")

        document_id = uuid.uuid4().hex
        file_path = upload_root() / f"{document_id}.pdf"
        file_path.write_bytes(content)

        # 提取内容
        result = await extract_pdf_text(str(file_path))
        if "error" in result:
            file_path.unlink(missing_ok=True)
            raise HTTPException(status_code=500, detail=result["error"])

        persisted_layouts = [
            {**layout, "preview_url": ""}
            for layout in result.get("page_layouts", [])
        ]
        result.update({
            "document_id": document_id,
            "pdf_filename": file.filename,
            "url": f"/api/pdf/documents/{document_id}/file",
        })
        save_paper(
            {
                **result,
                "abstract_text": result.get("abstract", ""),
                "page_layouts": persisted_layouts,
            },
            workspace_id,
        )

        return {
            "filename": file.filename,
            "document_id": document_id,
            "file_path": file_path.name,
            "persisted": True,
            "paper": result,
        }
    except HTTPException:
        raise
    except Exception as exc:
        if file_path is not None:
            file_path.unlink(missing_ok=True)
        logger.exception("PDF upload processing failed")
        raise HTTPException(status_code=500, detail="PDF 上传处理失败，请检查文件是否完整并重试") from exc


@router.get("/documents/{document_id}/file")
async def get_uploaded_pdf(
    document_id: str,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    """Return an uploaded PDF without exposing arbitrary filesystem paths."""
    if not document_id or any(char not in "0123456789abcdef" for char in document_id.lower()):
        raise HTTPException(status_code=400, detail="无效的 PDF 文档编号")
    if not document_belongs_to_workspace(document_id, workspace_id):
        raise HTTPException(status_code=404, detail="当前工作区不存在该 PDF")
    try:
        file_path = resolve_uploaded_pdf(f"{document_id}.pdf")
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return FileResponse(file_path, media_type="application/pdf", filename=f"{document_id}.pdf")


@router.post("/extract")
async def extract_pdf(
    req: FilePathRequest,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    """从已存在的文件路径提取 PDF 内容"""
    try:
        file_path = resolve_uploaded_pdf(req.file_path)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    ensure_pdf_workspace_access(file_path, workspace_id)
    result = await extract_pdf_text(str(file_path))
    if "error" in result:
        raise HTTPException(status_code=500, detail=result["error"])
    return {"paper": result}


@router.post("/metadata")
async def get_metadata(
    req: FilePathRequest,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    """仅提取 PDF 元数据"""
    try:
        file_path = resolve_uploaded_pdf(req.file_path)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    ensure_pdf_workspace_access(file_path, workspace_id)
    result = await extract_pdf_metadata_only(str(file_path))
    if "error" in result:
        raise HTTPException(status_code=500, detail=result["error"])
    return {"metadata": result}


@router.get("/{paper_id}/annotations")
async def get_pdf_annotations(
    paper_id: str,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    """读取 PDF 批注/高亮，供阅读器重开后恢复。"""
    ensure_paper_workspace_access(paper_id, workspace_id)
    return {"paper_id": paper_id, "annotations": list_pdf_annotations(scoped_paper_id(paper_id, workspace_id))}


@router.post("/{paper_id}/annotations")
async def upsert_pdf_annotation(
    paper_id: str,
    req: PDFAnnotationRequest,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    """保存或更新 PDF 批注/高亮。"""
    ensure_paper_workspace_access(paper_id, workspace_id)
    annotation = save_pdf_annotation(scoped_paper_id(paper_id, workspace_id), req.model_dump())
    return {"paper_id": paper_id, "annotation": annotation}


@router.delete("/{paper_id}/annotations/{annotation_id}")
async def remove_pdf_annotation(
    paper_id: str,
    annotation_id: str,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    """删除 PDF 批注/高亮。"""
    ensure_paper_workspace_access(paper_id, workspace_id)
    delete_pdf_annotation(scoped_paper_id(paper_id, workspace_id), annotation_id)
    return {"status": "deleted", "paper_id": paper_id, "annotation_id": annotation_id}
