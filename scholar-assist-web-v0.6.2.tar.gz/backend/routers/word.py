"""Word add-in bridge API."""
from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Union

from fastapi import APIRouter
from pydantic import BaseModel, Field


router = APIRouter(prefix="/api/word", tags=["Word 插件"])


class WordBridgeReference(BaseModel):
    title: str = ""
    authors: str = ""
    year: Union[int, str] = ""
    source: str = ""
    doi: str = ""
    url: str = ""
    abstract: str = ""
    notes: str = ""
    citation_key: str = ""


class WordBridgeContext(BaseModel):
    topic: str = ""
    source: str = "writing-mode"
    ai_config: Optional[Dict[str, Any]] = None
    references: List[WordBridgeReference] = Field(default_factory=list)
    updated_at: float = Field(default_factory=lambda: time.time())


_bridge_state = WordBridgeContext()


def _copy_context_with_update(context: WordBridgeContext, update: Dict[str, Any]) -> WordBridgeContext:
    if hasattr(context, "model_copy"):
        return context.model_copy(update=update)  # type: ignore[attr-defined]
    return context.copy(update=update)


@router.post("/bridge")
async def save_word_bridge_context(req: WordBridgeContext):
    """Store the latest local context for the Word add-in."""
    global _bridge_state
    _bridge_state = _copy_context_with_update(req, {"updated_at": time.time()})
    return _bridge_state


@router.get("/bridge")
async def get_word_bridge_context():
    """Return the latest local context for the Word add-in."""
    return _bridge_state
