"""学术搜索 API 路由 — Feature 1+8+9"""
from fastapi import APIRouter, Query
from pydantic import BaseModel
from services.browser_assist_service import (
    browser_assist_diagnostics,
    browser_assist_progress,
    close_assisted_browser_session,
    export_browser_assist_logs,
    get_assisted_browser_status,
    read_assisted_browser_results,
    reset_assisted_browser_profile,
    start_assisted_browser_search,
)
from services.search_service import search_all, paper_to_dict

router = APIRouter(prefix="/api/search", tags=["学术搜索"])


class BrowserAssistStartRequest(BaseModel):
    engine: str = "google_scholar"
    query: str
    category: str = "all"
    auto_translate: bool = True


class BrowserAssistReadRequest(BaseModel):
    limit: int = 0
    min_relevance: int = 70
    max_pages: int = 0


class BrowserAssistResetRequest(BaseModel):
    session_id: str = ""


def browser_assist_payload(session, papers=None):
    return {
        "session_id": session.id,
        "engine": session.engine,
        "query": session.query,
        "url": session.url,
        "status": session.status,
        "message": session.message,
        "progress": browser_assist_progress(session),
        "diagnostics": browser_assist_diagnostics(session),
        "papers": [paper_to_dict(p) for p in (papers or [])],
    }


@router.get("/papers")
async def search_papers(
    q: str = Query(..., description="搜索关键词（支持中英文混合）"),
    engines: str = Query("", description="搜索引擎列表，逗号分隔"),
    limit: int = Query(10, ge=1, le=30, description="每个引擎返回结果数"),
    category: str = Query("all", description="搜索分类: all | title | author | journal | abstract"),
    auto_translate: bool = Query(True, description="是否自动中英文双搜索"),
    weight_relevance: float = Query(0.45, ge=0, le=1, description="相关性权重"),
    weight_recency: float = Query(0.20, ge=0, le=1, description="新近度权重"),
    weight_citations: float = Query(0.25, ge=0, le=1, description="引用量权重"),
    weight_novelty: float = Query(0.10, ge=0, le=1, description="新颖度权重"),
):
    """
    跨平台学术论文搜索

    - **q**: 搜索关键词（支持中英文混合输入）
    - **category**: 搜索分类
      - `all` — 综合搜索
      - `title` — 按标题搜索
      - `author` — 按作者搜索
      - `journal` — 按期刊/会议搜索
      - `abstract` — 按摘要/概述搜索
    - **auto_translate**: 输入中文时自动同时搜索中英文
    """
    engine_list = None
    if engines:
        engine_list = [e.strip() for e in engines.split(",") if e.strip()]

    valid_categories = ["all", "title", "author", "journal", "abstract"]
    if category not in valid_categories:
        category = "all"

    results = await search_all(
        q,
        engines=engine_list,
        limit_per_engine=limit,
        category=category,
        auto_translate=auto_translate,
        rank_weights={
            "relevance": weight_relevance,
            "recency": weight_recency,
            "citations": weight_citations,
            "novelty": weight_novelty,
        },
    )

    # 统计各语言结果
    zh_count = sum(1 for p in results if p.search_language == "zh")
    en_count = sum(1 for p in results if p.search_language == "en")

    return {
        "query": q,
        "category": category,
        "total": len(results),
        "zh_results": zh_count,
        "en_results": en_count,
        "auto_translate": auto_translate,
        "rank_weights": {
            "relevance": weight_relevance,
            "recency": weight_recency,
            "citations": weight_citations,
            "novelty": weight_novelty,
        },
        "engines_used": list(set(p.source_engine for p in results)),
        "papers": [paper_to_dict(p) for p in results],
    }


@router.get("/engines")
async def list_engines():
    """列出所有可用的搜索引擎"""
    return {
        "engines": [
            {"id": "semantic_scholar", "name": "Semantic Scholar", "free": True, "api": True, "language": "英文为主", "supports_categories": True},
            {"id": "arxiv", "name": "arXiv", "free": True, "api": True, "language": "英文为主", "supports_categories": True},
            {"id": "google_scholar", "name": "Google Scholar", "free": False, "api": True, "requires_key": True, "language": "多语言", "supports_categories": True},
            {"id": "cnki", "name": "知网", "free": True, "api": False, "experimental": True, "language": "中文为主", "supports_categories": False},
            {"id": "baidu_xueshu", "name": "百度学术", "free": True, "api": False, "experimental": True, "language": "中文为主", "supports_categories": True},
            {"id": "crossref", "name": "Crossref", "free": True, "api": True, "language": "英文为主", "supports_categories": True},
            {"id": "openalex", "name": "OpenAlex", "free": True, "api": True, "language": "英文为主", "supports_categories": True},
            {"id": "pubmed", "name": "PubMed", "free": True, "api": True, "language": "医学/生命科学", "supports_categories": True},
            {"id": "dblp", "name": "DBLP", "free": True, "api": True, "language": "计算机科学", "supports_categories": True},
            {"id": "unpaywall", "name": "Unpaywall", "free": True, "api": True, "language": "开放获取", "supports_categories": False},
            {"id": "papers_with_code", "name": "Papers with Code", "free": True, "api": True, "language": "AI/代码复现", "supports_categories": False},
        ]
    }


@router.get("/categories")
async def list_categories():
    """列出搜索分类选项"""
    return {
        "categories": [
            {"id": "all", "name": "综合搜索", "icon": "🔍", "description": "在标题、摘要、关键词中综合匹配"},
            {"id": "title", "name": "按标题", "icon": "📝", "description": "仅匹配论文标题"},
            {"id": "author", "name": "按作者", "icon": "👤", "description": "搜索特定学者的论文"},
            {"id": "journal", "name": "按期刊/会议", "icon": "📰", "description": "搜索特定期刊或会议的论文"},
            {"id": "abstract", "name": "按概述", "icon": "📋", "description": "在摘要/概述中搜索关键词"},
        ]
    }


@router.post("/browser-assist/start")
async def start_browser_assist(request: BrowserAssistStartRequest):
    """打开可视浏览器搜索页；验证码由用户手动完成。"""
    try:
        session = await start_assisted_browser_search(
            request.engine,
            request.query,
            request.category,
            request.auto_translate,
        )
        return browser_assist_payload(session)
    except RuntimeError as e:
        return {
            "session_id": "",
            "engine": request.engine,
            "query": request.query,
            "url": "",
            "status": "missing_dependency",
            "message": str(e),
            "diagnostics": browser_assist_diagnostics(status="missing_dependency", message=str(e)),
            "papers": [],
        }
    except Exception as e:
        return {
            "session_id": "",
            "engine": request.engine,
            "query": request.query,
            "url": "",
            "status": "load_failed",
            "message": f"浏览器辅助搜索启动失败：{e}",
            "diagnostics": browser_assist_diagnostics(status="load_failed", message=str(e)),
            "papers": [],
        }


@router.post("/browser-assist/{session_id}/read")
async def read_browser_assist(session_id: str, request: BrowserAssistReadRequest):
    """读取用户手动验证后的浏览器结果页，并按相关度阈值连续翻页导入。"""
    try:
        session, papers = await read_assisted_browser_results(
            session_id,
            request.limit,
            request.min_relevance,
            request.max_pages,
        )
        return browser_assist_payload(session, papers)
    except KeyError as e:
        return {
            "session_id": session_id,
            "engine": "",
            "query": "",
            "url": "",
            "status": "not_found",
            "message": str(e),
            "diagnostics": browser_assist_diagnostics(status="not_found", message=str(e)),
            "papers": [],
        }
    except Exception as e:
        return {
            "session_id": session_id,
            "engine": "",
            "query": "",
            "url": "",
            "status": "load_failed",
            "message": f"浏览器读取或翻页失败：{e}",
            "diagnostics": browser_assist_diagnostics(status="load_failed", message=str(e)),
            "papers": [],
        }


@router.get("/browser-assist/{session_id}/status")
async def status_browser_assist(session_id: str):
    """检查浏览器辅助采集任务状态，不导入新结果。"""
    try:
        session = await get_assisted_browser_status(session_id)
        return browser_assist_payload(session)
    except KeyError as e:
        return {
            "session_id": session_id,
            "engine": "",
            "query": "",
            "url": "",
            "status": "not_found",
            "message": str(e),
            "progress": {"logs": []},
            "diagnostics": browser_assist_diagnostics(status="not_found", message=str(e)),
            "papers": [],
        }
    except Exception as e:
        return {
            "session_id": session_id,
            "engine": "",
            "query": "",
            "url": "",
            "status": "load_failed",
            "message": f"浏览器状态检查失败：{e}",
            "progress": {"logs": []},
            "diagnostics": browser_assist_diagnostics(status="load_failed", message=str(e)),
            "papers": [],
        }


@router.get("/browser-assist/{session_id}/logs")
async def export_browser_assist_log(session_id: str):
    """导出浏览器辅助采集日志，便于定位用户现场问题。"""
    try:
        return export_browser_assist_logs(session_id)
    except KeyError as e:
        return {
            "session_id": session_id,
            "status": "not_found",
            "logs": [],
            "markdown": str(e),
        }


@router.post("/browser-assist/reset-profile")
async def reset_browser_assist_profile(request: BrowserAssistResetRequest):
    """关闭辅助浏览器并重置 App 专用 profile。"""
    return await reset_assisted_browser_profile(request.session_id)


@router.delete("/browser-assist/{session_id}")
async def close_browser_assist(session_id: str):
    """关闭浏览器辅助搜索会话。"""
    await close_assisted_browser_session(session_id)
    return {"status": "closed", "session_id": session_id}
