"""图表生成 API 路由"""
from __future__ import annotations
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from services.chart_service import (
    build_nature_figure_workflow,
    generate_chart_from_data,
    generate_latex_table,
    generate_markdown_table,
    render_nature_figure_assets,
    save_chart_artifact,
)

router = APIRouter(prefix="/api/chart", tags=["图表生成"])


class ChartRequest(BaseModel):
    data: dict
    chart_type: str  # "bar" | "line" | "scatter" | "pie"
    title: str = ""
    xlabel: str = ""
    ylabel: str = ""
    color_palette: str = "default"


class TableRequest(BaseModel):
    headers: list[str]
    rows: list[list[str]]
    caption: str = ""
    label: str = ""
    format: str = "markdown"  # "markdown" | "latex"


class NatureFigureRequest(BaseModel):
    topic: str = ""
    conclusion: str = ""
    evidence_items: list[str] = []
    backend: str = "python"
    journal: str = "Nature / high-impact journal"
    source_data_csv: Optional[str] = None
    source_data_file_base64: Optional[str] = None
    source_data_filename: str = ""


@router.post("/generate")
async def generate_chart(req: ChartRequest):
    """根据数据生成学术图表，返回 base64 图片"""
    try:
        chart_base64 = await generate_chart_from_data(
            req.data,
            req.chart_type,
            title=req.title,
            xlabel=req.xlabel,
            ylabel=req.ylabel,
            color_palette=req.color_palette,
        )
        if not chart_base64:
            raise HTTPException(status_code=400, detail="图表生成失败，请检查数据格式")
        artifact = save_chart_artifact(chart_base64, req.title, req.chart_type)
        return {
            "chart_base64": chart_base64,
            "mime_type": "image/png",
            "html": f'<img src="data:image/png;base64,{chart_base64}" alt="{req.title}" />',
            **artifact,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/table")
async def generate_table(req: TableRequest):
    """生成学术表格"""
    try:
        if req.format == "latex":
            table = generate_latex_table(req.headers, req.rows, req.caption, req.label)
        else:
            table = generate_markdown_table(req.headers, req.rows, req.caption)
        return {"table": table, "format": req.format}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/nature-figure/workflow")
async def generate_nature_figure_workflow(req: NatureFigureRequest):
    """生成 Nature Figure 风格的 figure contract、panel map、绘图脚本和图注。"""
    try:
        return build_nature_figure_workflow(
            topic=req.topic,
            conclusion=req.conclusion,
            evidence_items=req.evidence_items,
            backend=req.backend,
            journal=req.journal,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/nature-figure/render")
async def render_nature_figure(req: NatureFigureRequest):
    """生成可插入论文的 Nature Figure 草图和 PNG/SVG/PDF 文件。"""
    try:
        return render_nature_figure_assets(
            topic=req.topic,
            conclusion=req.conclusion,
            evidence_items=req.evidence_items,
            backend=req.backend,
            journal=req.journal,
            source_data_csv=req.source_data_csv,
            source_data_file_base64=req.source_data_file_base64,
            source_data_filename=req.source_data_filename,
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail={
            "message": str(e),
            "repair_hint": "请先点击“载入源数据模板”，把 USER_DATA_REQUIRED 替换为真实实验数据；至少保留 panel、metric、n、value、uncertainty 五列。",
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
