"""Manuscript persistence API for the Web writing workspace."""
from __future__ import annotations

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field
from typing import Optional

from services.manuscript_service import (
    ManuscriptConflictError,
    ManuscriptNotFoundError,
    archive_manuscript,
    create_manuscript,
    create_manuscript_version,
    get_manuscript,
    list_manuscript_versions,
    list_manuscripts,
    restore_manuscript_version,
    update_manuscript,
)

router = APIRouter(prefix="/api/manuscripts", tags=["网页论文"])


def active_workspace(x_scholar_workspace: str = Header("default", alias="X-Scholar-Workspace")) -> str:
    return x_scholar_workspace or "default"


class ManuscriptCreateRequest(BaseModel):
    title: str = "未命名论文"
    content: str = ""
    template_id: str = "master"
    paper_format_id: str = "degree"
    citation_format: str = "gbt7714"
    profile: dict = Field(default_factory=dict)
    status: str = "draft"


class ManuscriptUpdateRequest(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    template_id: Optional[str] = None
    paper_format_id: Optional[str] = None
    citation_format: Optional[str] = None
    profile: Optional[dict] = None
    status: Optional[str] = None
    expected_revision: int = Field(ge=1)


class ManuscriptVersionRequest(BaseModel):
    label: str = "手动保存"
    content: Optional[str] = None


class ManuscriptRestoreRequest(BaseModel):
    expected_revision: int = Field(ge=1)


def _service_error(exc: ValueError) -> HTTPException:
    if isinstance(exc, ManuscriptConflictError):
        return HTTPException(status_code=409, detail=str(exc))
    return HTTPException(status_code=404, detail=str(exc))


@router.post("")
async def create_manuscript_route(
    req: ManuscriptCreateRequest,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    return create_manuscript(req.model_dump(), active_workspace(workspace_id))


@router.get("")
async def list_manuscripts_route(
    include_archived: bool = False,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    return list_manuscripts(active_workspace(workspace_id), include_archived)


@router.get("/{manuscript_id}")
async def get_manuscript_route(
    manuscript_id: str,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    try:
        return get_manuscript(manuscript_id, active_workspace(workspace_id))
    except ValueError as exc:
        raise _service_error(exc) from exc


@router.put("/{manuscript_id}")
async def update_manuscript_route(
    manuscript_id: str,
    req: ManuscriptUpdateRequest,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    try:
        return update_manuscript(
            manuscript_id,
            req.model_dump(exclude_none=True),
            active_workspace(workspace_id),
        )
    except ValueError as exc:
        raise _service_error(exc) from exc


@router.delete("/{manuscript_id}")
async def archive_manuscript_route(
    manuscript_id: str,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    try:
        return archive_manuscript(manuscript_id, active_workspace(workspace_id))
    except ValueError as exc:
        raise _service_error(exc) from exc


@router.post("/{manuscript_id}/versions")
async def create_manuscript_version_route(
    manuscript_id: str,
    req: ManuscriptVersionRequest,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    try:
        return create_manuscript_version(
            manuscript_id,
            req.label,
            req.content,
            active_workspace(workspace_id),
        )
    except ValueError as exc:
        raise _service_error(exc) from exc


@router.get("/{manuscript_id}/versions")
async def list_manuscript_versions_route(
    manuscript_id: str,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    try:
        return list_manuscript_versions(manuscript_id, active_workspace(workspace_id))
    except ValueError as exc:
        raise _service_error(exc) from exc


@router.post("/{manuscript_id}/versions/{version_id}/restore")
async def restore_manuscript_version_route(
    manuscript_id: str,
    version_id: int,
    req: ManuscriptRestoreRequest,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    try:
        return restore_manuscript_version(
            manuscript_id,
            version_id,
            req.expected_revision,
            active_workspace(workspace_id),
        )
    except ValueError as exc:
        raise _service_error(exc) from exc
