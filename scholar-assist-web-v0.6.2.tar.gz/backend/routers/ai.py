"""AI 分析 API 路由 — Feature 3+10"""
from __future__ import annotations
import re
from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from services.ai_service import (
    summarize_paper, summarize_multiple_papers,
    generate_project_knowledge_brief,
    extract_key_info, call_ai, call_ai_with_custom_config,
)

router = APIRouter(prefix="/api/ai", tags=["AI 分析"])


class SummarizeRequest(BaseModel):
    paper: dict
    user_context: str = ""


class MultiSummarizeRequest(BaseModel):
    papers: list[dict]
    user_topic: str = ""


class KnowledgeBriefRequest(BaseModel):
    papers: list[dict]
    user_topic: str = ""


class ChatRequest(BaseModel):
    messages: list[dict]
    system_prompt: str = ""
    provider: str = ""


class KeyInfoRequest(BaseModel):
    paper: dict


# Feature 10: 用户自定义 API 配置
class CustomAPIConfig(BaseModel):
    provider: str = "deepseek"  # "deepseek" | "openai" | "claude" | "custom"
    api_key: str = ""
    base_url: str = ""
    model: str = ""


class CustomChatRequest(BaseModel):
    messages: list[dict]
    system_prompt: str = ""
    config: CustomAPIConfig


def is_successful_ai_probe(result: str) -> bool:
    """Return False for normalized provider errors from the AI service."""
    normalized = result.strip().lower()
    if not normalized:
        return False
    if normalized.startswith("[") and any(marker in normalized for marker in ["错误", "error", "异常"]):
        return False
    return "ok" in normalized or not normalized.startswith("[")


def clean_manuscript_ai_output(text: str) -> str:
    """Remove chatty wrappers while preserving manuscript content."""
    cleaned = (text or "").strip()
    cleaned = re.sub(r"^(当然|好的|以下是|下面是)[，,:：\s]*(一[段篇份个])?(可用的|修改后的|生成的)?[^\n]{0,24}\n+", "", cleaned)
    cleaned = re.sub(r"\n+(希望以上内容.*|如需.*我可以继续.*|如果你需要.*)$", "", cleaned)
    return cleaned.strip()


def inspect_ai_writing_tells(text: str) -> list[dict]:
    """Return explainable writing-pattern warnings instead of a fake AI score."""
    value = text or ""
    checks = [
        ("聊天式开场", r"^(当然|好的|以下是|下面是|我来|让我们|接下来)", "删除对话式开头，直接进入论文内容。"),
        ("夸张或模板词", r"重要意义|显著提升|广阔前景|突破性|关键作用|深远影响|具有重要价值", "换成具体对象、指标、证据或适用范围。"),
        ("破折号", r"[—–]", "改成逗号、句号、冒号或重新拆句。"),
        ("三段式套话", r"首先|其次|最后|综上所述|总而言之", "保留真实逻辑，不要机械列点。"),
        ("泛化结尾", r"未来.*进一步|具有.*应用前景|为.*提供.*参考", "用可验证的局限、下一步实验或数据需求收尾。"),
    ]
    findings = []
    for label, pattern, hint in checks:
        matches = re.findall(pattern, value, re.I)
        if matches:
            findings.append({"label": label, "count": len(matches), "hint": hint})
    return findings


def build_humanize_instruction(text: str) -> str:
    """Build an editing instruction that reduces AI-like prose without changing evidence."""
    tells = inspect_ai_writing_tells(text)
    tell_lines = "\n".join(f"- {item['label']}：{item['hint']}" for item in tells) or "- 未发现明显模板痕迹，仍需检查语气是否具体。"
    return (
        "请把以下论文草稿改写得更像研究者手写草稿，而不是 AI 模板文。\n"
        "硬性要求：\n"
        "1. 保留公式、数据、引用标记和术语，不编造任何实验、样本量、结果或文献。\n"
        "2. 删除聊天式开场、客套话和总结式套话。\n"
        "3. 把夸张形容词改成具体证据、指标、边界条件或作者需要补充的信息。\n"
        "4. 避免整齐的三段式节奏，句长要自然变化。\n"
        "5. 不要输出解释，只输出改写后的正文。\n\n"
        f"已检测到的风险：\n{tell_lines}\n\n"
        f"原文：\n{text}"
    )


# ═══════════════════════════════════════════
# P0: AI 写作 API (生成段落/润色/扩写/翻译/引用格式)
# ═══════════════════════════════════════════

class WritingRequest(BaseModel):
    action: str  # "polish" | "expand" | "translate" | "summarize" | "abstract" | "outline" | "paragraph"
    text: str = ""
    context: str = ""  # 论文主题/上下文
    config: Optional[CustomAPIConfig] = None


@router.post("/writing")
async def ai_writing(req: WritingRequest):
    """AI 写作助手 — 支持润色、扩写、翻译、生成摘要、生成大纲、生成段落"""
    action_prompts = {
        "polish": "请润色以下学术段落。要求：保留原意、变量、公式、数据和引用；减少套话；用具体、克制、可写入论文正文的表达；不要输出解释：",
        "expand": "请扩写以下内容。要求：只补充与研究问题、方法细节、实验条件、指标解释或局限边界相关的内容；不得用空泛背景话填充篇幅；不要编造数据：",
        "translate": "请将以下中文翻译为学术英文。要求：保留术语、公式、引用和不确定性；避免宣传式形容词；不要输出解释：",
        "summarize": "请用 2-3 句话总结以下段落的核心观点：",
        "abstract": "根据以下论文内容，生成一个结构化的学术摘要（200-300字）：",
        "outline": "根据以下研究主题，生成一份详细的论文章节大纲：",
        "paragraph": "根据以下主题或大纲，撰写一段可直接放入论文的正文。要求：先写具体问题和对象，再写方法或证据；避免“近年来/随着/具有重要意义/取得突破性进展”等模板句；缺少事实时用 [AUTHOR_INPUT_NEEDED: ...] 标注：",
        "humanize": build_humanize_instruction(req.text),
        "nature_polish": """请把以下稿件片段润色成更接近 Nature / Nature Communications 风格的学术英文。
要求：
1. 保留事实、数据、引用意图和作者原意，不编造实验、机制或统计结果。
2. 优先修复论证顺序、claim-evidence-boundary 关系和段落推进。
3. 降低空泛形容词，使用证据加权表达，避免过度声称。
4. 输出分为「Polished version」和「Main changes」两部分。""",
        "nature_abstract": """请基于以下稿件/笔记生成 Nature 风格摘要。
结构必须覆盖：研究背景、关键缺口、本文方法、核心结果、意义、边界或限制。
要求：
1. 不编造任何数据、机制、样本量、统计显著性或创新点。
2. 如果关键信息缺失，用 [AUTHOR_INPUT_NEEDED: ...] 标注。
3. 摘要应适合跨学科读者理解，避免术语堆砌。
4. 输出 1 个中文版本和 1 个英文版本。""",
        "nature_intro": """请把以下研究主题/草稿重构为 Nature 风格引言逻辑。
请按漏斗式论证输出：
1. Field scale：该问题为什么重要。
2. Bottleneck：当前领域的核心瓶颈。
3. Prior attempts：已有路线解决了什么。
4. Unresolved gap：仍然缺什么证据或能力。
5. Present study：本文要证明什么。
6. 可直接写入论文的引言段落草稿。
要求证据优先，不要编造引用、数据或历史。""",
        "nature_results": """请把以下实验/结果笔记整理为 Nature 风格 Results 叙事。
要求：
1. 构建 evidence ladder，而不是按实验发生顺序罗列。
2. 每个主要结论都对应比较、消融、指标、可视化或压力测试证据。
3. 标注哪些 claim 缺少支撑证据。
4. 输出「结果叙事骨架」「可写入论文的 Results 段落」「缺失证据清单」。""",
        "nature_discussion": """请基于以下稿件/结果写 Nature 风格 Discussion。
要求：
1. 解释结果意味着什么，而不是重复 Results。
2. 说明与已有工作的关系、适用边界、限制和未来工作。
3. 控制过度声称，明确哪些结论只在当前证据范围内成立。
4. 输出可直接写入论文的讨论段落，并列出需要作者补充的信息。""",
        "nature_reviewer": """请模拟 Nature 风格预审/审稿自检，但不要假装真实审稿人。
请从以下维度评估：原创性、科学重要性、跨学科读者兴趣、技术可靠性、可读性、证据缺口。
输出：
1. Editor-facing summary
2. Major risks before submission
3. Reviewer 1 emphasis
4. Reviewer 2 emphasis
5. Reviewer 3 emphasis
6. 必须补强的实验/引用/表述
要求：只依据用户提供材料，不编造隐藏知识。""",
        "nature_figure_plan": """请基于以下研究内容设计 Nature 风格主图/结果图方案。
要求：
1. 先写核心科学结论。
2. 给出 Figure 1-4 的 panel map，每个 panel 说明承载什么证据。
3. 标明需要的数据、统计检验、图形类型和导出建议。
4. 不生成虚假数据，不假设用户已有未提供的实验。""",
    }

    prompt = action_prompts.get(req.action, action_prompts["polish"])
    content = f"{prompt}\n\n" if req.action != "humanize" else ""
    if req.context and req.action != "humanize":
        content += f"论文主题/上下文: {req.context}\n\n"
    content += req.text if req.action != "humanize" else prompt

    nature_actions = {
        "nature_polish", "nature_abstract", "nature_intro", "nature_results",
        "nature_discussion", "nature_reviewer", "nature_figure_plan",
    }
    system_prompt = (
        "你是 Nature 风格科研写作助手，擅长把作者提供的事实、结果和草稿组织成高影响力论文论证。"
        "必须证据优先，保留不确定性，不得编造数据、机制、样本量、统计显著性、引用或结论。"
        if req.action in nature_actions else
        "你是资深论文写作编辑。输出必须像研究者草稿：具体、克制、可追溯、少形容词。"
        "禁止使用聊天式开场、营销式夸张、空泛价值判断和模板句；不要编造任何数据、实验、引用、样本量或结论。"
        "保留 Markdown 标题、表格、引用标记和 LaTeX 公式。不要使用破折号、emoji 或机械加粗。"
    )
    max_tokens = 3600 if req.action in nature_actions else 2000

    try:
        if req.config and req.config.api_key:
            result = await call_ai_with_custom_config(
                messages=[{"role": "user", "content": content}],
                system_prompt=system_prompt,
                provider=req.config.provider, api_key=req.config.api_key,
                base_url=req.config.base_url, model=req.config.model,
                max_tokens=max_tokens,
                temperature=0.18,
            )
        else:
            result = await call_ai(
                messages=[{"role": "user", "content": content}],
                system_prompt=system_prompt,
                max_tokens=max_tokens,
                temperature=0.18,
            )
        return {"result": clean_manuscript_ai_output(result), "action": req.action}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ═══════════════════════════════════════════
# P2: 引用格式生成
# ═══════════════════════════════════════════

class CitationFormatRequest(BaseModel):
    papers: list[dict]
    format: str = "gbt7714"  # "gbt7714" | "apa" | "ieee" | "bibtex"


@router.post("/citations/format")
async def format_citations(req: CitationFormatRequest):
    """根据论文信息生成指定格式的参考文献列表"""
    try:
        papers_text = ""
        for i, p in enumerate(req.papers):
            papers_text += f"""{i+1}. 标题: {p.get('title', '')}
   作者: {p.get('authors', '')}
   年份: {p.get('year', '')}
   期刊/来源: {p.get('source', '')}
   DOI: {p.get('doi', '')}\n\n"""

        if req.format == "gbt7714":
            prompt = f"请将以下论文信息转换为 GB/T 7714-2015 格式的参考文献列表：\n\n{papers_text}"
        elif req.format == "bibtex":
            prompt = f"请将以下论文信息转换为 BibTeX 格式：\n\n{papers_text}"
        else:
            prompt = f"请将以下论文信息转换为 {req.format.upper()} 格式的参考文献列表：\n\n{papers_text}"

        result = await call_ai(
            messages=[{"role": "user", "content": prompt}],
            system_prompt="你是参考文献格式化专家。请只返回格式化后的参考文献，不要加额外解释。",
            temperature=0.1,
        )
        return {"citations": result, "format": req.format}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/summarize")
async def summarize_single(req: SummarizeRequest):
    """总结单篇文献"""
    try:
        result = await summarize_paper(req.paper, req.user_context)
        return {"summary": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/summarize-multiple")
async def summarize_multi(req: MultiSummarizeRequest):
    """总结多篇文献，生成综述"""
    try:
        result = await summarize_multiple_papers(req.papers, req.user_topic)
        return {"summary": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/knowledge-brief")
async def project_knowledge_brief(req: KnowledgeBriefRequest):
    """基于选中文献生成项目知识库精读报告。"""
    try:
        result = await generate_project_knowledge_brief(req.papers, req.user_topic)
        return {"brief": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/key-info")
async def get_key_info(req: KeyInfoRequest):
    """提取文献关键信息"""
    try:
        result = await extract_key_info(req.paper)
        return {"key_info": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/chat")
async def chat_with_ai(req: ChatRequest):
    """通用 AI 对话（使用系统配置的 API Key）"""
    try:
        result = await call_ai(
            req.messages,
            system_prompt=req.system_prompt,
            provider=req.provider,
        )
        return {"reply": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Feature 10: 用户自定义 API
@router.post("/chat/custom")
async def chat_with_custom_api(req: CustomChatRequest):
    """
    使用用户自定义 API 配置进行对话

    支持 DeepSeek、ChatGPT/OpenAI、Claude 和 OpenAI 兼容的自定义接口。
    用户在前端设置面板中填入自己的 API Key、Base URL 和 Model，
    后端将使用这些配置调用对应的 LLM。
    """
    try:
        result = await call_ai_with_custom_config(
            messages=req.messages,
            system_prompt=req.system_prompt,
            provider=req.config.provider,
            api_key=req.config.api_key,
            base_url=req.config.base_url,
            model=req.config.model,
        )
        return {"reply": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/verify-key")
async def verify_api_key(config: CustomAPIConfig):
    """验证用户 API Key 是否有效（发送最小请求）"""
    try:
        result = await call_ai_with_custom_config(
            messages=[{"role": "user", "content": "回复 OK"}],
            system_prompt="你只回复 OK 两个字。",
            provider=config.provider,
            api_key=config.api_key,
            base_url=config.base_url,
            model=config.model,
            max_tokens=10,
        )
        is_valid = is_successful_ai_probe(result)
        return {
            "valid": is_valid,
            "message": "API 连接正常" if is_valid else result,
        }
    except Exception as e:
        return {"valid": False, "message": str(e)}
