"""Zotero integration API routes."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from services.zotero_service import detect_zotero_citekey_conflicts, fetch_zotero_items, normalize_zotero_items

router = APIRouter(prefix="/api/zotero", tags=["Zotero"])


class ZoteroSyncRequest(BaseModel):
    library_id: str
    api_key: str = ""
    library_type: str = "user"
    collection_key: str = ""
    limit: int = 50
    include_children: bool = True
    since_version: int = 0


class ZoteroNormalizeRequest(BaseModel):
    items: list[dict]


@router.post("/sync")
async def zotero_sync(req: ZoteroSyncRequest):
    """Sync Zotero metadata through the official Zotero Web API."""
    if req.library_type not in {"user", "group"}:
        raise HTTPException(status_code=400, detail="library_type 仅支持 user 或 group")
    try:
        return fetch_zotero_items(
            library_id=req.library_id,
            api_key=req.api_key,
            library_type=req.library_type,  # type: ignore[arg-type]
            collection_key=req.collection_key,
            limit=req.limit,
            include_children=req.include_children,
            since_version=req.since_version,
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Zotero 同步失败: {exc}") from exc


@router.post("/normalize")
async def zotero_normalize(req: ZoteroNormalizeRequest):
    """Normalize exported Zotero Web API items without calling the network."""
    papers = normalize_zotero_items(req.items)
    return {
        "source": "Zotero",
        "count": len(req.items),
        "papers": papers,
        "citekey_report": detect_zotero_citekey_conflicts(papers),
    }
