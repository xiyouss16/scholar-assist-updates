"""Publication workflow API routes."""
from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from services.publication_service import (
    build_evidence_bound_chapter_contract,
    build_answer_with_citations_prompt,
    build_literature_answer_prompt,
    build_literature_matrix,
    build_pandoc_metadata_block,
    build_pdf_evidence_cards,
    detect_publication_tools,
    enhance_cross_references,
    inspect_export_preflight,
    inspect_manuscript_quality,
    list_template_packs,
)
from services.evidence_service import (
    build_evidence_index,
    build_traceable_knowledge_answer,
    load_persisted_evidence_index,
    persist_evidence_index,
    search_evidence_cards,
    search_persisted_evidence_cards,
)

router = APIRouter(prefix="/api/publication", tags=["出版工作流"])


class ManuscriptMarkdownRequest(BaseModel):
    markdown: str


class PandocMetadataRequest(BaseModel):
    title: str = "Scholar Assist Manuscript"
    bibliography: str = "references.bib"
    csl: str = "gb-t-7714-2015-numeric.csl"


class KnowledgeAnswerPromptRequest(BaseModel):
    question: str
    papers: list[dict]
    limit: int = 10


class EvidenceCardsRequest(BaseModel):
    paper: dict
    question: str = ""
    limit: int = 6


class LiteratureMatrixRequest(BaseModel):
    papers: list[dict]


class EvidenceChapterRequest(BaseModel):
    section_title: str
    current_text: str = ""
    papers: list[dict] = []


class ExportPreflightRequest(BaseModel):
    markdown: str
    papers: list[dict] = []


class EvidenceSearchRequest(BaseModel):
    question: str
    papers: list[dict] = []
    project_id: Optional[str] = None
    limit: int = 10
    candidate_limit: int = 40
    semantic_weight: float = 0.65
    diversity: float = 0.25


class EvidenceIndexPersistRequest(BaseModel):
    project_id: str = "default"
    papers: list[dict]
    embedding_vectors: Optional[list[list[float]]] = None


class EvidenceIndexLoadRequest(BaseModel):
    project_id: str = "default"


@router.get("/tools")
async def publication_tools():
    return {"tools": detect_publication_tools()}


@router.post("/metadata-block")
async def pandoc_metadata_block(req: PandocMetadataRequest):
    return {"metadata": build_pandoc_metadata_block(req.title, req.bibliography, req.csl)}


@router.post("/cross-references")
async def cross_references(req: ManuscriptMarkdownRequest):
    return enhance_cross_references(req.markdown)


@router.post("/quality")
async def manuscript_quality(req: ManuscriptMarkdownRequest):
    return {"checks": inspect_manuscript_quality(req.markdown)}


@router.post("/preflight")
async def export_preflight(req: ExportPreflightRequest):
    return {"checks": inspect_export_preflight(req.markdown, req.papers)}


@router.post("/knowledge-prompt")
async def knowledge_prompt(req: KnowledgeAnswerPromptRequest):
    return {"prompt": build_literature_answer_prompt(req.question, req.papers)}


@router.post("/answer-with-citations-prompt")
async def answer_with_citations_prompt(req: KnowledgeAnswerPromptRequest):
    return build_answer_with_citations_prompt(req.question, req.papers, req.limit)


@router.post("/knowledge-answer")
async def traceable_knowledge_answer(req: KnowledgeAnswerPromptRequest):
    return build_traceable_knowledge_answer(req.question, req.papers, req.limit)


@router.post("/evidence-search")
async def evidence_search(req: EvidenceSearchRequest):
    if req.project_id:
        evidence, stats = search_persisted_evidence_cards(
            req.question,
            req.project_id,
            limit=req.limit,
            candidate_limit=req.candidate_limit,
            semantic_weight=req.semantic_weight,
            diversity=req.diversity,
        )
        return {"evidence": evidence, "index_stats": stats}
    return {
        "evidence": search_evidence_cards(
            req.question,
            req.papers,
            limit=req.limit,
            candidate_limit=req.candidate_limit,
            semantic_weight=req.semantic_weight,
            diversity=req.diversity,
        ),
        "index_stats": build_evidence_index(req.papers)["stats"],
    }


@router.post("/evidence-index/persist")
async def evidence_index_persist(req: EvidenceIndexPersistRequest):
    return {"index": persist_evidence_index(req.project_id, req.papers, embedding_vectors=req.embedding_vectors)}


@router.post("/evidence-index/load")
async def evidence_index_load(req: EvidenceIndexLoadRequest):
    index = load_persisted_evidence_index(req.project_id)
    return {"index": {**index, "chunks": [{key: value for key, value in chunk.items() if key != "vector"} for chunk in index.get("chunks", [])]}}


@router.post("/pdf-evidence")
async def pdf_evidence(req: EvidenceCardsRequest):
    return {"cards": build_pdf_evidence_cards(req.paper, req.question, req.limit)}


@router.post("/literature-matrix")
async def literature_matrix(req: LiteratureMatrixRequest):
    return build_literature_matrix(req.papers)


@router.post("/evidence-chapter-prompt")
async def evidence_chapter_prompt(req: EvidenceChapterRequest):
    return build_evidence_bound_chapter_contract(req.section_title, req.current_text, req.papers)


@router.get("/templates")
async def template_packs():
    return {"templates": list_template_packs()}
