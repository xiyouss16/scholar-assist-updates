"""Project library HTTP API for browser deployments."""
from __future__ import annotations

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from services.library_service import (
    add_papers_to_library,
    build_workspace_backup,
    build_library_cleaning_report,
    create_library,
    create_workspace,
    delete_library,
    delete_workspace,
    export_workspace,
    get_all_papers,
    get_papers_in_library,
    list_libraries,
    list_workspaces,
    remove_paper_from_library,
    save_paper,
    save_papers_batch,
    search_papers_fulltext,
)

router = APIRouter(prefix="/api/library", tags=["网页项目库"])


class LibraryCreateRequest(BaseModel):
    name: str
    description: str = ""


class WorkspaceCreateRequest(BaseModel):
    name: str
    description: str = ""


class PaperSaveRequest(BaseModel):
    paper: dict


class PapersBatchRequest(BaseModel):
    papers: list[dict]


class LibraryPapersRequest(BaseModel):
    paper_ids: list[str]


def active_workspace(x_scholar_workspace: str = Header("default", alias="X-Scholar-Workspace")) -> str:
    return x_scholar_workspace or "default"


@router.post("/workspaces")
async def create_workspace_route(req: WorkspaceCreateRequest):
    return create_workspace(req.name, req.description)


@router.get("/workspaces")
async def list_workspaces_route():
    return list_workspaces()


@router.delete("/workspaces/{workspace_id}")
async def delete_workspace_route(workspace_id: str):
    try:
        delete_workspace(workspace_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"status": "ok"}


@router.get("/workspaces/{workspace_id}/export")
async def export_workspace_route(workspace_id: str):
    return export_workspace(workspace_id)


@router.get("/workspaces/{workspace_id}/backup")
async def backup_workspace_route(workspace_id: str):
    return build_workspace_backup(workspace_id)


@router.post("/libraries")
async def create_library_route(req: LibraryCreateRequest, workspace_id: str = Header("default", alias="X-Scholar-Workspace")):
    return create_library(req.name, req.description, active_workspace(workspace_id))


@router.get("/libraries")
async def list_libraries_route(workspace_id: str = Header("default", alias="X-Scholar-Workspace")):
    return list_libraries(active_workspace(workspace_id))


@router.delete("/libraries/{library_id}")
async def delete_library_route(library_id: int, workspace_id: str = Header("default", alias="X-Scholar-Workspace")):
    delete_library(library_id, active_workspace(workspace_id))
    return {"status": "ok"}


@router.post("/papers")
async def save_paper_route(req: PaperSaveRequest, workspace_id: str = Header("default", alias="X-Scholar-Workspace")):
    save_paper(req.paper, active_workspace(workspace_id))
    return {"status": "ok"}


@router.post("/papers/batch")
async def save_papers_batch_route(req: PapersBatchRequest, workspace_id: str = Header("default", alias="X-Scholar-Workspace")):
    return {"count": save_papers_batch(req.papers, active_workspace(workspace_id))}


@router.get("/papers")
async def get_all_papers_route(workspace_id: str = Header("default", alias="X-Scholar-Workspace")):
    return get_all_papers(active_workspace(workspace_id))


@router.get("/papers/cleaning-report")
async def get_library_cleaning_report_route(workspace_id: str = Header("default", alias="X-Scholar-Workspace")):
    return build_library_cleaning_report(active_workspace(workspace_id))


@router.get("/search")
async def search_papers_route(q: str, workspace_id: str = Header("default", alias="X-Scholar-Workspace")):
    return search_papers_fulltext(q, active_workspace(workspace_id))


@router.post("/libraries/{library_id}/papers")
async def add_papers_to_library_route(
    library_id: int,
    req: LibraryPapersRequest,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    return {"count": add_papers_to_library(library_id, req.paper_ids, active_workspace(workspace_id))}


@router.get("/libraries/{library_id}/papers")
async def get_papers_in_library_route(library_id: int, workspace_id: str = Header("default", alias="X-Scholar-Workspace")):
    return get_papers_in_library(library_id, active_workspace(workspace_id))


@router.delete("/libraries/{library_id}/papers/{paper_id}")
async def remove_paper_from_library_route(
    library_id: int,
    paper_id: str,
    workspace_id: str = Header("default", alias="X-Scholar-Workspace"),
):
    remove_paper_from_library(library_id, paper_id, active_workspace(workspace_id))
    return {"status": "ok"}
