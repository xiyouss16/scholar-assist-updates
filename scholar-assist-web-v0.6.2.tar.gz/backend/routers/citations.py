"""Citation verification and export API routes."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from services.citation_service import (
    format_bibtex,
    format_csl_json,
    format_ris,
    inspect_citation_closure,
    lookup_literature_identifier,
    verify_references,
)

router = APIRouter(prefix="/api/citations", tags=["引用校验"])


class CitationVerifyRequest(BaseModel):
    references: list[dict]


class CitationExportRequest(BaseModel):
    papers: list[dict]
    format: str = "bibtex"


class CitationLookupRequest(BaseModel):
    query: str


class CitationClosureRequest(BaseModel):
    markdown: str
    papers: list[dict] = []


@router.post("/verify")
async def verify_citations(req: CitationVerifyRequest):
    """Verify references against public scholarly metadata sources."""
    try:
        results = await verify_references(req.references)
        return {"results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/export")
async def export_citations(req: CitationExportRequest):
    """Export papers as BibTeX, RIS or CSL-JSON."""
    fmt = req.format.lower()
    if fmt not in {"bibtex", "ris", "csl-json"}:
        raise HTTPException(status_code=400, detail="format 仅支持 bibtex、ris 或 csl-json")
    if fmt == "bibtex":
        content = format_bibtex(req.papers)
    elif fmt == "ris":
        content = format_ris(req.papers)
    else:
        content = format_csl_json(req.papers)
    return {"format": fmt, "content": content}


@router.post("/lookup")
async def lookup_citation(req: CitationLookupRequest):
    """Lookup one paper by DOI, PMID, arXiv id or title and return normalized metadata."""
    query = req.query.strip()
    if not query:
        raise HTTPException(status_code=400, detail="query 不能为空")
    paper = lookup_literature_identifier(query)
    if not paper:
        raise HTTPException(status_code=404, detail="未找到匹配文献")
    return {"paper": paper}


@router.post("/closure")
async def citation_closure(req: CitationClosureRequest):
    """Inspect whether manuscript citation keys are closed by project-library metadata."""
    return {"report": inspect_citation_closure(req.markdown, req.papers)}
