"""Web deployment security helpers for Scholar Assist."""
import hmac
import os
import time
from collections import defaultdict, deque
from typing import Deque, Dict, List, Optional

from fastapi import Request
from starlette.responses import JSONResponse, Response


PUBLIC_API_PATHS = {"/api/health"}
_RATE_BUCKETS: Dict[str, Deque[float]] = defaultdict(deque)


def _split_csv(value: str) -> List[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def get_cors_origins() -> List[str]:
    """Return configured CORS origins, keeping local development friction low."""
    raw = os.environ.get("SCHOLAR_ASSIST_CORS_ORIGINS", "").strip()
    if raw:
        return _split_csv(raw)
    return ["*"]


def get_access_code() -> str:
    return os.environ.get("SCHOLAR_ASSIST_ACCESS_CODE", "").strip()


def get_rate_limit_per_minute() -> int:
    raw = os.environ.get("SCHOLAR_ASSIST_RATE_LIMIT_PER_MINUTE", "").strip()
    if not raw:
        return 0
    try:
        return max(0, int(raw))
    except ValueError:
        return 0


def security_status() -> dict:
    origins = get_cors_origins()
    return {
        "access_code_required": bool(get_access_code()),
        "rate_limit_per_minute": get_rate_limit_per_minute(),
        "cors_origins": origins,
        "public_paths": sorted(PUBLIC_API_PATHS),
    }


def extract_access_code(request: Request) -> str:
    header_code = request.headers.get("x-scholar-access-code", "").strip()
    if header_code:
        return header_code
    authorization = request.headers.get("authorization", "").strip()
    if authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return ""


def _client_key(request: Request) -> str:
    host = request.client.host if request.client else "unknown"
    workspace = request.headers.get("x-scholar-workspace", "default")
    return f"{host}:{workspace}:{request.url.path}"


def _rate_limit_response(request: Request, limit: int, now: Optional[float] = None) -> Optional[Response]:
    if limit <= 0:
        return None
    timestamp = time.monotonic() if now is None else now
    bucket = _RATE_BUCKETS[_client_key(request)]
    while bucket and timestamp - bucket[0] >= 60:
        bucket.popleft()
    if len(bucket) >= limit:
        return JSONResponse(
            status_code=429,
            content={
                "detail": "请求过于频繁，请稍后再试。",
                "hint": "可通过 SCHOLAR_ASSIST_RATE_LIMIT_PER_MINUTE 调整 Web 部署限流。",
            },
            headers={"Retry-After": "60"},
        )
    bucket.append(timestamp)
    return None


async def scholar_assist_security_middleware(request: Request, call_next):
    path = request.url.path
    if not path.startswith("/api") or path in PUBLIC_API_PATHS:
        response = await call_next(request)
        return apply_security_headers(response)

    rate_limited = _rate_limit_response(request, get_rate_limit_per_minute())
    if rate_limited is not None:
        return rate_limited

    expected_code = get_access_code()
    if expected_code:
        supplied_code = extract_access_code(request)
        if not supplied_code or not hmac.compare_digest(supplied_code, expected_code):
            return JSONResponse(
                status_code=401,
                content={
                    "detail": "需要 Scholar Assist Web 访问码。",
                    "hint": "在首页设置中填写访问码，或使用 X-Scholar-Access-Code 请求头。",
                },
                headers={"WWW-Authenticate": "Bearer"},
            )

    response = await call_next(request)
    if expected_code:
        response.headers.setdefault("Cache-Control", "no-store")
    return apply_security_headers(response)


def apply_security_headers(response: Response) -> Response:
    """Apply browser-facing headers without requiring a particular reverse proxy."""
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; base-uri 'self'; frame-ancestors 'none'; "
        "script-src 'self'; style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; font-src 'self' data:; "
        "connect-src 'self' http://127.0.0.1:* http://localhost:* https:",
    )
    return response


def reset_rate_limit_for_tests() -> None:
    _RATE_BUCKETS.clear()
