"""Scholar Assist Backend — 配置文件"""
import os
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

# LLM API Keys
CLAUDE_API_KEY = os.getenv("CLAUDE_API_KEY", "")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
SCHOLAR_ASSIST_AI_PROVIDER = os.getenv("SCHOLAR_ASSIST_AI_PROVIDER", "").strip().lower()
SCHOLAR_ASSIST_AI_API_KEY = os.getenv("SCHOLAR_ASSIST_AI_API_KEY", "").strip()
SCHOLAR_ASSIST_AI_BASE_URL = os.getenv("SCHOLAR_ASSIST_AI_BASE_URL", "").strip().rstrip("/")
SCHOLAR_ASSIST_AI_MODEL = os.getenv("SCHOLAR_ASSIST_AI_MODEL", "").strip()

# LLM 模型配置
LLM_CONFIG = {
    "claude": {
        "model": "claude-sonnet-4-6",
        "api_key": CLAUDE_API_KEY,
        "base_url": "https://api.anthropic.com",
    },
    "deepseek": {
        "model": os.getenv("DEEPSEEK_MODEL", "deepseek-v4-flash"),
        "api_key": DEEPSEEK_API_KEY,
        "base_url": "https://api.deepseek.com",
    },
    "openai": {
        "model": "gpt-4o",
        "api_key": OPENAI_API_KEY,
        "base_url": "https://api.openai.com",
    },
}

# 默认 LLM
DEFAULT_LLM = SCHOLAR_ASSIST_AI_PROVIDER or os.getenv("DEFAULT_LLM", "deepseek")

if SCHOLAR_ASSIST_AI_PROVIDER and SCHOLAR_ASSIST_AI_API_KEY:
    provider = SCHOLAR_ASSIST_AI_PROVIDER
    base_config = LLM_CONFIG.get(provider, {
        "model": "",
        "api_key": "",
        "base_url": "",
    })
    LLM_CONFIG[provider] = {
        **base_config,
        "model": SCHOLAR_ASSIST_AI_MODEL or base_config.get("model", ""),
        "api_key": SCHOLAR_ASSIST_AI_API_KEY,
        "base_url": SCHOLAR_ASSIST_AI_BASE_URL or base_config.get("base_url", ""),
    }

# 学术搜索引擎配置
SEARCH_ENGINES = {
    "semantic_scholar": {
        "base_url": "https://api.semanticscholar.org/graph/v1",
        "rate_limit": 100,  # 每 5 分钟
    },
    "arxiv": {
        "base_url": "http://export.arxiv.org/api/query",
    },
    "crossref": {
        "base_url": "https://api.crossref.org/works",
    },
}

# 服务端口
BACKEND_PORT = int(os.getenv("BACKEND_PORT", "8765"))
