# Windows 网页版使用指南

这条路线不需要 Apple Developer ID，也不要求安装 Microsoft Word。Windows 用户可以用浏览器打开 Scholar Assist，用 WPS 或 LibreOffice 打开导出的 DOCX/PDF 做最终校对。

## 推荐方式一：Docker 一条命令

适合不想处理 Python 环境的用户。先安装 Docker Desktop，然后在项目根目录打开 PowerShell：

```powershell
$env:SCHOLAR_ASSIST_ACCESS_CODE="换成你的访问码"
docker compose up --build
```

浏览器打开：

```text
http://127.0.0.1:8765
```

如果只在自己电脑本地用，也可以不设置访问码；如果给实验室同学访问，建议设置 `SCHOLAR_ASSIST_ACCESS_CODE` 并在首页设置里的 Web 安全页签填写同一个值。

## 推荐方式二：本机开发启动

适合需要改代码或调试浏览器辅助搜索的用户。

```powershell
npm install
cd backend
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python main.py
```

另开一个 PowerShell：

```powershell
npm run web:start
```

浏览器打开：

```text
http://127.0.0.1:1420
```

后端默认地址是：

```text
http://127.0.0.1:8765
```

## 浏览器辅助搜索

Google Scholar、知网等网页辅助搜索需要浏览器自动化环境。Windows 上建议：

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
python -m playwright install chromium
```

遇到验证码时，人手动完成验证，软件再继续读取。为了减少封禁风险，仍建议控制搜索频率和页数。

## WPS / LibreOffice 定稿

Scholar Assist 负责论文写作、证据、引用、图表和导出。导出的 DOCX/PDF 可以用：

- WPS：适合没有 Word 的学生做最终校对、批注、学校模板微调。
- LibreOffice：适合开源环境打开 DOCX，格式复杂时建议最终再人工检查。

这不等同于 Word 插件。Word 插件只服务已安装 Microsoft Word 的用户；Windows 网页版主流程不依赖它。

## 常见问题

### 端口被占用

如果看到 1420 或 8765 被占用，先关闭旧终端，或换端口：

```powershell
$env:BACKEND_PORT="8766"
$env:FRONTEND_PORT="1421"
npm run web:start
```

### PowerShell 不允许激活 venv

执行：

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

然后重新运行：

```powershell
.\.venv\Scripts\Activate.ps1
```

### pip 安装慢

可以临时使用国内镜像：

```powershell
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### 后端未连接

首页提示后端未连接时，优先确认：

```powershell
curl http://127.0.0.1:8765/api/health
```

如果没有返回 JSON，重新启动后端或直接使用：

```powershell
npm run web:start
```

### Docker 里浏览器辅助不能用

默认 Docker 镜像是 slim 路线，不内置 Playwright 浏览器，避免镜像过大。要在服务器或 Docker 中跑浏览器辅助，应另做 browser worker 镜像，或在宿主机上运行浏览器辅助。
