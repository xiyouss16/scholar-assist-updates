# Scholar Assist 网页版部署说明

网页版把前端作为普通 React/Vite 应用运行，后端由 FastAPI 提供 `/api/*` 接口和静态页面托管。这样用户通过浏览器访问，不需要安装 `.app`，也不需要 Apple Developer ID、Developer ID 签名或 notarize 公证。

## 适用场景

- 想先给自己、同学或实验室成员试用，不想处理 macOS 安装拦截。
- 想部署到局域网、服务器、云主机或 Docker 环境。
- 想保留桌面版，同时增加一个免安装入口。

## 本地开发运行

跨平台一键启动推荐：

```bash
npm run web:start
```

它会检查 `BACKEND_PORT` 和 `FRONTEND_PORT` 是否被占用，并同时启动 FastAPI 后端和 Vite 前端。Windows 用户详见 [Windows 网页版使用指南](WINDOWS_WEB_GUIDE.md)。

启动后端：

```bash
cd scholar-assist/backend
python3 main.py
```

另开一个终端启动网页前端：

```bash
cd scholar-assist
npm run web:dev
```

浏览器打开：

```text
http://127.0.0.1:1420
```

默认前端会请求：

```text
http://127.0.0.1:8765/api
```

如果前后端分开部署，构建前设置 `VITE_BACKEND_URL`：

```bash
VITE_BACKEND_URL=https://your-api.example.com npm run web:build
```

## Docker 一条命令运行

```bash
cd scholar-assist
SCHOLAR_ASSIST_ACCESS_CODE="换成你的访问码" docker compose up --build
```

浏览器打开：

```text
http://127.0.0.1:8765
```

Docker 会把项目库数据库保存到 volume：

```text
scholar-assist-data:/data
```

Docker 健康检查会访问容器内 `http://127.0.0.1:8765/api/health`，只有后端和静态页面服务真正可访问时才会显示 healthy。

关键环境变量：

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `BACKEND_PORT` | `8765` | FastAPI 服务端口 |
| `SCHOLAR_ASSIST_STATIC_DIR` | `/app/dist` | React 构建产物目录 |
| `SCHOLAR_ASSIST_LIBRARY_DB` | `/data/scholar_assist_web.db` | 网页端项目库 SQLite 数据库 |
| `SCHOLAR_ASSIST_ACCESS_CODE` | 空 | 公网部署建议必填；前端在「设置 → Web 安全」填同一个访问码 |
| `SCHOLAR_ASSIST_RATE_LIMIT_PER_MINUTE` | `180` | 简单请求限流，防止公开试用被刷爆 |
| `SCHOLAR_ASSIST_CORS_ORIGINS` | `*` | 正式公网部署建议改成你的 HTTPS 域名 |
| `VITE_BACKEND_URL` | 空字符串 | 前端请求后端的基础地址；同源部署时留空 |
| `SCHOLAR_ASSIST_AI_PROVIDER` | 空 | 可选。后端默认 AI 服务商，例如 `deepseek`、`openai`、`claude`、`custom` |
| `SCHOLAR_ASSIST_AI_API_KEY` | 空 | 可选。推荐把长期密钥放后端环境变量，避免只存在浏览器 localStorage |
| `SCHOLAR_ASSIST_AI_BASE_URL` | 空 | 可选。自定义 OpenAI-compatible 网关地址 |
| `SCHOLAR_ASSIST_AI_MODEL` | 空 | 可选。后端默认模型名 |

AI 配置说明：前端设置里的 API Key 会保存到浏览器 localStorage，只建议本机临时调试。实验室内网或公网部署时，请优先使用 `SCHOLAR_ASSIST_AI_PROVIDER`、`SCHOLAR_ASSIST_AI_API_KEY`、`SCHOLAR_ASSIST_AI_BASE_URL`、`SCHOLAR_ASSIST_AI_MODEL`，也兼容旧变量 `DEEPSEEK_API_KEY`、`OPENAI_API_KEY`、`CLAUDE_API_KEY` 和 `DEFAULT_LLM`。

## 发布矩阵

Web 发布包会在 `latest-web.json` 里写入 macOS、Windows、Linux 和 Docker 的启动方式。用户拿到包后优先看这张矩阵，不需要猜该用 `.app`、Word 还是 Docker：

| 平台 | 推荐启动 | 定稿打开方式 | 说明 |
| --- | --- | --- | --- |
| macOS | `npm run web:start` | WPS 或 LibreOffice / 可选 Word | 不需要 Apple Developer ID；桌面 `.app` 才涉及签名和公证 |
| Windows | `npm run web:start` 或 Docker | WPS 或 LibreOffice / 可选 Word | 详见 [Windows 网页版使用指南](WINDOWS_WEB_GUIDE.md) |
| Linux | `npm run web:start` 或 Docker | LibreOffice | 适合服务器或实验室内网部署 |
| Docker | `docker compose up --build` | 浏览器下载 DOCX/PDF 后打开 | Compose 内置 Docker 健康检查和持久化 volume |

如果没有 Microsoft Word，导出的 DOCX/PDF 仍可用 WPS 或 LibreOffice 做导师批注、格式校对和最终提交。Word 插件只是增强项，不是网页写论文的硬依赖。

## 生成免安装 Web 发布包

没有 Apple Developer ID 时，优先发布 Web 包，不走 `.app` 安装链路：

```bash
npm run web:package -- \
  --base-url "https://your-download.example.com/releases" \
  --notes "Web 版更新说明"
```

脚本会先执行 `npm run web:build`，然后生成：

```text
release/web/scholar-assist-web-v<version>.tar.gz
release/web/latest-web.json
```

`latest-web.json` 包含版本、发布时间、压缩包 SHA-256、安装命令和 Web 安全环境变量。这个包可以上传到 GitHub Release、对象存储或服务器下载目录。它不需要 Apple Developer ID、Developer ID 签名或 notarize 公证。

如果已经构建过前端，只想重新打包：

```bash
npm run web:package -- --skip-build
```

## 当前网页端已支持

- 打开主界面，不依赖 Tauri 容器。
- 项目库 CRUD：新建项目库、保存论文、加入项目库、移除、全文搜索。
- 后端 API 继续复用已有搜索、AI、PDF、引用、导出、图表和 Word bridge 路由。
- FastAPI 可直接托管 `dist/index.html`，刷新页面不会 404。

## 和桌面版的差异

- 桌面版仍然通过 Tauri 命令访问本地 SQLite；网页版通过 `/api/library` 访问 FastAPI SQLite。
- 网页版不使用 macOS Keychain。AI 密钥应优先走后端环境变量或后续的服务端加密配置，不建议把长期密钥硬编码进前端。
- 公网部署时请设置 `SCHOLAR_ASSIST_ACCESS_CODE`，并在首页「设置 → Web 安全」填写同一个访问码；本地开发不设置时不会增加使用门槛。
- `SCHOLAR_ASSIST_RATE_LIMIT_PER_MINUTE` 是轻量限流，不是账号系统。正式商业化仍需要登录、权限、审计和更强的队列隔离。
- 浏览器辅助 Google Scholar、知网等需要真实浏览器自动化环境。Docker 镜像默认不安装 Playwright 浏览器，避免镜像过大；如果要在服务器端跑浏览器辅助，需要额外安装浏览器运行时，或把这部分拆成单独 worker。
- 网页版不需要 Apple Developer ID，但如果公开联网部署，后续应增加登录、权限、HTTPS、速率限制和服务端密钥管理。

## 推荐部署路线

1. 个人试用：`npm run web:dev` + `python3 backend/main.py`。
2. 实验室内网：`docker compose up --build`，通过局域网 IP 访问 `8765`。
3. 公开试用：前端和后端同源部署，开启 HTTPS，设置 `SCHOLAR_ASSIST_ACCESS_CODE`、限流和数据库路径。
4. 正式商业化：增加账号系统、项目隔离、任务队列、对象存储、日志审计和限流。

## 常见问题

### 网页版是不是替代桌面版？

不是。它是免安装入口。桌面版适合本机文件、系统级能力和离线使用；网页版适合快速试用、团队访问和规避 macOS 签名安装问题。

### 为什么网页版本不会出现“已损坏，无法打开”？

这个提示来自 macOS Gatekeeper 对未签名 `.app` 的拦截。网页版通过浏览器访问，不分发 macOS 应用包，所以不会触发 Apple Developer ID、公证或 Gatekeeper 安装校验。

### 项目库数据会不会丢？

本地开发默认写入 `~/.scholar-assist/scholar_assist_web.db`。Docker 默认写入 `/data/scholar_assist_web.db`，并通过 volume 持久化。迁移时备份这个 SQLite 文件即可。

### 为什么有些桌面功能在网页里还要服务化？

网页不能直接访问本机文件系统、Keychain、Tauri command 或已安装应用。涉及本机能力的功能需要变成后端 API、浏览器扩展、Word 插件或独立 worker。
