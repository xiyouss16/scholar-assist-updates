# Scholar Assist 第一次使用指南

Scholar Assist 当前优先用网页版。它不要求 Apple Developer ID，也不要求安装 Word；写完后可导出 DOCX/PDF，并用 WPS 或 LibreOffice 做最终校对。

## 1. 启动

在项目根目录运行：

```bash
npm install
cd backend && pip install -r requirements.txt && cd ..
npm run web:start
```

浏览器打开终端提示的地址，通常是 `http://127.0.0.1:1420`。后端默认运行在 `http://127.0.0.1:8765`。

如果首页显示“后端未连接”，先点击“重试连接”。如果显示“后端需要重启”，说明前端与旧 Python 进程版本不一致：先在旧终端按 `Ctrl+C`，再运行 `npm run web:start`。仍失败时检查 8765 端口，或分别启动：

```bash
# 终端 1
cd backend && python3 main.py

# 终端 2
npm run web:dev
```

Windows 用户见 [Windows 网页版使用指南](WINDOWS_WEB_GUIDE.md)。

## 2. 配置 AI 和访问码

首页右上角打开“设置”：

1. 在“AI 配置”填写 DeepSeek、OpenAI、Claude 或 OpenAI 兼容接口。
2. 点击“测试连接”，成功后再保存。
3. 如果部署时设置了访问码，在“设置 → Web 安全”填写同一个值。

长期使用建议把密钥放在后端环境变量，而不是浏览器：

```env
SCHOLAR_ASSIST_AI_PROVIDER=deepseek
SCHOLAR_ASSIST_AI_API_KEY=你的密钥
SCHOLAR_ASSIST_AI_BASE_URL=https://api.deepseek.com
SCHOLAR_ASSIST_AI_MODEL=deepseek-chat
SCHOLAR_ASSIST_ACCESS_CODE=你的访问码
```

创作和文献工作流共用同一套 AI 配置。

## 3. 从首页开始

首页保留两个清晰模式：

- **文献模式**：搜索、导入和精读 PDF，建立证据卡与项目知识库。
- **创作模式**：进入三步论文启动向导，新建一篇独立稿件。

已有论文显示在模式入口下方的“最近论文”列表，点击对应行继续，不会和“新建论文”混在一个按钮里。

第一次使用建议先导入 2-5 篇核心 PDF，再新建论文。这样写作助手能基于真实材料工作，而不是只生成泛化文本。

## 4. 新建论文

启动向导共三步：

1. **选择写作类型**：本科论文、硕士论文、期刊论文、开题报告或自定义。
2. **设置格式**：使用内置结构，或导入旧论文、目标模板、CSL、DOCX/PDF 作为线索。
3. **填写研究信息并选择开始方式**：空白论文、大纲或章节骨架。

导入普通 DOCX/PDF 只能提取标题、结构、引用和排版线索，不能自动还原学校或期刊的精确模板。正式定稿应使用目标机构提供的 `reference.docx + CSL` 并人工核对。

系统生成的骨架会使用 `[待补引用]` 和 `[需要实验数据]`，不会预填虚构 DOI、页码或实验结果。

## 5. 写作和保存

进入写作区后，页面中心始终是论文：

- 左侧目录、规划区和右侧助手默认收起，需要时再打开。
- 正文修改约 1.5 秒后自动保存。
- 顶部会显示“保存中、已保存、保存失败、版本冲突或恢复副本”。
- “保存版本”会创建可跨刷新恢复的服务端版本。
- 返回首页前如果仍有未保存内容，系统会提示确认。

看到“保存失败”时先不要刷新，点击“重试”。浏览器恢复副本会在后端保存成功前保留当前正文。

## 6. 检索和保存文献

优先使用 OpenAlex、Semantic Scholar、Crossref、PubMed 和 arXiv 等开放 API。输入中文和英文关键词可以扩大召回范围。

Google Scholar、知网等页面可能出现验证码：

1. 打开浏览器辅助搜索。
2. 由用户手动完成验证。
3. 回到应用点击继续读取。

软件不会绕过验证码，也不承诺无人值守抓取全部结果。核心项目不要只依赖这些网页来源。

把可信论文保存到项目库后，先处理重复 DOI、citekey 冲突和缺失元数据，再进入写作。

文献检索、项目库保存、AI 阅读和引用导出会在视图顶部显示处理状态。出现失败时先阅读具体原因；提示“后端需要重启”时停止旧进程并重新运行 `npm run web:start`。

## 7. PDF 精读与证据

上传 PDF 后可以按页阅读、批注并提取证据。证据卡应至少包含：

- 文献和 citekey
- 原文片段
- 页码
- 你的解释或用途
- 适合写入的章节

AI 问答只应使用返回的证据。证据不足时继续补材料，不要把模型常识当作文献结论。

## 8. 引用和参考文献

从项目库插入引用，而不是让 AI 自由编造：

1. 打开助手的“找证据”。
2. 选择项目库和目标文献。
3. 插入 citekey 或证据卡。
4. 定稿前运行“引用闭环”，处理缺失、重复和未使用引用。

GB/T 7714、APA 和 IEEE 应通过 CSL/citeproc 确定性生成；生成后仍需按学校或期刊要求核对。

## 9. 图表

普通 Markdown 表格可以生成预览图或三线表。Nature Figure 属于高级实验工具：

1. 填写核心结论和证据链。
2. 上传真实 CSV/Excel，或粘贴已替换占位符的源数据。
3. 生成预览并核对数值、误差、样本量和图注。
4. 确认后再插入正文。

没有真实源数据时只能生成工作流规划，不能生成或插入科研结果图。系统不会用随机数代替实验数据。

## 10. 定稿和导出

先打开助手的“定稿导出”，运行导出前体检。必须处理的阻断项包括：

- `[待补引用]`、`[需要实验数据]` 或 `USER_DATA_REQUIRED`
- 缺失或无效 citekey
- 公式未闭合
- 图表缺源数据或正文引用
- 目标模板、Pandoc/Quarto 等导出依赖缺失

Markdown 和 HTML 可以在浏览器端应急导出。DOCX/PDF 失败时会明确报错，不会把 HTML 文件冒充 DOCX。没有 Word 时，用 WPS 或 LibreOffice 打开 DOCX 做学校模板微调。

## 11. 环境与验收

检查运行环境：

```bash
npm run doctor:delivery
```

完整本地验收：

```bash
npm test
npm run test:acceptance
npm run smoke:ui
```

`npm test` 运行前后端测试；`npm run test:acceptance` 构建 Web 包、运行交付体检和 Web smoke；`npm run smoke:ui` 会真实操作新建、编辑、自动保存、刷新恢复和定稿体检。

## 12. 常见问题

### 端口 1420 被占用

```bash
lsof -nP -iTCP:1420 -sTCP:LISTEN
kill 对应PID
```

也可以显式换端口启动：

```bash
FRONTEND_PORT=1430 BACKEND_PORT=8770 npm run web:start
```

### 搜索只返回 10 篇

先检查来源本身是否只有一页、浏览器辅助是否仍在等待验证、最低相关阈值是否过高，以及保护上限是否生效。开放 API 搜索比网页抓取更适合作为批量主路径。

### DOCX/PDF 导出失败

先运行 `npm run doctor:delivery`，检查后端、Pandoc、Quarto、LaTeX 和模板文件。正文不会因为导出失败丢失；可以先保存版本并导出 Markdown。

### 换电脑

先导出工作区备份清单，并复制 SQLite 数据库、PDF 上传目录、图表和导出资产。不要只复制前端源码。

## 推荐的第一次完整流程

```text
启动 Web -> 配置 AI/访问码 -> 导入核心 PDF -> 保存项目库
-> 提取页码证据 -> 新建论文 -> 插入引用并写作
-> 保存版本 -> 定稿体检 -> DOCX/PDF -> WPS/LibreOffice 最终核对
```
