"""
Scholar Assist — AI 学术助手后端
FastAPI 主入口
"""
import sys
import os
from pathlib import Path

sys.path.insert(0, os.path.dirname(__file__))

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from routers.search import router as search_router
from routers.ai import router as ai_router
from routers.chart import router as chart_router
from routers.pdf import router as pdf_router
from routers.citations import router as citations_router
from routers.export import router as export_router
from routers.publication import router as publication_router
from routers.zotero import router as zotero_router
from routers.library import router as library_router
from routers.manuscripts import router as manuscripts_router
from security import get_cors_origins, scholar_assist_security_middleware, security_status

app = FastAPI(
    title="Scholar Assist API",
    description="AI 学术助手后端服务 — 学术搜索、AI 分析、图表生成、PDF 解析",
    version="0.6.1",
)

cors_origins = get_cors_origins()

# CORS for local and deployed Web clients.
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=cors_origins != ["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def security_guard(request, call_next):
    return await scholar_assist_security_middleware(request, call_next)


# 注册路由
app.include_router(search_router)
app.include_router(ai_router)
app.include_router(chart_router)
app.include_router(pdf_router)
app.include_router(citations_router)
app.include_router(export_router)
app.include_router(publication_router)
app.include_router(zotero_router)
if os.environ.get("SCHOLAR_ASSIST_ENABLE_LEGACY_WORD_BRIDGE", "").strip() == "1":
    from routers.word import router as word_router
    app.include_router(word_router)
app.include_router(library_router)
app.include_router(manuscripts_router)

static_dir = os.environ.get("SCHOLAR_ASSIST_STATIC_DIR", "").strip()
if static_dir and os.path.isdir(static_dir):
    assets_dir = os.path.join(static_dir, "assets")
    if os.path.isdir(assets_dir):
        app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")


@app.get("/api/health")
async def health_check():
    """健康检查"""
    return {
        "status": "ok",
        "service": "Scholar Assist Backend",
        "version": "0.6.1",
        "endpoints": [
            "GET  /api/health",
            "GET  /api/search/papers?q=...&engines=...&limit=...",
            "GET  /api/search/engines",
            "POST /api/search/browser-assist/start",
            "POST /api/search/browser-assist/{session_id}/read",
            "GET  /api/search/browser-assist/{session_id}/logs",
            "POST /api/search/browser-assist/reset-profile",
            "DELETE /api/search/browser-assist/{session_id}",
            "POST /api/ai/summarize",
            "POST /api/ai/summarize-multiple",
            "POST /api/ai/knowledge-brief",
            "POST /api/ai/key-info",
            "POST /api/ai/chat",
            "POST /api/chart/generate",
            "POST /api/chart/table",
            "POST /api/chart/nature-figure/workflow",
            "POST /api/chart/nature-figure/render",
            "POST /api/pdf/upload",
            "GET  /api/pdf/documents/{document_id}/file",
            "POST /api/pdf/extract",
            "POST /api/pdf/metadata",
            "POST /api/publication/evidence-index/persist",
            "POST /api/publication/evidence-search",
            "POST /api/citations/verify",
            "POST /api/citations/export",
            "POST /api/export/manuscript",
            "GET  /api/publication/tools",
            "POST /api/publication/cross-references",
            "POST /api/publication/quality",
            "POST /api/publication/preflight",
            "POST /api/publication/literature-matrix",
            "POST /api/zotero/sync",
            "GET  /api/library/libraries",
            "POST /api/library/libraries",
            "GET  /api/library/search?q=...",
            "GET  /api/manuscripts",
            "POST /api/manuscripts",
            "PUT  /api/manuscripts/{manuscript_id}",
            "GET  /api/manuscripts/{manuscript_id}/versions",
            "POST /api/manuscripts/{manuscript_id}/versions",
        ],
        "security": security_status(),
    }


@app.head("/{full_path:path}", include_in_schema=False)
@app.get("/{full_path:path}", include_in_schema=False)
async def serve_web_app(full_path: str):
    """Serve the built React app in web deployments."""
    if full_path == "api" or full_path.startswith("api/"):
        raise HTTPException(status_code=404, detail="API endpoint not found")
    if not static_dir or not os.path.isdir(static_dir):
        return {"status": "ok", "message": "Scholar Assist API is running"}
    static_root = Path(static_dir).resolve()
    target = (static_root / full_path.lstrip("/")).resolve()
    if target != static_root and static_root not in target.parents:
        target = static_root / "index.html"
    if full_path and target.is_file():
        return FileResponse(target)
    return FileResponse(static_root / "index.html")


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("BACKEND_PORT", "8765"))
    reload_enabled = os.environ.get("SCHOLAR_ASSIST_DEV_RELOAD", "").strip() == "1"
    target = "backend.main:app" if reload_enabled else app
    uvicorn.run(
        target,
        host="127.0.0.1",
        port=port,
        log_level="info",
        reload=reload_enabled,
        reload_dirs=[str(Path(__file__).resolve().parent)] if reload_enabled else None,
    )
