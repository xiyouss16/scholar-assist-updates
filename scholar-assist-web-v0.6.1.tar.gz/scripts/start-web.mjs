#!/usr/bin/env node
import net from "node:net";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { formatPythonResolutionError, resolvePythonCommand } from "./python-runtime.mjs";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const isWindows = process.platform === "win32";
const backendPort = Number(process.env.BACKEND_PORT || 8765);
const frontendPort = Number(process.env.FRONTEND_PORT || 1420);
const children = new Set();

function isPortFree(port) {
  return new Promise(resolve => {
    const server = net.createServer();
    server.once("error", error => {
      if (error.code === "EADDRINUSE") {
        resolve(false);
        return;
      }
      resolve(false);
    });
    server.once("listening", () => {
      server.close(() => resolve(true));
    });
    server.listen(port, "127.0.0.1");
  });
}

function spawnManaged(name, command, args, options = {}) {
  const { env: optionEnv = {}, ...spawnOptions } = options;
  const child = spawn(command, args, {
    cwd: root,
    stdio: "inherit",
    shell: isWindows,
    env: {
      ...process.env,
      BACKEND_PORT: String(backendPort),
      FRONTEND_PORT: String(frontendPort),
      ...optionEnv,
    },
    ...spawnOptions,
  });
  children.add(child);
  child.once("exit", code => {
    children.delete(child);
    if (code && code !== 0) {
      console.error(`[${name}] exited with code ${code}`);
      shutdown(code);
    }
  });
  return child;
}

function shutdown(code = 0) {
  for (const child of children) {
    if (!child.killed) child.kill(isWindows ? undefined : "SIGTERM");
  }
  setTimeout(() => process.exit(code), 250);
}

process.on("SIGINT", () => shutdown(0));
process.on("SIGTERM", () => shutdown(0));

const backendMain = join(root, "backend", "main.py");
if (!existsSync(backendMain)) {
  console.error("Missing backend/main.py. Please run this from the Scholar Assist repository root.");
  process.exit(1);
}

const [backendFree, frontendFree] = await Promise.all([
  isPortFree(backendPort),
  isPortFree(frontendPort),
]);

if (!backendFree || !frontendFree) {
  console.error(
    `Port check failed: ${!backendFree ? `BACKEND_PORT ${backendPort}` : ""} ${!frontendFree ? `FRONTEND_PORT ${frontendPort}` : ""}`.trim(),
  );
  console.error("Close the old process or set BACKEND_PORT/FRONTEND_PORT to another value.");
  process.exit(1);
}

const python = resolvePythonCommand({ cwd: root });
if (!python.ok) {
  console.error(formatPythonResolutionError(python));
  console.error("Override example: SCHOLAR_ASSIST_PYTHON=/path/to/python3 npm run web:start");
  process.exit(1);
}

if (!process.env.SCHOLAR_ASSIST_ACCESS_CODE) {
  console.log("[web:start] SCHOLAR_ASSIST_ACCESS_CODE is not set; local development will run without an access code.");
}

console.log(`[web:start] backend: ${python.label} backend/main.py on http://127.0.0.1:${backendPort}`);
console.log(`[web:start] frontend: npm run web:dev on http://127.0.0.1:${frontendPort}`);

spawnManaged("backend", python.command, [...python.args, "backend/main.py"], {
  env: { SCHOLAR_ASSIST_DEV_RELOAD: "1" },
});
spawnManaged("frontend", isWindows ? "npm.cmd" : "npm", ["run", "web:dev"], {
  env: {
    VITE_BACKEND_URL: process.env.VITE_BACKEND_URL || `http://127.0.0.1:${backendPort}`,
  },
});
